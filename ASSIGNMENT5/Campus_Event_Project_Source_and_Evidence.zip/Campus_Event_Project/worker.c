#include <stdio.h>
#include <unistd.h>
int main(void){ printf("EXEC_WORKER: separate utility started; pid=%ld\n",(long)getpid()); return 0; }
