#!/bin/sh
# Demonstration orchestrator. Run from the project directory.
set -eu
./campus init
printf '\n[1] Persistent file records\n'; ./campus list
printf '\n[2] Concurrent analysis and mutex test\n'; ./campus threads
printf '\n[3] Pipe-based producer/consumer IPC\n'; ./campus ipc
printf '\n[4] fork/exec/wait process management\n'; ./campus process-demo
printf '\n[5] Start local TCP server in background\n'
./server > integrated_server.log 2>&1 & SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM
sleep 1
printf '\n[6] Send event through TCP client\n'; ./client EVENT 10 GATE-INT '2026-11-15 15:00:00' ACCESS 'Integrated event'
printf '\n[7] Request filtered summary through TCP client\n'; ./client SUMMARY '2026-11-15 00:00:00' '2026-11-15 23:59:59'
printf '\n[8] Final event report\n'; ./campus process 10 ACCESS
kill "$SERVER_PID" 2>/dev/null || true
wait "$SERVER_PID" 2>/dev/null || true
trap - EXIT INT TERM
