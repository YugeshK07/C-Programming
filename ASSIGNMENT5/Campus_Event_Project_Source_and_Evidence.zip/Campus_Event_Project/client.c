#include "common.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
static int send_all(int fd,const char*b,size_t n){size_t o=0;while(o<n){ssize_t r=send(fd,b+o,n-o,0);if(r<0){if(errno==EINTR)continue;return -1;}o+=(size_t)r;}return 0;}
int main(int argc,char**argv){if(argc<2){fprintf(stderr,"usage: client EVENT|SUMMARY ...\n");return 2;}char req[MAX_LINE];if(!strcmp(argv[1],"EVENT")){if(argc<7)return 2;snprintf(req,sizeof req,"EVENT|%s|%s|%s|%s|%s\n",argv[2],argv[3],argv[4],argv[5],argv[6]);}else if(!strcmp(argv[1],"SUMMARY")){if(argc<4)return 2;snprintf(req,sizeof req,"SUMMARY|%s|%s\n",argv[2],argv[3]);}else return 2;int s=socket(AF_INET,SOCK_STREAM,0);if(s<0){perror("socket");return 1;}struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_port=htons(PORT);inet_pton(AF_INET,HOST,&a.sin_addr);if(connect(s,(struct sockaddr*)&a,sizeof a)<0){perror("connect");close(s);return 1;}if(send_all(s,req,strlen(req))<0){perror("send");close(s);return 1;}shutdown(s,SHUT_WR);char b[256];ssize_t n=recv(s,b,sizeof b-1,0);if(n<0){perror("recv");close(s);return 1;}b[n]='\0';printf("CLIENT_RESPONSE: %s",b);close(s);return 0;}
