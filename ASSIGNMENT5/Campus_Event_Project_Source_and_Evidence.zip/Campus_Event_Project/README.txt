Campus Event Log and Monitoring System – source package
Environment target: Linux/POSIX, GCC, pthreads, IPv4 TCP localhost.
Build: gcc -Wall -Wextra -Wpedantic -std=c11 -pthread common.c campus.c -o campus
gcc -Wall -Wextra -Wpedantic -std=c11 common.c server.c -o server
gcc -Wall -Wextra -Wpedantic -std=c11 common.c client.c -o client
gcc -Wall -Wextra -Wpedantic -std=c11 worker.c -o worker
Run commands from this directory. See assignment report for task mapping, evidence and limitations.
