#include "common.h"
#include <sys/file.h>
#include <sys/stat.h>
void now_string(char out[20]) { time_t t=time(NULL); struct tm tmv; localtime_r(&t,&tmv); strftime(out,20,"%Y-%m-%d %H:%M:%S",&tmv); }
int append_event(const Event *e) {
    int fd=open(LOG_FILE,O_WRONLY|O_APPEND|O_CREAT,0644);
    if(fd<0){perror("open events.log");return -1;}
    if(flock(fd,LOCK_EX)<0){perror("flock");close(fd);return -1;}
    char row[MAX_LINE]; int len=snprintf(row,sizeof row,"%d|%s|%s|%s|%s\n",e->id,e->source,e->timestamp,e->type,e->message);
    ssize_t written=write(fd,row,(size_t)len);
    if(written!=len){if(written<0)perror("write event");else fprintf(stderr,"short write\n");flock(fd,LOCK_UN);close(fd);return -1;}
    flock(fd,LOCK_UN); if(close(fd)<0){perror("close log");return -1;} return 0;
}
int parse_event(const char *line, Event *e) {
    char copy[MAX_LINE]; snprintf(copy,sizeof copy,"%s",line); char *save=NULL;
    char *p=strtok_r(copy,"|\n",&save); if(!p)return -1; char *end=NULL; long id=strtol(p,&end,10); if(*end||id<0||id>2147483647)return -1; e->id=(int)id;
    p=strtok_r(NULL,"|\n",&save); if(!p||strlen(p)>=sizeof e->source)return -1; strcpy(e->source,p);
    p=strtok_r(NULL,"|\n",&save); if(!p||strlen(p)!=19)return -1; strcpy(e->timestamp,p);
    p=strtok_r(NULL,"|\n",&save); if(!p||strlen(p)>=sizeof e->type)return -1; strcpy(e->type,p);
    p=strtok_r(NULL,"\n",&save); if(!p||strlen(p)>=sizeof e->message||strchr(p,'|'))return -1; strcpy(e->message,p); return 0;
}
