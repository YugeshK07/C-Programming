#ifndef COMMON_H
#define COMMON_H
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>
#define LOG_FILE "events.log"
#define MAX_LINE 512
#define PORT 15055
#define HOST "127.0.0.1"
typedef struct { int id; char source[32]; char timestamp[20]; char type[32]; char message[256]; } Event;
void now_string(char out[20]);
int append_event(const Event *e);
int parse_event(const char *line, Event *e);
#endif
