/* Campus CMS front end. Plain JS, no build step: the C server just serves this file. */
'use strict';

const $app = document.getElementById('app');
const state = { me: null, staff: [], timer: null, view: null };

const SUBCATS = {
  'Hostel Maintenance': ['Plumbing & Water Supply', 'Furniture & Fixtures', 'Doors, Locks & Windows', 'Pest Control', 'Other'],
  'Network & WiFi': ['Access point / coverage', 'Wired LAN', 'Login / authentication', 'Slow speed', 'Other'],
  'Electrical & Power': ['Fan / light not working', 'Power socket', 'Frequent power cuts', 'Exposed wiring (hazard)', 'Other'],
  'Classroom & AV': ['Projector / display', 'Audio system', 'Furniture', 'Air conditioning', 'Other'],
  'Sanitation & Drainage': ['Blocked drain', 'Washroom cleanliness', 'Garbage collection', 'Water logging', 'Other'],
  'Civil & Structural': ['Cracks / seepage', 'Broken tiles or flooring', 'Roof leakage', 'Railings & stairs', 'Other'],
};
const CAT_ICON = {
  'Hostel Maintenance': 'building', 'Network & WiFi': 'wifi', 'Electrical & Power': 'bolt',
  'Classroom & AV': 'screen', 'Sanitation & Drainage': 'drop', 'Civil & Structural': 'tool',
};
const ZONES = ['Hostel Block A', 'Hostel Block B', 'Hostel Block C (Girls)', 'Academic Block A', 'CSE Block',
  'ECE Block', 'Central Library', 'Main Canteen', 'Sports Complex', 'Admin Building', 'Other'];
const PRIOS = [
  { name: 'Low', sla: 72, dot: '#94a3b8' }, { name: 'Medium', sla: 48, dot: '#0d9488' },
  { name: 'High', sla: 24, dot: '#f97316' }, { name: 'Critical', sla: 4, dot: '#e11d48' },
];
const STAGES = ['Logged', 'Reviewed', 'Assigned', 'In Progress', 'Resolved'];

/* ---------- tiny helpers ---------- */

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V21H3z"/><path d="M9 21v-6h6v6"/>',
  inbox: '<path d="M3 13h5l2 3h4l2-3h5"/><path d="M5 5h14l2 8v6H3v-6z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  track: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5c2 .7 3.2 2.6 3.5 5.5"/>',
  ledger: '<path d="M5 3h11l3 3v15H5z"/><path d="M9 9h6M9 13h6M9 17h4"/>',
  key: '<circle cx="7.5" cy="14.5" r="4"/><path d="m10.5 11.5 9-9M16 6l3 3M14 8l2 2"/>',
  logout: '<path d="M15 4h4v16h-4"/><path d="M10 8l-4 4 4 4M6 12h11"/>',
  building: '<path d="M4 21V5l8-3 8 3v16"/><path d="M9 9h1M14 9h1M9 13h1M14 13h1M10 21v-4h4v4"/>',
  wifi: '<path d="M2 8.5a15 15 0 0 1 20 0M5 12a10 10 0 0 1 14 0M8.5 15.5a5 5 0 0 1 7 0"/><circle cx="12" cy="19" r="1"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  screen: '<rect x="3" y="4" width="18" height="12" rx="1"/><path d="M8 20h8M12 16v4"/>',
  drop: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
  tool: '<path d="M14.5 6.5a4 4 0 0 0 5 5L12 19l-3 1-2-2 1-3 7.5-7.5"/><path d="M14.5 6.5 17 4l3 3-2.5 2.5"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  alert: '<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17v.5"/>',
  phone: '<path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2z"/>',
  note: '<path d="M4 4h16v12H8l-4 4z"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  print: '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="1"/><path d="M6 14h12v7H6z"/>',
  shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
  cap: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5"/>',
  badge: '<rect x="4" y="5" width="16" height="15" rx="2"/><circle cx="12" cy="11" r="2.5"/><path d="M8 17c.8-1.6 2.2-2.5 4-2.5s3.2.9 4 2.5M9 3h6"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  userplus: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5M19 8v6M16 11h6"/>',
  terminal: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3M12 15h5"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  star: '<path d="m12 2.5 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z"/>',
  pin: '<path d="M12 21s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  wrench: '<path d="M14.5 6.5a4 4 0 0 0 5 5L12 19l-3 1-2-2 1-3 7.5-7.5"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
};
const icon = (n, cls = '') => `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

const initials = (name) => String(name || '?').replace(/^(Dr|Prof|Mr|Ms|Mrs)\.?\s+/i, '').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();

function fmtDate(ts, withTime = true) {
  if (!ts) return '';
  const d = new Date(ts * 1000);
  const date = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  return withTime ? `${date}, ${d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}` : date;
}
const fmtTime = (ts) => new Date(ts * 1000).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });

function ago(ts) {
  const s = Math.floor(Date.now() / 1000) - ts;
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
}

/* "1h 45m left", "overdue 3h", or how it ended for closed complaints */
function slaInfo(c) {
  if (!c.open) {
    if (c.status === 'Rejected') return { text: 'closed', cls: '' };
    const met = c.resolved_at <= c.deadline;
    return { text: met ? 'SLA met' : 'SLA missed', cls: met ? 'ok' : 'over' };
  }
  let s = c.deadline - Math.floor(Date.now() / 1000);
  const over = s < 0;
  s = Math.abs(s);
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
  const span = d ? `${d}d ${h}h` : h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m`;
  return { text: over ? `overdue ${span}` : `${span} left`, cls: over ? 'over' : '' };
}

function statusBadge(c) {
  const cls = { Pending: 'pending', Reviewed: 'reviewed', Assigned: 'assigned', 'In Progress': 'progress', Resolved: 'resolved', Rejected: 'rejected' }[c.status] || 'pending';
  return `<span class="badge b-${cls}">${esc(c.status)}</span>` + (c.escalated && c.open ? ' <span class="badge b-escalated">Escalated</span>' : '');
}
const prioBadge = (p) => `<span class="badge plain b-${String(p).toLowerCase()}">${esc(p)}</span>`;
const idBadge = (id) => `<span class="badge b-id">${esc(id)}</span>`;
const catBadge = (c) => `<span class="badge b-cat">${icon(CAT_ICON[c] || 'tool', 'sm')} ${esc(c)}</span>`;

function toast(msg, bad = false) {
  const t = document.createElement('div');
  t.className = 'toast' + (bad ? ' bad' : '');
  t.textContent = msg;
  document.getElementById('toasts').appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

/* ---------- API ---------- */

async function api(method, path, data) {
  const opt = { method, credentials: 'same-origin', headers: {} };
  if (data) {
    opt.headers['Content-Type'] = 'application/x-www-form-urlencoded';
    opt.body = new URLSearchParams(data).toString();
  }
  let res;
  try {
    res = await fetch('/api' + path, opt);
  } catch (e) {
    throw new Error('Cannot reach the server. Is cms_server running?');
  }
  const body = await res.json().catch(() => ({}));
  if (res.status === 401 && path !== '/login') {
    state.me = null;
    location.hash = '#/login';
    throw new Error(body.error || 'Session expired, sign in again.');
  }
  if (!res.ok) throw new Error(body.error || `Request failed (${res.status})`);
  return body;
}

/* small modal for "why?" / "what was done?" prompts */
function ask({ title, text = '', label = 'Note', placeholder = '', confirm = 'Save', required = true, extra = '' }) {
  return new Promise((resolve) => {
    const bg = document.createElement('div');
    bg.className = 'modal-bg';
    bg.innerHTML = `<form class="modal" role="dialog" aria-modal="true">
      <h3>${esc(title)}</h3>${text ? `<p class="muted small">${esc(text)}</p>` : ''}
      ${extra}
      <div class="f-row" style="margin-top:14px"><label class="f">${esc(label)}</label>
      <textarea name="v" maxlength="480" placeholder="${esc(placeholder)}" ${required ? 'required minlength="3"' : ''}></textarea></div>
      <div class="actions"><button type="button" class="btn" data-x>Cancel</button><button class="btn primary">${esc(confirm)}</button></div></form>`;
    const done = (v) => { bg.remove(); resolve(v); };
    bg.querySelector('[data-x]').onclick = () => done(null);
    bg.onclick = (e) => { if (e.target === bg) done(null); };
    bg.querySelector('form').onsubmit = (e) => {
      e.preventDefault();
      const f = new FormData(e.target);
      done(Object.fromEntries(f.entries()));
    };
    document.body.appendChild(bg);
    bg.querySelector('textarea').focus();
  });
}

/* ---------- routing ---------- */

const ROUTES = [
  [/^#\/login$/, viewLogin, false],
  [/^#\/home$/, viewHome, true],
  [/^#\/new$/, viewNew, true],
  [/^#\/list$/, viewList, true],
  [/^#\/c\/([\w-]+)$/, viewComplaint, true],
  [/^#\/users$/, viewUsers, true],
  [/^#\/audit$/, viewAudit, true],
  [/^#\/account$/, viewAccount, true],
];

async function router() {
  clearInterval(state.timer);
  state.timer = null;
  const hash = location.hash || '#/home';
  if (!state.me && hash !== '#/login') {
    try { state.me = await api('GET', '/me'); } catch (e) { /* api() already redirected */ return; }
  }
  for (const [re, fn, needsAuth] of ROUTES) {
    const m = hash.match(re);
    if (!m) continue;
    if (needsAuth && !state.me) { location.hash = '#/login'; return; }
    state.view = fn;
    try {
      await fn(...m.slice(1));
    } catch (e) {
      if (state.me) renderShell('Error', `<div class="err">${esc(e.message)}</div>`);
    }
    window.scrollTo(0, 0);
    return;
  }
  location.hash = state.me ? '#/home' : '#/login';
}
window.addEventListener('hashchange', router);

/* re-runs the current view every so often so changes made by other users show up */
function autoRefresh(fn, ms = 20000) {
  state.timer = setInterval(() => {
    const a = document.activeElement;
    if (document.hidden || document.querySelector('.modal-bg')) return;
    if (a && /INPUT|TEXTAREA|SELECT/.test(a.tagName)) return;
    fn().catch(() => {});
  }, ms);
}

/* ---------- shell ---------- */

function navItems() {
  const r = state.me.role;
  const items = [['#/home', 'home', 'Dashboard']];
  if (r === 'student') items.push(['#/list', 'inbox', 'My complaints'], ['#/new', 'plus', 'Lodge complaint']);
  if (r === 'staff') items.push(['#/list', 'inbox', 'My work queue'], ['#/new', 'plus', 'Report an issue']);
  if (r === 'admin' || r === 'supervisor') items.push(['#/list', 'inbox', 'All complaints'], ['#/audit', 'ledger', 'Audit ledger']);
  if (r === 'admin') items.push(['#/users', 'users', 'Manage accounts']);
  return items;
}

function renderShell(title, body, subtitle = '') {
  const me = state.me;
  const here = location.hash.split('?')[0];
  const nav = navItems().map(([h, ic, t]) => `<a href="${h}" class="${here === h ? 'on' : ''}">${icon(ic)} ${t}</a>`).join('');
  const roleLabel = { student: 'Student', staff: 'Staff', admin: 'Admin', supervisor: 'Supervisor' }[me.role];
  const bottom = [['#/home', 'home', 'Home'], ['#/list', 'inbox', 'My CMP'], ['#/new', 'plus', 'New'],
    [me.role === 'admin' || me.role === 'supervisor' ? '#/audit' : '#/list', 'track', 'Track'], ['#/account', 'user', 'More']];
  $app.innerHTML = `
  <div class="shell">
    <aside class="sidebar">
      <div class="brand"><div class="crest">${icon('shield')}</div><div><b>Campus CMS</b><span>${roleLabel} console</span></div></div>
      <nav class="nav">${nav}<div class="sep"></div>
        <a href="#/account" class="${here === '#/account' ? 'on' : ''}">${icon('key')} Account</a>
        <a href="#" data-logout>${icon('logout')} Sign out</a></nav>
      <div class="side-foot"><span class="dot"></span>C server online</div>
    </aside>
    <div class="main">
      <header class="topbar">
        <h1>${esc(title)}${subtitle ? `<small>${esc(subtitle)}</small>` : ''}</h1>
        <div class="who"><div class="meta"><b>${esc(me.name)}</b><span class="muted small mono">${esc(me.username)}</span></div>
          <div class="avatar">${esc(initials(me.name))}</div><span class="role-pill">${roleLabel}</span></div>
      </header>
      <main class="content">${body}</main>
    </div>
  </div>
  <nav class="bottom-nav">${bottom.map(([h, ic, t]) => `<a href="${h}" class="${ic === 'plus' ? 'fab' : ''} ${here === h && ic !== 'track' ? 'on' : ''}">${icon(ic)}${t}</a>`).join('')}</nav>`;
  $app.querySelector('[data-logout]').onclick = logout;
}

async function logout(e) {
  if (e) e.preventDefault();
  await api('POST', '/logout').catch(() => {});
  state.me = null;
  location.hash = '#/login';
}

/* ---------- login ---------- */

let loginRole = 'student';

async function viewLogin() {
  if (state.me) { location.hash = '#/home'; return; }
  const roles = [
    ['student', 'cap', 'Student', 'Roll no. sign in', 'University Roll No / Campus ID', 'CS2023084'],
    ['staff', 'badge', 'Staff / Officer', 'Staff ID directory', 'Staff / Faculty ID', 'OP-408'],
    ['admin', 'shield', 'Administrator', 'Dispatch & accounts', 'Admin ID', 'admin'],
    ['supervisor', 'eye', 'Supervisor', 'Escalation & review', 'Supervisor ID', 'super01'],
  ];
  const cur = roles.find((r) => r[0] === loginRole);
  $app.innerHTML = `
  <div class="login">
    <div class="statusbar" id="hb"><span class="dot"></span> connecting to server…</div>
    <div class="crest">${icon('shield')}</div>
    <span class="tag">Academic operations</span>
    <h1>Campus Complaint<br>Management System</h1>
    <p class="sub">Report campus problems, follow them to the fix, and see who's on it.</p>

    <div class="roles" role="tablist">${roles.map(([k, ic, t, s]) =>
      `<button type="button" role="tab" data-role="${k}" class="${k === loginRole ? 'on' : ''}" aria-selected="${k === loginRole}"><b>${icon(ic)} ${t}</b><small>${s}</small></button>`).join('')}</div>

    <form class="card" id="loginForm" autocomplete="on">
      <div class="f-row">
        <div class="row between"><label class="f" for="u">${cur[4]} <span class="req">*</span></label><span class="role-tag">ROLE_${loginRole.toUpperCase()}</span></div>
        <div class="input-icon">${icon('user')}<input id="u" name="username" type="text" required placeholder="e.g. ${cur[5]}" autocomplete="username"></div>
      </div>
      <div class="f-row">
        <label class="f" for="p">Password <span class="req">*</span></label>
        <div class="input-icon">${icon('key')}<input id="p" name="password" type="password" required autocomplete="current-password">
          <button type="button" id="peek" aria-label="Show password">${icon('eye')}</button></div>
      </div>
      <label class="check f-row"><input type="checkbox" name="remember" value="1" checked> Keep me signed in on this computer (8 hours)</label>
      <div id="loginErr"></div>
      <button class="btn primary block lg">Sign in ${icon('arrow')}</button>
    </form>

    <div class="reg" id="regBox">
      <div class="ic">${icon('userplus')}</div>
      <div class="grow"><b>New student?</b><p class="small muted">Register with your roll number. Staff accounts come from the estate office.</p></div>
      <button class="btn" id="showReg">Register</button>
    </div>
    <form class="card hidden" id="regForm" style="margin-top:14px">
      <h3 style="font-size:16px;margin-bottom:12px">Student registration</h3>
      <div class="grid g2">
        <div class="f-row"><label class="f">Roll number <span class="req">*</span></label><input type="text" name="username" required minlength="3" maxlength="30" pattern="[A-Za-z0-9._\\-]+"></div>
        <div class="f-row"><label class="f">Full name <span class="req">*</span></label><input type="text" name="name" required maxlength="60"></div>
      </div>
      <div class="f-row"><label class="f">Department</label><input type="text" name="dept" maxlength="90" placeholder="Computer Science & Engineering"></div>
      <div class="f-row"><label class="f">Password <span class="req">*</span></label><input type="password" name="password" required minlength="6" autocomplete="new-password"></div>
      <div id="regErr"></div>
      <div class="row"><button class="btn primary">Create account</button><button type="button" class="btn" id="hideReg">Cancel</button></div>
    </form>

    <div class="card tele">
      <div class="row between"><b class="row small" style="gap:8px">${icon('terminal')} SERVER TELEMETRY</b><span class="badge b-cat mono" id="sockState">checking</span></div>
      <dl id="tele"><dt>Engine</dt><dd>POSIX C sockets · pthreads</dd></dl>
    </div>

    <details class="demo"><summary>Demo accounts (created on first run)</summary>
      <table><tr><td>Student</td><td>CS2023084</td><td>student123</td></tr>
      <tr><td>Staff</td><td>OP-408</td><td>staff123</td></tr>
      <tr><td>Admin</td><td>admin</td><td>admin123</td></tr>
      <tr><td>Supervisor</td><td>super01</td><td>super123</td></tr></table></details>
    <p class="foot-note">${icon('shield', 'sm')} Passwords are salted and hashed with SHA-256 on the server.</p>
  </div>`;

  $app.querySelectorAll('[data-role]').forEach((b) => (b.onclick = () => { loginRole = b.dataset.role; viewLogin(); }));
  $app.querySelector('#peek').onclick = () => { const p = $app.querySelector('#p'); p.type = p.type === 'password' ? 'text' : 'password'; };
  $app.querySelector('#showReg').onclick = () => { $app.querySelector('#regForm').classList.remove('hidden'); $app.querySelector('#regBox').classList.add('hidden'); };
  $app.querySelector('#hideReg').onclick = () => { $app.querySelector('#regForm').classList.add('hidden'); $app.querySelector('#regBox').classList.remove('hidden'); };

  $app.querySelector('#loginForm').onsubmit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target).entries());
    f.role = loginRole;
    const box = $app.querySelector('#loginErr');
    box.innerHTML = '';
    try {
      const r = await api('POST', '/login', f);
      state.me = r.user;
      location.hash = '#/home';
    } catch (err) {
      box.innerHTML = `<div class="err f-row">${esc(err.message)}</div>`;
    }
  };
  $app.querySelector('#regForm').onsubmit = async (e) => {
    e.preventDefault();
    const box = $app.querySelector('#regErr');
    box.innerHTML = '';
    try {
      const r = await api('POST', '/register', Object.fromEntries(new FormData(e.target).entries()));
      state.me = r.user;
      toast('Welcome aboard, ' + r.user.name.split(' ')[0] + '!');
      location.hash = '#/home';
    } catch (err) {
      box.innerHTML = `<div class="err f-row">${esc(err.message)}</div>`;
    }
  };
  $app.querySelector('#u').focus();

  try {
    const h = await api('GET', '/health');
    const up = h.uptime < 3600 ? `${Math.floor(h.uptime / 60)} min` : `${Math.floor(h.uptime / 3600)} h ${Math.floor((h.uptime % 3600) / 60)} min`;
    $app.querySelector('#hb').innerHTML = `<span class="dot"></span> SERVER_ONLINE // PID ${h.pid}`;
    $app.querySelector('#sockState').textContent = 'SOCKET_READY';
    $app.querySelector('#tele').innerHTML = `<dt>Engine</dt><dd>C backend (cms_server)</dd>
      <dt>Process</dt><dd>PID ${h.pid} · up ${up}</dd>
      <dt>Records</dt><dd>${h.complaints} complaints · ${h.users} accounts</dd>
      <dt>Timeline</dt><dd>${h.events} audit events</dd>
      <dt>Auth</dt><dd>HMAC-SHA256 signed tokens</dd>`;
  } catch (e) {
    $app.querySelector('#hb').innerHTML = `<span class="dot off"></span> SERVER UNREACHABLE`;
    $app.querySelector('#sockState').textContent = 'OFFLINE';
  }
}

/* ---------- shared pieces ---------- */

function stageBar(c) {
  const segs = STAGES.map((_, i) => {
    const n = i + 1;
    const cls = n < c.stage || (n === c.stage && !c.open) ? 'done' : n === c.stage ? 'cur' : '';
    return `<div class="seg ${cls}"></div>`;
  }).join('');
  const labels = STAGES.map((s, i) => {
    const n = i + 1;
    const cls = n < c.stage || (n === c.stage && !c.open) ? 'done' : n === c.stage ? 'cur' : '';
    return `<span class="${cls}">${s}${cls === 'done' ? ' ✓' : ''}</span>`;
  }).join('');
  return `<div class="stages">${segs}</div><div class="stage-labels">${labels}</div>`;
}

function complaintCard(c, opts = {}) {
  const sla = slaInfo(c);
  const who = state.me.role === 'student'
    ? (c.assignee ? `${icon('wrench', 'sm')} ${esc(c.assignee)} <span class="muted">· ${esc(c.assignee_dept)}</span>` : `<span class="muted">${icon('clock', 'sm')} Waiting for the desk to assign someone</span>`)
    : (c.assignee ? `${icon('user', 'sm')} ${esc(c.assignee)}` : `<span class="muted">Unassigned</span>`);
  return `<a class="c-card ${c.escalated && c.open ? 'esc' : ''}" href="#/c/${esc(c.id)}">
    <div class="bar"><span class="row" style="gap:8px">${idBadge(c.id)} ${catBadge(c.category)}</span><span>${statusBadge(c)}</span></div>
    <h3>${esc(c.title)}</h3>
    <div class="meta"><span>${icon('pin', 'sm')} ${esc(c.zone)} · ${esc(c.room)}</span><span>${icon('clock', 'sm')} ${fmtDate(c.created)}</span></div>
    ${opts.noFoot ? '' : `<div class="foot"><span>${who}</span><span class="row" style="gap:8px">${prioBadge(c.priority)}<span class="mono small ${sla.cls === 'over' ? '' : 'muted'}" style="${sla.cls === 'over' ? 'color:var(--rose)' : ''}">${sla.text}</span></span></div>`}
  </a>`;
}

const emptyBox = (msg) => `<div class="empty">${icon('inbox')}<div>${esc(msg)}</div></div>`;

/* ---------- dashboards ---------- */

async function viewHome() {
  const r = state.me.role;
  if (r === 'student') return dashStudent();
  if (r === 'staff') return dashStaff();
  return dashManager();
}

async function dashStudent() {
  const me = state.me;
  const [list, stats] = await Promise.all([api('GET', '/complaints'), api('GET', '/stats')]);
  const items = list.items;
  const s = stats.by_status;
  const spot = items.find((c) => c.open);
  const recent = items.slice(0, 4);

  renderShell('Student dashboard', `
  <div class="cols">
    <div class="stack">
      <div class="card row">
        <div class="avatar lg">${esc(initials(me.name))}</div>
        <div><div class="row" style="gap:8px"><h2 style="font-size:18px">${esc(me.name)}</h2><span class="badge b-resolved plain">${icon('check', 'sm')} Verified</span></div>
        <div class="mono small muted">${esc(me.username)}</div><div class="small">${icon('building', 'sm')} ${esc(me.dept || 'Department not set')}</div></div>
      </div>

      <div class="hero">
        <span class="chip">${icon('bolt', 'sm')} Direct dispatch</span>
        <h2>Need to report an issue?</h2>
        <p>Hostel repairs, network outages, broken classroom gear, anything on campus that needs fixing.</p>
        <a class="btn block lg" href="#/new">${icon('plus')} Lodge new complaint</a>
      </div>

      <div class="grid g3 keep">
        <div class="card metric" style="text-align:center"><div class="label" style="justify-content:center">Waiting</div><div class="value" style="color:var(--navy)">${s.Pending + s.Reviewed}</div><div class="foot">not yet assigned</div></div>
        <div class="card metric" style="text-align:center"><div class="label" style="justify-content:center">Being fixed</div><div class="value" style="color:#c2410c">${s.Assigned + s['In Progress']}</div><div class="foot">someone's on it</div></div>
        <div class="card metric" style="text-align:center"><div class="label" style="justify-content:center">Resolved</div><div class="value" style="color:var(--green)">${s.Resolved}</div><div class="foot">all time</div></div>
      </div>

      ${spot ? `<div class="card">
        <div class="row between"><span class="eyebrow" style="color:var(--navy)">● Live spotlight</span>${idBadge(spot.id)}</div>
        <h3 style="font-size:17px;margin:10px 0 6px">${esc(spot.title)}</h3>
        <div class="row wrap small muted">${catBadge(spot.category)} <span>${fmtDate(spot.created)}</span></div>
        <div class="card" style="background:var(--tint);border-color:var(--tint-2);margin-top:12px;padding:12px">
          <div class="row between small"><b>Stage ${spot.stage} of 5</b>${statusBadge(spot)}</div>${stageBar(spot)}
        </div>
        ${spot.assignee ? `<div class="person" style="margin-top:12px;background:none;padding:10px 0">
          <div class="avatar">${esc(initials(spot.assignee))}</div><div class="grow"><b>${esc(spot.assignee)}</b><span>${esc(spot.assignee_dept)}</span></div>
          ${spot.assignee_phone ? `<a class="btn soft sm" href="tel:${esc(spot.assignee_phone)}" aria-label="Call">${icon('phone', 'sm')}</a>` : ''}</div>` : ''}
        <a class="btn soft block" style="margin-top:10px" href="#/c/${esc(spot.id)}">View full live tracking ${icon('arrow', 'sm')}</a>
      </div>` : ''}
    </div>

    <div class="stack">
      <div>
        <div class="section-title"><h2>Recent submissions</h2><a href="#/list">See all (${items.length})</a></div>
        <div class="list">${recent.length ? recent.map((c) => complaintCard(c)).join('') : emptyBox("You haven't lodged anything yet.")}</div>
      </div>
      <div class="alert" style="border-color:var(--rose-line)">
        <div class="ic">${icon('alert')}</div>
        <div class="grow"><div class="eyebrow" style="color:var(--rose)">Campus emergency desk</div><b>Hotline: Ext 4022</b><div class="mono small muted">24/7 for fire, flooding, live wires, injuries</div></div>
        <a class="btn sm" href="tel:4022">${icon('phone', 'sm')}</a>
      </div>
    </div>
  </div>`, 'Track what you reported');
  autoRefresh(dashStudent);
}

async function dashStaff() {
  const me = state.me;
  const [list, stats] = await Promise.all([api('GET', '/complaints?sort=sla'), api('GET', '/stats')]);
  const open = list.items.filter((c) => c.open);
  const now = Date.now() / 1000;
  const urgent = open.filter((c) => c.escalated || c.deadline - now < 4 * 3600).length;

  renderShell('Staff operations', `
  <div class="stack">
    <div class="card">
      <div class="row between wrap">
        <div class="row"><div class="avatar lg">${esc(initials(me.name))}</div>
          <div><div class="row" style="gap:8px"><h2 style="font-size:18px">${esc(me.name)}</h2>${idBadge(me.username)}</div>
          <div class="small muted">${esc(me.dept)}</div></div></div>
        <span class="badge b-resolved">ON DUTY</span>
      </div>
    </div>

    <div class="grid g4">
      <div class="card metric"><div class="label">Assigned</div><div class="value">${open.length}</div><div class="foot">open backlog</div></div>
      <div class="card metric"><div class="label" style="color:var(--rose)">Action</div><div class="value" style="color:var(--rose)">${urgent}</div><div class="foot">due &lt; 4h or escalated</div></div>
      <div class="card metric"><div class="label" style="color:#c2410c">Active</div><div class="value" style="color:#c2410c">${stats.by_status['In Progress']}</div><div class="foot">in progress</div></div>
      <div class="card metric"><div class="label" style="color:var(--green)">Closed</div><div class="value" style="color:var(--green)">${stats.by_status.Resolved}</div><div class="foot">+${stats.resolved_today} today</div></div>
    </div>

    <div>
      <div class="section-title"><h2><span style="color:var(--rose)">●</span> Priority dispatch queue</h2><span class="badge b-id">SLA sorted</span></div>
      <div class="list" id="queue">${open.length ? open.map(staffCard).join('') : emptyBox('Nothing assigned to you right now. Nice.')}</div>
    </div>
  </div>`, me.dept);

  $app.querySelectorAll('[data-act]').forEach((b) => (b.onclick = () => staffAction(b.dataset.act, b.dataset.id)));
  autoRefresh(dashStaff);
}

function staffCard(c) {
  const sla = slaInfo(c);
  const hot = c.escalated || c.priority === 'Critical' || sla.cls === 'over';
  const head = hot ? 'background:var(--rose-bg);border-color:var(--rose-line)' : 'background:var(--tint)';
  const label = c.escalated ? 'ESCALATED' : c.priority.toUpperCase();
  return `<div class="card" style="padding:0;overflow:hidden">
    <div class="row between" style="padding:10px 16px;border-bottom:1px solid var(--line);${head}">
      <span class="row" style="gap:8px"><span class="badge plain b-${hot ? 'critical' : c.priority.toLowerCase()}">${label}</span> <span class="mono small" style="font-weight:700;color:var(--navy)">${esc(c.id)}</span></span>
      <span class="mono small" style="font-weight:700;color:${sla.cls === 'over' || hot ? 'var(--rose)' : 'var(--text-2)'}">${icon('clock', 'sm')} ${sla.text}</span>
    </div>
    <div style="padding:14px 16px">
      <div class="row between wrap">${catBadge(c.category)}<span class="mono small muted">Due: ${fmtDate(c.deadline)}</span></div>
      <h3 style="font-size:16px;margin:10px 0 8px"><a href="#/c/${esc(c.id)}" style="color:inherit">${esc(c.title)}</a></h3>
      <div class="person"><div class="avatar" style="background:var(--tint-2);color:var(--navy)">${icon('user', 'sm')}</div>
        <div class="grow"><b>${esc(c.submitter)}</b><span>${esc(c.zone)}, ${esc(c.room)}</span></div>${statusBadge(c)}</div>
      <div class="grid g2" style="margin-top:12px;gap:10px">
        ${c.status === 'In Progress'
          ? `<button class="btn primary lg" data-act="resolve" data-id="${esc(c.id)}">${icon('check')} Mark resolved</button>`
          : `<button class="btn primary lg" data-act="accept" data-id="${esc(c.id)}">${icon('check')} Accept task</button>`}
        <button class="btn soft lg" data-act="note" data-id="${esc(c.id)}">${icon('note')} Add work note</button>
      </div>
    </div></div>`;
}

async function staffAction(act, id) {
  try {
    if (act === 'accept') {
      await api('POST', `/complaints/${id}/status`, { status: 'In Progress', note: 'Accepted, heading to site' });
      toast(`${id} accepted. The student can see you're on it.`);
    } else if (act === 'resolve') {
      const v = await ask({ title: `Resolve ${id}`, label: 'What was done?', placeholder: 'e.g. Replaced the cracked PVC coupling, tested for leaks.', confirm: 'Mark resolved' });
      if (!v) return;
      await api('POST', `/complaints/${id}/status`, { status: 'Resolved', note: v.v });
      toast(`${id} marked resolved.`);
    } else if (act === 'note') {
      const v = await ask({ title: `Work note for ${id}`, label: 'Note', placeholder: 'e.g. Waiting for parts from central store, back tomorrow 10am.' });
      if (!v) return;
      await api('POST', `/complaints/${id}/note`, { text: v.v });
      toast('Note added to the timeline.');
    }
    router();
  } catch (e) {
    toast(e.message, true);
  }
}

let mgrTab = null;

async function dashManager() {
  const me = state.me;
  const isAdmin = me.role === 'admin';
  if (!mgrTab) mgrTab = isAdmin ? 'all' : 'escalated';
  const q = { all: '', pending: '?status=Pending', unassigned: '?status=unassigned', escalated: '?escalated=1', resolved: '?status=Resolved' }[mgrTab];
  const [stats, list, health, audit, staff] = await Promise.all([
    api('GET', '/stats'), api('GET', '/complaints' + (q ? q + '&' : '?') + 'sort=sla'), api('GET', '/health'),
    api('GET', '/audit?limit=1'), api('GET', '/users?role=staff'),
  ]);
  state.staff = staff.items.filter((u) => u.active);
  const s = stats.by_status;
  const maxCat = Math.max(1, ...stats.by_category.map((c) => c.open));
  const catColors = ['#1e3a8a', '#0d9488', '#f97316', '#64748b', '#7c3aed', '#e11d48', '#94a3b8'];
  const last = audit.items[0];
  const tabs = [['all', 'All'], ['pending', 'Pending'], ['unassigned', 'Unassigned'], ['escalated', 'Escalated'], ['resolved', 'Resolved']];

  renderShell(isAdmin ? 'Administrator dashboard' : 'Supervisor dashboard', `
  <div class="stack">
    <div class="banner"><span><span class="dot"></span>C backend online · PID ${health.pid} · ${health.users} accounts · ${health.events} audit events</span><span class="badge b-resolved">SYS-OK</span></div>

    <div class="section-title" style="margin:0"><h2>Incident telemetry</h2><span class="mono small muted">SYNC ${fmtTime(Date.now() / 1000)}</span></div>
    <div class="grid g4">
      <div class="card metric"><div class="label">Total lodged ${icon('inbox', 'sm')}</div><div class="value">${stats.total.toLocaleString('en-IN')}</div><div class="foot" style="color:var(--teal-deep)">+${stats.today} today</div></div>
      <div class="card metric"><div class="label">Pending review ${icon('clock', 'sm')}</div><div class="value">${s.Pending + s.Reviewed}</div><div class="foot"><span class="badge plain b-pending">${stats.unassigned} unassigned</span></div></div>
      <div class="card metric"><div class="label">In progress ${icon('wrench', 'sm')}</div><div class="value">${s.Assigned + s['In Progress']}</div><div class="foot"><span class="badge plain b-progress">${stats.overdue} overdue</span></div></div>
      <div class="card metric"><div class="label">Resolved (30d) ${icon('check', 'sm')}</div><div class="value">${stats.resolved_30d}</div><div class="foot"><span class="badge plain b-resolved">${stats.sla_met_pct}% SLA</span>${stats.avg_rating ? ` <span class="small">★ ${stats.avg_rating.toFixed(1)}</span>` : ''}</div></div>
    </div>

    ${stats.escalated ? `<div class="alert"><div class="ic"><b>!</b></div><div class="grow"><div class="row" style="gap:8px"><b style="font-size:16px">${stats.escalated} escalated case${stats.escalated > 1 ? 's' : ''}</b><span class="badge plain b-critical">URGENT</span></div><div class="small muted">Flagged by students or supervisors as stuck or unsafe</div></div><button class="btn danger" id="goEsc">Review ${icon('arrow', 'sm')}</button></div>` : ''}

    <div class="cols">
      <div class="stack">
        <div>
          <div class="section-title" style="flex-wrap:wrap"><h2>${icon('ledger')} Queue registry</h2>
            <div class="tabs">${tabs.map(([k, t]) => `<button data-tab="${k}" class="${k === mgrTab ? 'on' : ''}">${t}</button>`).join('')}</div></div>
          <div class="list">${list.items.length ? list.items.slice(0, 30).map(managerCard).join('') : emptyBox('Nothing in this view.')}</div>
          ${list.items.length > 30 ? `<p class="small muted" style="margin-top:8px">Showing 30 of ${list.count}. <a href="#/list">Open the full list</a></p>` : ''}
        </div>
      </div>
      <div class="stack">
        <div class="card">
          <div class="section-title"><h2>${icon('chart')} Open by category</h2><span class="eyebrow">${stats.open} active</span></div>
          <div class="bars">${stats.by_category.filter((c) => c.open || c.name !== 'Other').map((c, i) => `
            <div class="item"><div class="lbl"><span>${esc(c.name)}</span><span>${stats.open ? Math.round((100 * c.open) / stats.open) : 0}% (${c.open})</span></div>
            <div class="track"><div class="fill" style="width:${(100 * c.open) / maxCat}%;background:${catColors[i % catColors.length]}"></div></div></div>`).join('')}</div>
        </div>
        <div class="grid g2" style="gap:10px">
          <a class="btn" href="/api/export.csv">${icon('download', 'sm')} Export CSV</a>
          ${isAdmin ? `<a class="btn" href="#/users">${icon('userplus', 'sm')} Manage staff</a>` : `<a class="btn" href="#/audit">${icon('ledger', 'sm')} Audit ledger</a>`}
        </div>
        ${last ? `<div class="card" style="background:var(--tint);border-color:var(--tint-2)"><div class="eyebrow" style="color:var(--navy)">Latest audit entry</div>
          <div class="mono small" style="margin-top:6px">${esc(last.actor)} · <b>${esc(last.complaint)}</b> · ${fmtTime(last.at)}</div><div class="small" style="margin-top:4px">${esc(last.text)}</div></div>` : ''}
        <div class="card">
          <div class="section-title"><h2>${icon('users')} Staff workload</h2></div>
          ${state.staff.map((u) => `<div class="row between small" style="padding:6px 0;border-bottom:1px solid var(--line)"><span><b>${esc(u.name)}</b> <span class="muted">· ${esc(u.dept)}</span></span><span class="mono">${u.open_jobs} open</span></div>`).join('') || '<p class="muted small">No active staff accounts.</p>'}
        </div>
      </div>
    </div>
  </div>`, isAdmin ? 'Dispatch, assignment and accounts' : 'Escalations and SLA oversight');

  $app.querySelectorAll('[data-tab]').forEach((b) => (b.onclick = () => { mgrTab = b.dataset.tab; dashManager(); }));
  const ge = $app.querySelector('#goEsc');
  if (ge) ge.onclick = () => { mgrTab = 'escalated'; dashManager(); };
  bindAssign();
  autoRefresh(dashManager);
}

function staffOptions(selectedId) {
  return `<option value="">${selectedId ? 'Reassign…' : 'Assign to…'}</option>` +
    state.staff.map((u) => `<option value="${esc(u.username)}" ${u.id === selectedId ? 'disabled' : ''}>${esc(u.name)} (${esc(u.dept)}) · ${u.open_jobs} open</option>`).join('');
}

function managerCard(c) {
  const sla = slaInfo(c);
  return `<div class="c-card ${c.escalated && c.open ? 'esc' : ''}">
    <div class="bar"><span class="row" style="gap:8px"><a href="#/c/${esc(c.id)}" class="mono small" style="font-weight:700;${c.escalated && c.open ? 'color:var(--rose)' : ''}">${esc(c.id)}</a> ${catBadge(c.category)}</span><span>${statusBadge(c)}</span></div>
    <h3><a href="#/c/${esc(c.id)}" style="color:inherit">${esc(c.title)}</a></h3>
    <div class="meta"><span>${icon('pin', 'sm')} ${esc(c.zone)} · ${esc(c.room)}</span><span>${icon('user', 'sm')} ${esc(c.submitter)}</span><span class="mono" style="${sla.cls === 'over' ? 'color:var(--rose)' : ''}">${sla.text}</span></div>
    <div class="foot"><span>${c.assignee ? `${icon('wrench', 'sm')} ${esc(c.assignee)}` : `<span class="muted">${icon('clock', 'sm')} Unassigned</span>`}</span>
      <span class="row" style="gap:8px">${c.open ? `<select class="assign" data-id="${esc(c.id)}" style="height:30px;width:auto;max-width:220px;font-size:12px">${staffOptions(c.assignee_id)}</select>` : ''}${prioBadge(c.priority)}</span></div>
  </div>`;
}

function bindAssign() {
  $app.querySelectorAll('select.assign').forEach((sel) => (sel.onchange = async () => {
    if (!sel.value) return;
    try {
      const c = await api('POST', `/complaints/${sel.dataset.id}/assign`, { staff: sel.value });
      toast(`${c.id} → ${c.assignee}`);
      router();
    } catch (e) {
      toast(e.message, true);
      sel.value = '';
    }
  }));
}

/* ---------- lodge complaint ---------- */

async function viewNew() {
  const draft = (() => { try { return JSON.parse(localStorage.getItem('cms_draft') || '{}'); } catch { return {}; } })();
  let cat = draft.category || 'Hostel Maintenance';
  let prio = draft.priority || 'Medium';

  renderShell('Lodge new complaint', `
  <form id="newForm" class="stack" style="max-width:820px">
    <div class="card row between wrap">
      <div><span class="mono small muted">PROTOCOL CMP-REQ</span><h2 style="font-size:20px;margin-top:4px">Lodge new incident / complaint</h2>
      <p class="small muted">You'll get a tracking ID (CMP-YYYY-NNN) as soon as it's submitted.</p></div>
      <span class="badge b-resolved">LEDGER ONLINE</span>
    </div>

    <div class="card">
      <div class="row between" style="margin-bottom:12px"><span class="eyebrow">1. Category & classification</span><span class="mono small muted">REQ-FIELD</span></div>
      <div class="tiles" id="cats">${Object.keys(SUBCATS).map((k) => `<button type="button" class="tile ${k === cat ? 'on' : ''}" data-cat="${esc(k)}">${icon(CAT_ICON[k])} ${esc(k)}</button>`).join('')}</div>
      <div class="f-row" style="margin-top:14px"><label class="f" for="sub">Sub-category / issue type</label><select id="sub" name="subcategory"></select></div>
      <div class="f-row"><div class="row between"><label class="f" for="title">Complaint subject <span class="req">*</span></label><span class="counter" id="tCount">0 / 120</span></div>
        <input id="title" name="title" type="text" required minlength="5" maxlength="120" placeholder="e.g. Water leakage in Block-B 3rd floor washroom" value="${esc(draft.title || '')}"></div>
      <div class="f-row" style="margin:0"><div class="row between"><label class="f" for="desc">Detailed description <span class="req">*</span></label><span class="counter" id="dCount">0 / 1000</span></div>
        <textarea id="desc" name="description" required minlength="10" maxlength="1000" placeholder="What's wrong, since when, and anything that makes it unsafe.">${esc(draft.description || '')}</textarea>
        <div class="hint">${icon('alert', 'sm')} Mention the wing, floor and landmarks, plus any immediate safety hazard.</div></div>
    </div>

    <div class="card">
      <div class="row between" style="margin-bottom:12px"><span class="eyebrow">2. Location</span><span class="mono small muted">LOC-MAP</span></div>
      <div class="grid g2">
        <div class="f-row" style="margin:0"><label class="f" for="zone">Campus zone / facility <span class="req">*</span></label>
          <select id="zone" name="zone" required>${ZONES.map((z) => `<option ${z === draft.zone ? 'selected' : ''}>${esc(z)}</option>`).join('')}</select></div>
        <div class="f-row" style="margin:0"><label class="f" for="room">Exact room / wing / landmark <span class="req">*</span></label>
          <div class="input-icon">${icon('pin')}<input id="room" name="room" type="text" required maxlength="120" placeholder="3rd floor east wing, near Lab 304" value="${esc(draft.room || '')}"></div></div>
      </div>
    </div>

    <div class="card">
      <div class="row between" style="margin-bottom:12px"><span class="eyebrow">3. Priority & impact</span><span class="mono small muted" style="color:var(--teal-deep)">SLA CONTRACT</span></div>
      <div class="tiles" id="prios" style="grid-template-columns:repeat(4,minmax(0,1fr))">${PRIOS.map((p) => `<button type="button" class="tile ${p.name === prio ? 'on' : ''}" data-prio="${p.name}"><span>${p.name}<small>${p.sla < 24 ? `Dispatch &lt; ${p.sla}h` : `${p.sla}h SLA`}</small></span><span class="dot" style="background:${p.dot}"></span></button>`).join('')}</div>
      <p class="hint small muted" style="margin-top:8px">Critical is for safety hazards only (exposed wiring, flooding, structural damage). Misuse gets downgraded by the desk.</p>
    </div>

    <div class="card">
      <label class="check"><input type="checkbox" name="anonymous" value="1" ${draft.anonymous ? 'checked' : ''}>
        <span><b>Keep this anonymous</b><br><span class="small muted">Staff and the admin desk won't see your name. Only senior supervisors can, if there's a safety follow-up.</span></span></label>
    </div>

    <div id="newErr"></div>
    <button class="btn primary block lg">Submit & generate token (CMP-ID) ${icon('arrow')}</button>
    <div class="grid g2" style="gap:10px"><button type="button" class="btn" id="saveDraft">Save as draft</button><button type="button" class="btn danger" id="discard">Cancel & discard</button></div>
  </form>`, 'Goes straight to the estate dispatch desk');

  const form = $app.querySelector('#newForm');
  const subSel = $app.querySelector('#sub');
  const fillSubs = () => {
    subSel.innerHTML = SUBCATS[cat].map((s) => `<option ${s === draft.subcategory ? 'selected' : ''}>${esc(s)}</option>`).join('');
  };
  fillSubs();
  $app.querySelectorAll('[data-cat]').forEach((b) => (b.onclick = () => {
    cat = b.dataset.cat;
    $app.querySelectorAll('[data-cat]').forEach((x) => x.classList.toggle('on', x === b));
    fillSubs();
  }));
  $app.querySelectorAll('[data-prio]').forEach((b) => (b.onclick = () => {
    prio = b.dataset.prio;
    $app.querySelectorAll('[data-prio]').forEach((x) => x.classList.toggle('on', x === b));
  }));
  const count = (el, out, max) => { const f = () => (out.textContent = `${el.value.length} / ${max}`); el.oninput = f; f(); };
  count($app.querySelector('#title'), $app.querySelector('#tCount'), 120);
  count($app.querySelector('#desc'), $app.querySelector('#dCount'), 1000);

  const collect = () => ({ ...Object.fromEntries(new FormData(form).entries()), category: cat, priority: prio });
  $app.querySelector('#saveDraft').onclick = () => {
    try { localStorage.setItem('cms_draft', JSON.stringify(collect())); toast('Draft saved on this browser.'); } catch { toast('Could not save the draft here.', true); }
  };
  $app.querySelector('#discard').onclick = () => {
    try { localStorage.removeItem('cms_draft'); } catch { /* ignore */ }
    location.hash = '#/home';
  };
  form.onsubmit = async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button.primary');
    btn.disabled = true;
    try {
      const c = await api('POST', '/complaints', collect());
      try { localStorage.removeItem('cms_draft'); } catch { /* ignore */ }
      toast(`Lodged. Your tracking ID is ${c.id}`);
      location.hash = `#/c/${c.id}`;
    } catch (err) {
      $app.querySelector('#newErr').innerHTML = `<div class="err">${esc(err.message)}</div>`;
      btn.disabled = false;
    }
  };
}

/* ---------- complaint detail / tracking ---------- */

function stageTimes(c) {
  /* when did each stage happen, according to the event log */
  const t = { 1: c.created };
  for (const e of c.events) {
    if (e.kind === 'assign') t[3] = t[3] || e.at;
    const m = e.kind === 'status' && e.text.match(/^Status changed to ([^:]+)/);
    if (m) {
      const idx = STAGES.indexOf(m[1] === 'Pending' ? 'Logged' : m[1]);
      if (idx >= 0) t[idx + 1] = e.at;
    }
  }
  return t;
}

async function viewComplaint(id) {
  const c = await api('GET', `/complaints/${id}`);
  const me = state.me;
  const mgr = me.role === 'admin' || me.role === 'supervisor';
  const mine = c.submitter_username === me.username;
  const isAssignee = c.assignee_username === me.username;
  if (mgr && !state.staff.length) state.staff = (await api('GET', '/users?role=staff')).items.filter((u) => u.active);

  const sla = slaInfo(c);
  const times = stageTimes(c);
  const descs = [
    `Lodged by <b>${esc(c.submitter)}</b>${c.submitter_username ? ` <span class="mono muted">(${esc(c.submitter_username)})</span>` : ''}.`,
    'Checked and categorised by the dispatch desk.',
    c.assignee ? `Assigned to <b>${esc(c.assignee)}</b> <span class="mono muted">(${esc(c.assignee_username)})</span>.` : 'Waiting for a staff member to be assigned.',
    'Technician on site / work under way.',
    c.status === 'Rejected' ? 'Closed without action by the desk.' : 'Fixed and signed off.',
  ];
  const timeline = STAGES.map((name, i) => {
    const n = i + 1;
    const done = n < c.stage || (n === c.stage && !c.open);
    const cur = n === c.stage && c.open;
    const cls = done ? 'done' : cur ? 'cur' : 'todo';
    const label = n === 5 && c.status === 'Rejected' ? 'Rejected' : name;
    const t = times[n] ? `${fmtTime(times[n])}` : n === 5 && c.open ? `est. ${fmtTime(c.deadline)}` : '';
    return `<li class="${cls}"><span class="node">${done ? icon('check', 'sm') : cur ? icon('wrench', 'sm') : icon('clock', 'sm')}</span>
      <div class="box"><div class="head"><span>${n}. ${label}${cur ? ' <span style="color:var(--navy)">●</span>' : ''}</span><time>${t}</time></div><div class="sub">${descs[i]}</div></div></li>`;
  }).join('');

  const feedIcon = { status: 'track', note: 'note', assign: 'user', escalate: 'alert', rating: 'star', created: 'plus' };
  const feed = c.events.slice().reverse().map((e) => `<li><span class="ic ${esc(e.kind)}">${icon(feedIcon[e.kind] || 'note', 'sm')}</span>
    <div><span class="who"><b>${esc(e.actor)}</b> · ${esc(e.actor_role)} · ${fmtDate(e.at)}</span><div class="txt">${esc(e.text)}</div></div></li>`).join('');

  /* who can do what - mirrors the server rules, the server checks again anyway */
  const actions = [];
  if (isAssignee && c.status === 'Assigned') actions.push(`<button class="btn primary" data-do="accept">${icon('check', 'sm')} Accept task</button>`);
  if (isAssignee && c.status === 'In Progress') actions.push(`<button class="btn primary" data-do="resolve">${icon('check', 'sm')} Mark resolved</button>`);
  if (c.open && (mine || mgr) && !c.escalated && me.role !== 'staff') actions.push(`<button class="btn danger" data-do="escalate">${icon('alert', 'sm')} Request escalation</button>`);
  if (c.open && mgr && c.escalated) actions.push(`<button class="btn" data-do="deescalate">Clear escalation</button>`);

  renderShell(c.id, `
  <div class="row between no-print" style="margin-bottom:14px">
    <a href="#/list" class="small">${icon('back', 'sm')} Back to queue</a>
    <span class="row" style="gap:6px"><button class="btn sm" id="copy" title="Copy ID">Copy ID</button><button class="btn sm" onclick="window.print()">${icon('print', 'sm')} Print</button></span>
  </div>
  <div class="cols">
    <div class="stack">
      <div class="card">
        <div class="row wrap" style="gap:8px">${idBadge(c.id)} ${statusBadge(c)} <span class="badge plain b-${c.priority.toLowerCase()}">${esc(c.priority)} priority</span>${c.anonymous ? ' <span class="badge plain b-rejected">Anonymous</span>' : ''}</div>
        <h2 style="font-size:20px;margin:12px 0 6px">${esc(c.title)}</h2>
        <div class="row wrap small muted">${catBadge(c.category)}<span>${esc(c.subcategory)}</span><span>· ${fmtDate(c.created)}</span></div>
        <div class="sla" style="margin-top:14px"><span>${icon('clock', 'sm')} <b>Target resolution:</b> ${c.priority} (${c.sla_hours}h window) · due ${fmtDate(c.deadline)}</span><span class="left ${sla.cls}">${sla.text}</span></div>
      </div>

      <div class="card">
        <div class="section-title"><h2>${icon('track')} Lifecycle timeline</h2><span class="eyebrow" style="color:var(--teal-deep)">Stage ${c.stage} of 5</span></div>
        <ol class="timeline">${timeline}</ol>
      </div>

      <div class="card">
        <div class="section-title"><h2>${icon('note')} Details</h2></div>
        <p style="white-space:pre-wrap">${esc(c.description)}</p>
        <div class="person" style="margin-top:12px"><div class="avatar" style="background:var(--tint-2);color:var(--navy)">${icon('pin', 'sm')}</div><div class="grow"><b>${esc(c.zone)}</b><span>${esc(c.room)}</span></div></div>
      </div>

      <div class="card">
        <div class="section-title"><h2>${icon('ledger')} Activity & notes</h2><span class="eyebrow">${c.events.length} entries</span></div>
        <ul class="feed">${feed}</ul>
        <form id="noteForm" class="no-print" style="margin-top:14px">
          <label class="f" for="nt">Post a clarification note</label>
          <textarea id="nt" name="text" maxlength="480" required minlength="2" placeholder="${me.role === 'student' ? 'Extra room details, a better time for the visit…' : 'Progress update, parts needed, findings…'}" style="min-height:70px"></textarea>
          <button class="btn soft" style="margin-top:8px">${icon('note', 'sm')} Add note</button>
        </form>
      </div>
    </div>

    <div class="stack">
      <div class="card">
        <div class="row between"><span class="eyebrow">Dispatched field specialist</span>${c.assignee ? `<span class="badge b-resolved">${c.status === 'In Progress' ? 'ON SITE' : c.open ? 'ASSIGNED' : 'DONE'}</span>` : ''}</div>
        ${c.assignee ? `<div class="person" style="background:none;padding:12px 0 4px"><div class="avatar lg">${esc(initials(c.assignee))}</div>
          <div class="grow"><b style="font-size:16px">${esc(c.assignee)}</b><span>${esc(c.assignee_dept)}</span><div class="mono small muted">ID: ${esc(c.assignee_username)}</div></div></div>
          ${c.assignee_phone ? `<a class="btn soft block" href="tel:${esc(c.assignee_phone)}" style="margin-top:10px">${icon('phone', 'sm')} ${esc(c.assignee_phone)}</a>` : ''}`
          : `<p class="muted small" style="margin-top:10px">Nobody yet. The dispatch desk assigns new complaints during working hours.</p>`}
        ${mgr && c.open ? `<div class="f-row" style="margin:12px 0 0"><label class="f">Assign / reassign</label><select class="assign" data-id="${esc(c.id)}">${staffOptions(c.assignee_id)}</select></div>` : ''}
      </div>

      ${actions.length ? `<div class="card no-print"><div class="eyebrow" style="margin-bottom:10px">Actions</div><div class="stack" style="gap:8px">${actions.join('')}</div></div>` : ''}

      ${mgr ? `<form class="card no-print" id="statusForm"><div class="eyebrow" style="margin-bottom:10px">Change status</div>
        <div class="f-row"><select name="status">${['Pending', 'Reviewed', 'Assigned', 'In Progress', 'Resolved', 'Rejected'].map((s) => `<option ${s === c.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
        <div class="f-row"><input type="text" name="note" maxlength="300" placeholder="Reason / note (optional)"></div>
        <button class="btn primary block">Update status</button></form>` : ''}

      ${mine && c.status === 'Resolved' ? `<div class="card no-print"><div class="eyebrow" style="margin-bottom:8px">Rate the resolution</div>
        ${c.rating ? `<div class="stars">${[1, 2, 3, 4, 5].map((n) => `<span class="${n <= c.rating ? 'on' : ''}">${icon('star')}</span>`).join('')}</div><p class="small muted">Thanks for the feedback.</p>`
          : `<div class="stars" id="stars">${[1, 2, 3, 4, 5].map((n) => `<button data-star="${n}" aria-label="${n} star">${icon('star')}</button>`).join('')}</div><p class="small muted">How happy are you with the fix?</p>`}</div>` : ''}

      <div class="card" style="background:var(--tint);border-color:var(--tint-2)">
        <div class="eyebrow">Reported by</div>
        <div style="margin-top:6px"><b>${esc(c.submitter)}</b>${c.submitter_dept ? `<div class="small muted">${esc(c.submitter_dept)}</div>` : ''}</div>
        <div class="mono small muted" style="margin-top:8px">Last update ${ago(c.updated)}</div>
      </div>
    </div>
  </div>`, `${c.category} · ${c.zone}`);

  const reload = () => viewComplaint(id);
  $app.querySelector('#copy').onclick = () => { navigator.clipboard?.writeText(c.id); toast('Copied ' + c.id); };
  $app.querySelector('#noteForm').onsubmit = async (e) => {
    e.preventDefault();
    try { await api('POST', `/complaints/${id}/note`, { text: e.target.text.value }); toast('Note added.'); reload(); } catch (err) { toast(err.message, true); }
  };
  const sf = $app.querySelector('#statusForm');
  if (sf) sf.onsubmit = async (e) => {
    e.preventDefault();
    try { await api('POST', `/complaints/${id}/status`, Object.fromEntries(new FormData(sf).entries())); toast('Status updated.'); reload(); } catch (err) { toast(err.message, true); }
  };
  $app.querySelectorAll('[data-star]').forEach((b) => {
    b.onmouseenter = () => $app.querySelectorAll('[data-star]').forEach((x) => x.classList.toggle('on', +x.dataset.star <= +b.dataset.star));
    b.onclick = async () => {
      try { await api('POST', `/complaints/${id}/rate`, { stars: b.dataset.star }); toast('Thanks for rating!'); reload(); } catch (err) { toast(err.message, true); }
    };
  });
  $app.querySelectorAll('[data-do]').forEach((b) => (b.onclick = async () => {
    try {
      const act = b.dataset.do;
      if (act === 'accept') await api('POST', `/complaints/${id}/status`, { status: 'In Progress', note: 'Accepted, heading to site' });
      if (act === 'resolve') {
        const v = await ask({ title: 'Mark as resolved', label: 'What was done?', confirm: 'Mark resolved' });
        if (!v) return;
        await api('POST', `/complaints/${id}/status`, { status: 'Resolved', note: v.v });
      }
      if (act === 'escalate') {
        const v = await ask({ title: 'Request immediate escalation', text: 'Use this when it is unsafe or has been stuck way past the SLA. Supervisors get alerted.', label: 'Why does this need escalating?', confirm: 'Escalate' });
        if (!v) return;
        await api('POST', `/complaints/${id}/escalate`, { reason: v.v });
      }
      if (act === 'deescalate') {
        const v = await ask({ title: 'Clear escalation', label: 'Note (optional)', required: false, confirm: 'Clear' });
        if (!v) return;
        await api('POST', `/complaints/${id}/deescalate`, { reason: v.v });
      }
      toast('Done.');
      reload();
    } catch (err) {
      toast(err.message, true);
    }
  }));
  bindAssign();
  autoRefresh(reload);
}

/* ---------- full list ---------- */

const listFilter = { status: '', category: '', q: '' };

async function viewList() {
  const me = state.me;
  const mgr = me.role === 'admin' || me.role === 'supervisor';
  const params = new URLSearchParams({ sort: me.role === 'student' ? 'new' : 'sla' });
  for (const [k, v] of Object.entries(listFilter)) if (v) params.set(k, v);
  const [list] = await Promise.all([api('GET', '/complaints?' + params), mgr && !state.staff.length
    ? api('GET', '/users?role=staff').then((r) => (state.staff = r.items.filter((u) => u.active))) : null]);
  const title = { student: 'My complaints', staff: 'My work queue', admin: 'All complaints', supervisor: 'All complaints' }[me.role];

  const rows = list.items.map((c) => {
    const sla = slaInfo(c);
    return `<tr><td><a class="mono" href="#/c/${esc(c.id)}" style="font-weight:600">${esc(c.id)}</a></td>
      <td><a href="#/c/${esc(c.id)}" style="color:inherit">${esc(c.title)}</a><div class="small muted">${esc(c.zone)} · ${esc(c.room)}</div></td>
      <td class="small">${esc(c.category)}</td><td>${prioBadge(c.priority)}</td><td>${statusBadge(c)}</td>
      <td class="small">${c.assignee ? esc(c.assignee) : '<span class="muted">—</span>'}</td>
      <td class="r mono small" style="${sla.cls === 'over' ? 'color:var(--rose)' : ''}">${sla.text}</td></tr>`;
  }).join('');

  renderShell(title, `
  <div class="card row wrap" style="margin-bottom:16px;gap:10px">
    <div class="input-icon" style="flex:1;min-width:200px">${icon('search')}<input type="search" id="q" placeholder="Search ID, title, room…" value="${esc(listFilter.q)}"></div>
    <select id="fs" style="width:auto"><option value="">Any status</option><option value="open" ${listFilter.status === 'open' ? 'selected' : ''}>Open only</option>${['Pending', 'Reviewed', 'Assigned', 'In Progress', 'Resolved', 'Rejected'].map((s) => `<option ${s === listFilter.status ? 'selected' : ''}>${s}</option>`).join('')}</select>
    <select id="fc" style="width:auto"><option value="">Any category</option>${Object.keys(SUBCATS).map((k) => `<option ${k === listFilter.category ? 'selected' : ''}>${esc(k)}</option>`).join('')}</select>
    ${me.role !== 'staff' ? `<a class="btn primary" href="#/new">${icon('plus', 'sm')} New</a>` : ''}
    ${mgr ? `<a class="btn" href="/api/export.csv">${icon('download', 'sm')} CSV</a>` : ''}
  </div>
  <p class="small muted" style="margin-bottom:8px">${list.count} result${list.count === 1 ? '' : 's'}</p>
  ${list.items.length ? `<div class="t-wrap hide-sm"><table class="t"><thead><tr><th>ID</th><th>Subject</th><th>Category</th><th>Priority</th><th>Status</th><th>Assignee</th><th class="r">SLA</th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="list show-sm">${list.items.map((c) => complaintCard(c)).join('')}</div>` : emptyBox('No complaints match these filters.')}`);

  let deb;
  $app.querySelector('#q').oninput = (e) => { clearTimeout(deb); deb = setTimeout(() => { listFilter.q = e.target.value.trim(); viewList().then(() => { const q = $app.querySelector('#q'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }); }, 300); };
  $app.querySelector('#fs').onchange = (e) => { listFilter.status = e.target.value; viewList(); };
  $app.querySelector('#fc').onchange = (e) => { listFilter.category = e.target.value; viewList(); };
  autoRefresh(viewList, 30000);
}

/* ---------- admin: accounts ---------- */

async function viewUsers() {
  if (state.me.role !== 'admin') { location.hash = '#/home'; return; }
  const { items } = await api('GET', '/users');
  const rows = items.map((u) => `<tr>
    <td><b>${esc(u.name)}</b><div class="mono small muted">${esc(u.username)}</div></td>
    <td><span class="badge plain b-id">${esc(u.role)}</span></td><td class="small">${esc(u.dept)}</td><td class="small mono">${esc(u.phone)}</td>
    <td class="r mono small">${u.role === 'staff' ? `${u.open_jobs} / ${u.resolved_jobs}` : ''}</td>
    <td>${u.active ? '<span class="badge b-resolved">active</span>' : '<span class="badge b-rejected">disabled</span>'}</td>
    <td class="r" style="white-space:nowrap">${u.id === state.me.id ? '<span class="small muted">you</span>' : `
      <button class="btn sm" data-reset="${u.id}" data-name="${esc(u.name)}">Reset password</button>
      <button class="btn sm ${u.active ? 'danger' : ''}" data-toggle="${u.id}" data-active="${u.active ? 0 : 1}">${u.active ? 'Disable' : 'Enable'}</button>`}</td></tr>`).join('');

  renderShell('Manage accounts', `
  <div class="cols">
    <div class="t-wrap"><table class="t"><thead><tr><th>Name</th><th>Role</th><th>Department</th><th>Phone</th><th class="r">Open / done</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    <form class="card" id="userForm">
      <h3 style="font-size:16px;margin-bottom:12px">${icon('userplus')} Create account</h3>
      <div class="f-row"><label class="f">Role</label><select name="role"><option value="staff">Staff / officer</option><option value="student">Student</option><option value="supervisor">Supervisor</option><option value="admin">Admin</option></select></div>
      <div class="f-row"><label class="f">Login ID <span class="req">*</span></label><input type="text" name="username" required minlength="3" maxlength="30" placeholder="OP-512"></div>
      <div class="f-row"><label class="f">Full name <span class="req">*</span></label><input type="text" name="name" required maxlength="60"></div>
      <div class="f-row"><label class="f">Department / unit</label><input type="text" name="dept" maxlength="90" placeholder="Electrical & Power"></div>
      <div class="f-row"><label class="f">Phone</label><input type="text" name="phone" maxlength="30"></div>
      <div class="f-row"><label class="f">Initial password <span class="req">*</span></label><input type="text" name="password" required minlength="6"></div>
      <button class="btn primary block">Create</button>
    </form>
  </div>`, `${items.length} accounts`);

  $app.querySelector('#userForm').onsubmit = async (e) => {
    e.preventDefault();
    try { const u = await api('POST', '/users', Object.fromEntries(new FormData(e.target).entries())); toast(`Created ${u.username}`); state.staff = []; viewUsers(); } catch (err) { toast(err.message, true); }
  };
  $app.querySelectorAll('[data-toggle]').forEach((b) => (b.onclick = async () => {
    try { await api('POST', `/users/${b.dataset.toggle}/active`, { active: b.dataset.active }); state.staff = []; viewUsers(); } catch (err) { toast(err.message, true); }
  }));
  $app.querySelectorAll('[data-reset]').forEach((b) => (b.onclick = async () => {
    const p = prompt(`New password for ${b.dataset.name} (6+ characters):`);
    if (!p) return;
    try { await api('POST', `/users/${b.dataset.reset}/password`, { password: p }); toast('Password reset. Their old sessions were signed out.'); } catch (err) { toast(err.message, true); }
  }));
}

/* ---------- audit ---------- */

async function viewAudit() {
  if (!['admin', 'supervisor'].includes(state.me.role)) { location.hash = '#/home'; return; }
  const { items } = await api('GET', '/audit?limit=200');
  renderShell('Audit ledger', `
  <div class="t-wrap"><table class="t"><thead><tr><th>Time</th><th>Complaint</th><th>Who</th><th>Event</th><th>Detail</th></tr></thead><tbody>
  ${items.map((e) => `<tr><td class="mono small" style="white-space:nowrap">${fmtDate(e.at)}</td><td><a class="mono small" href="#/c/${esc(e.complaint)}">${esc(e.complaint)}</a></td>
    <td class="small"><b>${esc(e.actor)}</b><div class="muted">${esc(e.actor_role)}</div></td><td><span class="badge plain b-id">${esc(e.kind)}</span></td><td class="small">${esc(e.text)}</td></tr>`).join('')}
  </tbody></table></div>`, 'Every change, newest first. The full log lives in data/events.db on the server.');
  autoRefresh(viewAudit, 30000);
}

/* ---------- account ---------- */

async function viewAccount() {
  const me = state.me;
  renderShell('Account', `
  <div class="grid g2" style="max-width:820px">
    <div class="card">
      <div class="row"><div class="avatar lg">${esc(initials(me.name))}</div><div><h2 style="font-size:18px">${esc(me.name)}</h2><div class="mono small muted">${esc(me.username)} · ${esc(me.role)}</div><div class="small">${esc(me.dept)}</div></div></div>
      <button class="btn danger block" id="out" style="margin-top:16px">${icon('logout', 'sm')} Sign out</button>
    </div>
    <form class="card" id="pwForm">
      <h3 style="font-size:16px;margin-bottom:12px">${icon('lock')} Change password</h3>
      <div class="f-row"><label class="f">Current password</label><input type="password" name="old" required autocomplete="current-password"></div>
      <div class="f-row"><label class="f">New password</label><input type="password" name="new" required minlength="6" autocomplete="new-password"></div>
      <button class="btn primary">Update password</button>
    </form>
  </div>`);
  $app.querySelector('#out').onclick = logout;
  $app.querySelector('#pwForm').onsubmit = async (e) => {
    e.preventDefault();
    try { await api('POST', '/password', Object.fromEntries(new FormData(e.target).entries())); toast('Password changed.'); e.target.reset(); } catch (err) { toast(err.message, true); }
  };
}

router();
