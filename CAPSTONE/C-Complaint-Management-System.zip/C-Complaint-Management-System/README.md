# Campus Complaint Management System

A multi-user, network-based complaint system written in C. Students report problems around campus, the admin desk assigns them to staff, staff fix them, and everyone follows the same complaint through a five-stage timeline until it's closed.

The server is plain C: POSIX sockets, one pthread per connection, and flat-file storage. It serves a web UI built from the Stitch designs in `design/` and a JSON API. A separate C terminal client uses that same API, so browsers and terminals can work on the same data at the same time.

## Build and run

You need `gcc` and `make` on Linux, macOS or WSL. There are no other dependencies.

```bash
make
```

```bash
./cms_server -p 8080
```

Then open http://localhost:8080 in a browser. Other machines on the same network can use `http://<server-ip>:8080`.

To use the terminal client, run this in another window (or on another machine):

```bash
./cms_client 127.0.0.1 8080
```

On the first start the server creates these demo accounts and a few sample complaints:

| Role       | ID          | Password     |
|------------|-------------|--------------|
| Student    | `CS2023084` | `student123` |
| Student    | `EC2024017` | `student123` |
| Staff      | `OP-408`    | `staff123`   |
| Staff      | `OP-215`    | `staff123`   |
| Staff      | `OP-330`    | `staff123`   |
| Admin      | `admin`     | `admin123`   |
| Supervisor | `super01`   | `super123`   |

`make reset-data` wipes everything, and the next start seeds the demo data again.

Server options: `-p` sets the port (default 8080), `-d` the data folder (default `data`) and `-w` the web folder (default `web`).

## Live deployment (Vercel)

https://c-complaint-management-system.vercel.app

Vercel can't keep a socket server running, so on Vercel the same C code runs in one-shot mode: `cms_server -1` reads a single HTTP request on stdin, writes the response to stdout, and exits. A small Node function, `deploy/vercel/api/index.js`, starts it once for each `/api` call. The web UI is served as static files.

Vercel's disk doesn't last between requests, so the three `.db` files are kept together in a private Vercel Blob. Each request downloads the latest copy (warm instances skip the download if nothing has changed), runs the C binary on it, and saves any changes with a conditional write tied to the version it started from. If another request saved first, the write is refused and the whole request runs again on the fresh data, so simultaneous users never overwrite each other. In testing, 15 simultaneous writes to one complaint all landed exactly once.

Logins use signed tokens (HMAC-SHA256 over the user id, the expiry and the password salt) instead of a session table, because each request runs in a fresh process. The signing key is the `CMS_SECRET` environment variable. Changing a password makes every older token for that account invalid.

To redeploy:

```bash
make vercel
```

```bash
cd deploy/vercel && npx vercel deploy --prod
```

`make vercel` builds a statically linked binary, so it runs on Vercel's Linux image, and copies the web UI into `deploy/vercel/public`. The Vercel project needs a private Blob store connected (which provides `BLOB_READ_WRITE_TOKEN`) and a `CMS_SECRET` of at least 16 characters.

## Who can do what

| | Student | Staff | Admin | Supervisor |
|---|:-:|:-:|:-:|:-:|
| Lodge a complaint | ✓ | ✓ | ✓ | ✓ |
| See complaints | own | assigned to them | all | all |
| Add notes | ✓ | ✓ | ✓ | ✓ |
| Accept / mark resolved | | ✓ (own jobs) | ✓ | ✓ |
| Any status change, reject | | | ✓ | ✓ |
| Assign / reassign staff | | | ✓ | ✓ |
| Escalate | own | | ✓ | ✓ |
| Rate the fix | own, once resolved | | | |
| Audit ledger, CSV export | | | ✓ | ✓ |
| Create / disable accounts | | | ✓ | |
| See who filed an anonymous complaint | own | | | ✓ |

The server checks every one of these rules itself, whatever the UI shows. A student who asks for someone else's complaint gets the same "not found" as for an ID that doesn't exist, so IDs can't be probed.

## Complaint lifecycle

```
Pending → Reviewed → Assigned → In Progress → Resolved
                                     └──────→ Rejected (closed without action)
```

Each priority comes with a resolution deadline (SLA): Low 72 h, Medium 48 h, High 24 h, Critical 4 h. Dashboards count down to the deadline and flag anything overdue. The admin dashboard also shows what share of complaints resolved in the last 30 days met their deadline.

Escalation is a flag, not a separate status. An escalated complaint keeps its place in the workflow, but it jumps to the top of the queues and gets a red marker until it's resolved or a supervisor clears the flag.

## Project layout

```
server/
  main.c      socket setup, accept loop, one detached thread per client
  http.c      minimal HTTP/1.1 parsing, static files, form decoding
  api.c       sessions, permission checks, every /api endpoint
  store.c     in-memory tables + persistence to data/*.db
  sha256.c    SHA-256 for password hashing (no OpenSSL needed)
  sbuf.c      growable string buffer used to build JSON
client/
  cms_client.c  interactive terminal client (menus per role)
web/
  index.html, style.css, app.js   single-page UI, no build step
design/       the original Stitch screens and design spec
data/         created at runtime
```

## How it works

**Concurrency (local server).** `accept()` hands each connection to its own detached thread. All shared data sits behind one mutex. A handler takes the lock, does its work, builds the reply in memory, and releases the lock before writing to the socket, so a slow client can't hold anyone else up. Each socket has a 15-second timeout, so an idle connection can't keep a thread busy forever. In testing, 40 clients sending 400 complaints in parallel all got unique IDs and nothing was lost.

**Storage.** Data lives in three tab-separated text files under `data/`:

- `users.db` is rewritten whenever an account changes.
- `complaints.db` is rewritten whenever a complaint changes.
- `events.db` is append-only and serves as the timeline and audit trail.

A rewrite goes to a temp file, gets `fsync`ed, and is then `rename`d over the old file, so a crash mid-save never leaves a half-written database. The files are human-readable, which helps when you're debugging or explaining the project.

**Auth.** Passwords are salted, hashed with SHA-256, and re-hashed 5,000 times. Password checks compare every byte, so timing doesn't reveal how much of a guess was right. Logging in issues a token signed with HMAC-SHA256: the user id, an expiry 8 hours out, and a signature over both plus the user's password salt. The browser stores it as an `HttpOnly; SameSite=Strict` cookie, and the terminal client sends it as `Authorization: Bearer <token>`. Resetting a password invalidates all of that user's older tokens, and disabled accounts are refused straight away. Set `CMS_SECRET` to keep logins valid across server restarts; without it, the server makes a new random key each time it starts.

**Input handling.** Request bodies are form-encoded (`a=1&b=2`) because that's easy to parse safely in C. Every field is bounds-checked and copied with a function that always terminates the string. The server refuses headers over 8 KB, bodies over 64 KB, and any path containing `..`. CSV export neutralises cells that start with `=`, `+`, `-` or `@` so spreadsheet programs won't run them as formulas.

## API quick reference

Every endpoint lives under `/api`, takes a form-encoded body, and returns JSON.

```
POST /login            username, password, [role], [remember=1]
POST /register         username, name, dept, password   (students only)
POST /logout
GET  /me
POST /password         old, new
GET  /health           pid, uptime, counts (public)

GET  /complaints       ?status=&category=&escalated=1&q=&sort=sla&scope=mine
POST /complaints       title, category, subcategory, description, zone, room, priority, anonymous
GET  /complaints/:id   full record + timeline (id is CMP-2026-007 or just 7)
POST /complaints/:id/status      status, note
POST /complaints/:id/assign      staff (login id)
POST /complaints/:id/note        text
POST /complaints/:id/escalate    reason
POST /complaints/:id/deescalate  [reason]
POST /complaints/:id/rate        stars (1-5), [comment]

GET  /stats            counts by status/category, SLA %, average rating
GET  /audit            ?limit=50
GET  /export.csv
GET  /users            ?role=staff
POST /users            username, name, role, dept, phone, password   (admin)
POST /users/:id/active    active=0|1   (admin)
POST /users/:id/password  password     (admin)
```

You can try it with curl:

```bash
curl -c jar -d "username=admin&password=admin123" localhost:8080/api/login
```

```bash
curl -b jar "localhost:8080/api/complaints?escalated=1"
```

## Known limits

- Logging out clears the token on that device, but a copied token stays valid until it expires (at most 8 hours) or the password changes. That's the trade-off of signed tokens.
- The standalone server speaks plain HTTP. To put it on the open internet yourself, run it behind a reverse proxy that handles TLS (nginx, Caddy). The Vercel deployment already uses HTTPS.
- One request per connection (no keep-alive). That's fine at campus scale, but it isn't built for thousands of requests per second.
- Table sizes are fixed at compile time: 1,024 users and 8,192 complaints. Change them in `server/store.h`.
- The design's photo or evidence upload isn't implemented. Notes on the timeline take its place.
