/*
 * Campus CMS - terminal client
 *
 *   ./cms_client [host] [port]        (defaults: 127.0.0.1 8080)
 *
 * Talks to cms_server over plain TCP using the same HTTP/JSON API as the web
 * UI, so you can lodge and work on complaints from a lab terminal. Several
 * clients (and browsers) can be connected at once.
 */
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static char host[256] = "127.0.0.1";
static char port[8] = "8080";
static char token[80];
static char my_name[96], my_role[24], my_id[48];

/* ---------- networking ---------- */

static int connect_server(void)
{
    struct addrinfo hints = {0}, *res, *rp;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    int rc = getaddrinfo(host, port, &hints, &res);
    if (rc != 0) {
        fprintf(stderr, "cannot resolve %s: %s\n", host, gai_strerror(rc));
        return -1;
    }
    int fd = -1;
    for (rp = res; rp; rp = rp->ai_next) {
        fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (fd < 0)
            continue;
        if (connect(fd, rp->ai_addr, rp->ai_addrlen) == 0)
            break;
        close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    if (fd < 0)
        fprintf(stderr, "cannot connect to %s:%s (%s). Is cms_server running?\n", host, port, strerror(errno));
    return fd;
}

/* Percent-encodes s onto the end of out (form encoding). */
static void enc_append(char *out, size_t n, const char *s)
{
    size_t o = strlen(out);
    for (; *s && o + 4 < n; s++) {
        unsigned char c = (unsigned char)*s;
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~')
            out[o++] = (char)c;
        else if (c == ' ')
            out[o++] = '+';
        else
            o += (size_t)sprintf(out + o, "%%%02X", c);
    }
    out[o] = '\0';
}

/* Builds "k1=v1&k2=v2" from a NULL-terminated list of key, value pairs. */
static void form(char *out, size_t n, ...)
{
    out[0] = '\0';
    va_list ap;
    va_start(ap, n);
    const char *k;
    int first = 1;
    while ((k = va_arg(ap, const char *))) {
        const char *v = va_arg(ap, const char *);
        if (!first)
            strncat(out, "&", n - strlen(out) - 1);
        first = 0;
        enc_append(out, n, k);
        strncat(out, "=", n - strlen(out) - 1);
        enc_append(out, n, v ? v : "");
    }
    va_end(ap);
}

/* Sends one request and returns the response body (malloc'd). *status gets the HTTP code. */
static char *request(const char *method, const char *path, const char *body, int *status)
{
    int fd = connect_server();
    if (fd < 0)
        return NULL;
    size_t blen = body ? strlen(body) : 0;
    char head[1024];
    int hn = snprintf(head, sizeof head,
                      "%s %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: cms-client/1.0\r\n"
                      "Connection: close\r\n%s%s%s"
                      "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: %zu\r\n\r\n",
                      method, path, host, token[0] ? "Authorization: Bearer " : "", token,
                      token[0] ? "\r\n" : "", blen);
    if (send(fd, head, (size_t)hn, 0) < 0 || (blen && send(fd, body, blen, 0) < 0)) {
        perror("send");
        close(fd);
        return NULL;
    }

    size_t cap = 8192, len = 0;
    char *buf = malloc(cap);
    for (;;) {
        if (len + 4096 > cap) {
            cap *= 2;
            buf = realloc(buf, cap);
        }
        ssize_t r = recv(fd, buf + len, cap - len - 1, 0);
        if (r <= 0)
            break;
        len += (size_t)r;
    }
    close(fd);
    buf[len] = '\0';

    *status = 0;
    sscanf(buf, "HTTP/%*s %d", status);
    char *bodyp = strstr(buf, "\r\n\r\n");
    char *out = strdup(bodyp ? bodyp + 4 : "");
    free(buf);
    return out;
}

/* ---------- a very small JSON reader ----------
 * Enough for this API: find "key": inside an object and read a string or
 * number. Objects are scanned at their own nesting level only. */

static const char *skip_value(const char *p);

static const char *skip_string(const char *p)
{
    p++; /* opening quote */
    while (*p && *p != '"') {
        if (*p == '\\' && p[1])
            p++;
        p++;
    }
    return *p ? p + 1 : p;
}

static const char *skip_value(const char *p)
{
    while (isspace((unsigned char)*p))
        p++;
    if (*p == '"')
        return skip_string(p);
    if (*p == '{' || *p == '[') {
        int depth = 0;
        while (*p) {
            if (*p == '"') {
                p = skip_string(p);
                continue;
            }
            if (*p == '{' || *p == '[')
                depth++;
            else if (*p == '}' || *p == ']') {
                if (--depth == 0)
                    return p + 1;
            }
            p++;
        }
        return p;
    }
    while (*p && *p != ',' && *p != '}' && *p != ']')
        p++;
    return p;
}

/* Finds key in the object starting at obj ('{'). Returns pointer to its value or NULL. */
static const char *jfind(const char *obj, const char *key)
{
    if (!obj)
        return NULL;
    const char *p = obj;
    while (*p && *p != '{')
        p++;
    if (!*p)
        return NULL;
    p++;
    size_t kl = strlen(key);
    for (;;) {
        while (isspace((unsigned char)*p) || *p == ',')
            p++;
        if (*p != '"')
            return NULL;
        const char *k = p + 1;
        p = skip_string(p);
        int match = (size_t)(p - 1 - k) == kl && strncmp(k, key, kl) == 0;
        while (isspace((unsigned char)*p) || *p == ':')
            p++;
        if (match)
            return p;
        p = skip_value(p);
    }
}

static void jstr(const char *obj, const char *key, char *out, size_t n)
{
    out[0] = '\0';
    const char *p = jfind(obj, key);
    if (!p)
        return;
    if (*p != '"') { /* number / literal */
        size_t i = 0;
        while (*p && *p != ',' && *p != '}' && *p != ']' && i + 1 < n)
            out[i++] = *p++;
        out[i] = '\0';
        return;
    }
    p++;
    size_t i = 0;
    while (*p && *p != '"' && i + 1 < n) {
        if (*p == '\\' && p[1]) {
            p++;
            if (*p == 'n') out[i++] = '\n';
            else if (*p == 't') out[i++] = '\t';
            else if (*p == 'u' && strncmp(p, "u003c", 5) == 0) { out[i++] = '<'; p += 4; }
            else out[i++] = *p;
            p++;
        } else {
            out[i++] = *p++;
        }
    }
    out[i] = '\0';
}

static long jint(const char *obj, const char *key)
{
    char b[32];
    jstr(obj, key, b, sizeof b);
    return atol(b);
}

/* Calls fn for every object in the array at obj[key]. */
static void jeach(const char *obj, const char *key, void (*fn)(const char *item, void *ctx), void *ctx)
{
    const char *p = jfind(obj, key);
    if (!p || *p != '[')
        return;
    p++;
    for (;;) {
        while (isspace((unsigned char)*p) || *p == ',')
            p++;
        if (*p != '{')
            return;
        fn(p, ctx);
        p = skip_value(p);
    }
}

/* ---------- console helpers ---------- */

static void prompt(const char *label, char *out, size_t n)
{
    printf("%s", label);
    fflush(stdout);
    if (!fgets(out, (int)n, stdin)) {
        out[0] = '\0';
        if (feof(stdin)) {
            printf("\n");
            exit(0);
        }
        return;
    }
    out[strcspn(out, "\r\n")] = '\0';
}

static void ask_id(char *id, size_t n) { prompt("Complaint ID (e.g. CMP-2026-001 or 1): ", id, n); }

static void when(long ts, char *out, size_t n)
{
    time_t t = (time_t)ts;
    struct tm tm;
    strftime(out, n, "%d %b %H:%M", localtime_r(&t, &tm));
}

/* prints the server's error message if there was one; returns 1 if the call failed */
static int failed(const char *body, int status)
{
    if (!body)
        return 1;
    if (status >= 200 && status < 300)
        return 0;
    char err[300];
    jstr(body, "error", err, sizeof err);
    printf("  ! %s\n", err[0] ? err : "request failed");
    if (status == 401)
        token[0] = '\0';
    return 1;
}

/* ---------- commands ---------- */

static int do_login(void)
{
    char user[64], pass[128], body[512];
    prompt("ID / roll number : ", user, sizeof user);
    prompt("Password         : ", pass, sizeof pass);
    form(body, sizeof body, "username", user, "password", pass, (char *)NULL);
    int st;
    char *r = request("POST", "/api/login", body, &st);
    memset(pass, 0, sizeof pass);
    if (failed(r, st)) {
        free(r);
        return 0;
    }
    jstr(r, "token", token, sizeof token);
    const char *u = jfind(r, "user");
    jstr(u, "name", my_name, sizeof my_name);
    jstr(u, "role", my_role, sizeof my_role);
    jstr(u, "username", my_id, sizeof my_id);
    printf("\n  Signed in as %s (%s, %s)\n", my_name, my_id, my_role);
    free(r);
    return 1;
}

static void print_row(const char *c, void *ctx)
{
    (void)ctx;
    char id[24], title[64], status[20], prio[12], who[40], esc[4];
    jstr(c, "id", id, sizeof id);
    jstr(c, "title", title, sizeof title);
    jstr(c, "status", status, sizeof status);
    jstr(c, "priority", prio, sizeof prio);
    jstr(c, "assignee", who, sizeof who);
    jstr(c, "escalated", esc, sizeof esc);
    if (strlen(title) > 40)
        strcpy(title + 37, "...");
    printf("  %-13s %-40s %-12s %-9s %s%s\n", id, title, status, prio, who[0] ? who : "-",
           esc[0] == '1' && strcmp(status, "Resolved") ? "  [ESCALATED]" : "");
}

static void cmd_list(const char *query)
{
    int st;
    char path[256];
    snprintf(path, sizeof path, "/api/complaints?sort=sla%s", query ? query : "");
    char *r = request("GET", path, NULL, &st);
    if (!failed(r, st)) {
        printf("\n  %ld complaint(s)\n", jint(r, "count"));
        printf("  %-13s %-40s %-12s %-9s %s\n", "ID", "SUBJECT", "STATUS", "PRIORITY", "ASSIGNEE");
        printf("  -------------------------------------------------------------------------------------\n");
        jeach(r, "items", print_row, NULL);
    }
    free(r);
}

static void print_event(const char *e, void *ctx)
{
    (void)ctx;
    char t[32], actor[64], text[512];
    when(jint(e, "at"), t, sizeof t);
    jstr(e, "actor", actor, sizeof actor);
    jstr(e, "text", text, sizeof text);
    printf("    %s  %-16s %s\n", t, actor, text);
}

static void cmd_view(void)
{
    char id[32], path[96];
    ask_id(id, sizeof id);
    snprintf(path, sizeof path, "/api/complaints/%s", id);
    int st;
    char *r = request("GET", path, NULL, &st);
    if (!failed(r, st)) {
        char cid[24], title[128], cat[64], zone[96], room[128], status[20], prio[12], sub[64], asg[64], desc[1100], t[32];
        jstr(r, "id", cid, sizeof cid);
        jstr(r, "title", title, sizeof title);
        jstr(r, "category", cat, sizeof cat);
        jstr(r, "zone", zone, sizeof zone);
        jstr(r, "room", room, sizeof room);
        jstr(r, "status", status, sizeof status);
        jstr(r, "priority", prio, sizeof prio);
        jstr(r, "submitter", sub, sizeof sub);
        jstr(r, "assignee", asg, sizeof asg);
        jstr(r, "description", desc, sizeof desc);
        long deadline = jint(r, "deadline");
        when(deadline, t, sizeof t);
        printf("\n  %s  %s\n", cid, title);
        printf("  ------------------------------------------------------------\n");
        printf("  Status   : %s (stage %ld of 5)%s\n", status, jint(r, "stage"), jint(r, "escalated") ? "  ESCALATED" : "");
        printf("  Priority : %s, due %s%s\n", prio, t,
               jint(r, "open") && deadline < time(NULL) ? "  (OVERDUE)" : "");
        printf("  Category : %s\n", cat);
        printf("  Where    : %s, %s\n", zone, room);
        printf("  Filed by : %s\n", sub);
        printf("  Assigned : %s\n", asg[0] ? asg : "nobody yet");
        printf("\n  %s\n\n  Timeline:\n", desc);
        jeach(r, "events", print_event, NULL);
    }
    free(r);
}

static void cmd_new(void)
{
    static const char *cats[] = {"Hostel Maintenance", "Network & WiFi", "Electrical & Power",
                                 "Classroom & AV", "Sanitation & Drainage", "Civil & Structural"};
    static const char *prios[] = {"Low", "Medium", "High", "Critical"};
    char title[160], desc[1024], zone[128], room[160], pick[8], anon[8], body[4096];

    printf("\n  Categories:\n");
    for (int i = 0; i < 6; i++)
        printf("    %d) %s\n", i + 1, cats[i]);
    prompt("  Choose 1-6: ", pick, sizeof pick);
    int ci = atoi(pick) - 1;
    if (ci < 0 || ci > 5) {
        printf("  ! not a valid choice\n");
        return;
    }
    prompt("  Subject      : ", title, sizeof title);
    prompt("  Description  : ", desc, sizeof desc);
    prompt("  Building/zone: ", zone, sizeof zone);
    prompt("  Room/landmark: ", room, sizeof room);
    prompt("  Priority 1=Low 2=Medium 3=High 4=Critical [2]: ", pick, sizeof pick);
    int pi = pick[0] ? atoi(pick) - 1 : 1;
    if (pi < 0 || pi > 3)
        pi = 1;
    prompt("  File anonymously? (y/N): ", anon, sizeof anon);

    form(body, sizeof body, "category", cats[ci], "title", title, "description", desc, "zone", zone,
         "room", room, "priority", prios[pi], "anonymous", (anon[0] == 'y' || anon[0] == 'Y') ? "1" : "0",
         (char *)NULL);
    int st;
    char *r = request("POST", "/api/complaints", body, &st);
    if (!failed(r, st)) {
        char id[24];
        jstr(r, "id", id, sizeof id);
        printf("\n  Lodged. Your tracking ID is %s\n", id);
    }
    free(r);
}

static void post_action(const char *id, const char *action, const char *body)
{
    char path[128];
    snprintf(path, sizeof path, "/api/complaints/%s/%s", id, action);
    int st;
    char *r = request("POST", path, body, &st);
    if (!failed(r, st)) {
        char status[24], who[64];
        jstr(r, "status", status, sizeof status);
        jstr(r, "assignee", who, sizeof who);
        printf("  OK. Now: %s%s%s\n", status, who[0] ? ", assigned to " : "", who);
    }
    free(r);
}

static void cmd_status(void)
{
    char id[32], s[24], note[400], body[1024];
    ask_id(id, sizeof id);
    if (strcmp(my_role, "staff") == 0)
        prompt("New status (In Progress / Resolved): ", s, sizeof s);
    else
        prompt("New status (Pending/Reviewed/Assigned/In Progress/Resolved/Rejected): ", s, sizeof s);
    prompt("Note: ", note, sizeof note);
    form(body, sizeof body, "status", s, "note", note, (char *)NULL);
    post_action(id, "status", body);
}

static void cmd_note(void)
{
    char id[32], note[480], body[1600];
    ask_id(id, sizeof id);
    prompt("Note: ", note, sizeof note);
    form(body, sizeof body, "text", note, (char *)NULL);
    post_action(id, "note", body);
}

static void cmd_escalate(void)
{
    char id[32], why[300], body[1000];
    ask_id(id, sizeof id);
    prompt("Why does this need escalation? ", why, sizeof why);
    form(body, sizeof body, "reason", why, (char *)NULL);
    post_action(id, "escalate", body);
}

static void print_staff(const char *u, void *ctx)
{
    (void)ctx;
    char id[40], name[64], dept[96];
    jstr(u, "username", id, sizeof id);
    jstr(u, "name", name, sizeof name);
    jstr(u, "dept", dept, sizeof dept);
    if (jint(u, "active"))
        printf("    %-10s %-20s %-28s %ld open\n", id, name, dept, jint(u, "open_jobs"));
}

static void cmd_assign(void)
{
    char id[32];
    ask_id(id, sizeof id);
    int st;
    char *r = request("GET", "/api/users?role=staff", NULL, &st);
    if (failed(r, st)) {
        free(r);
        return;
    }
    printf("\n  Staff:\n");
    jeach(r, "items", print_staff, NULL);
    free(r);
    char who[48], body[128];
    prompt("Staff ID to assign: ", who, sizeof who);
    form(body, sizeof body, "staff", who, (char *)NULL);
    post_action(id, "assign", body);
}

static void cmd_stats(void)
{
    int st;
    char *r = request("GET", "/api/stats", NULL, &st);
    if (!failed(r, st)) {
        const char *bs = jfind(r, "by_status");
        printf("\n  Total %ld | open %ld | escalated %ld | overdue %ld | unassigned %ld\n",
               jint(r, "total"), jint(r, "open"), jint(r, "escalated"), jint(r, "overdue"), jint(r, "unassigned"));
        printf("  Pending %ld, Reviewed %ld, Assigned %ld, In Progress %ld, Resolved %ld, Rejected %ld\n",
               jint(bs, "Pending"), jint(bs, "Reviewed"), jint(bs, "Assigned"), jint(bs, "In Progress"),
               jint(bs, "Resolved"), jint(bs, "Rejected"));
        char pct[16], rating[16];
        jstr(r, "sla_met_pct", pct, sizeof pct);
        jstr(r, "avg_rating", rating, sizeof rating);
        printf("  Resolved in last 30 days: %ld (%s%% within SLA), average rating %s\n",
               jint(r, "resolved_30d"), pct, rating);
    }
    free(r);
}

static void cmd_logout(void)
{
    int st;
    free(request("POST", "/api/logout", "", &st));
    token[0] = '\0';
    printf("  Signed out.\n");
}

static void menu(void)
{
    int student = !strcmp(my_role, "student"), staff = !strcmp(my_role, "staff");
    printf("\n== Campus CMS :: %s (%s) ==\n", my_name, my_role);
    printf("  1) List %s\n", student ? "my complaints" : staff ? "my work queue" : "all complaints");
    printf("  2) View a complaint + timeline\n");
    printf("  3) Lodge a new complaint\n");
    printf("  4) Add a note\n");
    if (!student)
        printf("  5) Change status\n");
    if (!staff)
        printf("  6) Escalate\n");
    if (!student && !staff)
        printf("  7) Assign to staff\n  8) Show escalated only\n");
    printf("  9) Stats\n  0) Sign out\n  q) Quit\n");
}

int main(int argc, char **argv)
{
    if (argc > 1)
        snprintf(host, sizeof host, "%s", argv[1]);
    if (argc > 2)
        snprintf(port, sizeof port, "%s", argv[2]);

    int st;
    char *h = request("GET", "/api/health", NULL, &st);
    if (!h)
        return 1;
    printf("Connected to %s:%s  (server pid %ld, %ld complaints on record)\n", host, port, jint(h, "pid"),
           jint(h, "complaints"));
    free(h);

    char choice[16];
    for (;;) {
        while (!token[0]) {
            printf("\n-- Sign in --\n");
            if (do_login())
                break;
        }
        menu();
        int manager = !strcmp(my_role, "admin") || !strcmp(my_role, "supervisor");
        prompt("> ", choice, sizeof choice);
        switch (choice[0]) {
        case '1': cmd_list(NULL); break;
        case '2': cmd_view(); break;
        case '3': cmd_new(); break;
        case '4': cmd_note(); break;
        case '5': if (strcmp(my_role, "student")) cmd_status(); else printf("  ? not available for students\n"); break;
        case '6': if (strcmp(my_role, "staff")) cmd_escalate(); else printf("  ? not available for staff\n"); break;
        case '7': if (manager) cmd_assign(); else printf("  ? admins and supervisors only\n"); break;
        case '8': if (manager) cmd_list("&escalated=1"); else printf("  ? admins and supervisors only\n"); break;
        case '9': cmd_stats(); break;
        case '0': cmd_logout(); break;
        case 'q': case 'Q': return 0;
        default: printf("  ? pick one of the numbers above\n");
        }
    }
}
