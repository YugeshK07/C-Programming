/*
 * Vercel adapter for the C server.
 *
 * Vercel can't keep a socket server running, so every /api request lands
 * here instead and we run the compiled C server once in one-shot mode
 * (`cms_cgi -1`): the raw HTTP request goes in on stdin and the HTTP response
 * comes back on stdout. All the actual logic (auth, permissions, complaints,
 * timeline) stays in C.
 *
 * Function instances have no lasting disk, so the three .db files live in a
 * private Vercel Blob as one JSON document:
 *   1. fetch the latest copy (skipped when this warm instance already has it)
 *   2. run the C binary against it in /tmp
 *   3. if the files changed, write them back with `ifMatch` on the ETag we
 *      started from; if another request saved in between, the write is
 *      refused and we redo the whole request on the fresh data
 * so concurrent users never overwrite each other.
 */
'use strict';

const { spawn } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { get, put, BlobPreconditionFailedError } = require('@vercel/blob');

const BLOB_PATH = 'cms/db.json';
const CACHE_DIR = '/tmp/cms-cache'; // last copy pulled from the blob, shared by this instance
const BIN_SRC = path.join(__dirname, '..', 'bin', 'cms_cgi');
const BIN = '/tmp/cms_cgi';
const FILES = ['users.db', 'complaints.db', 'events.db'];
const MAX_ATTEMPTS = 12;

let cachedEtag = null; // ETag of the blob copy currently in CACHE_DIR

function prepareBinary() {
  if (!fs.existsSync(BIN)) {
    fs.copyFileSync(BIN_SRC, BIN);
    fs.chmodSync(BIN, 0o755);
  }
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

function readFiles(dir) {
  const out = {};
  for (const f of FILES) {
    const p = path.join(dir, f);
    out[f] = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : null;
  }
  return out;
}

function writeFiles(dir, files) {
  fs.mkdirSync(dir, { recursive: true });
  for (const f of FILES) {
    const p = path.join(dir, f);
    if (files && typeof files[f] === 'string') fs.writeFileSync(p, files[f]);
    else fs.rmSync(p, { force: true });
  }
}

/* Gets the latest data from the blob and returns { etag, files }. A warm
 * instance asks with If-None-Match and reuses its cached copy when nothing
 * changed. Fluid compute can run several requests in one instance at once,
 * so the cache is only ever replaced whole, and each request then works on
 * its own private copy (see the handler). */
async function pull() {
  const res = await get(BLOB_PATH, {
    access: 'private',
    useCache: false,
    ...(cachedEtag ? { ifNoneMatch: cachedEtag } : {}),
  });
  if (!res) {
    // nothing stored yet: start empty and let the C server seed the demo data
    return { etag: null, files: null };
  }
  if (res.statusCode === 304) return { etag: strongEtag(res.blob.etag) || cachedEtag, files: readFiles(CACHE_DIR) };
  const files = JSON.parse(await new Response(res.stream).text());
  writeFiles(CACHE_DIR, files);
  cachedEtag = strongEtag(res.blob.etag);
  return { etag: cachedEtag, files };
}

async function push(files, baseEtag) {
  const body = JSON.stringify(files);
  const opts = { access: 'private', contentType: 'application/json', addRandomSuffix: false, cacheControlMaxAge: 60 };
  // ifMatch makes the write conditional on nobody else having saved since we read
  const result = baseEtag
    ? await put(BLOB_PATH, body, { ...opts, allowOverwrite: true, ifMatch: baseEtag })
    : await put(BLOB_PATH, body, { ...opts, allowOverwrite: false });
  writeFiles(CACHE_DIR, files);
  cachedEtag = result.etag;
}

/* Downloads come back with a weak ETag (W/"abc") because the response is
 * compressed in transit, while conditional writes compare against the strong
 * form ("abc"). Same version either way, so drop the W/ prefix. */
const strongEtag = (e) => (e ? String(e).replace(/^W\//, '') : e);

function isConflict(err) {
  if (err instanceof BlobPreconditionFailedError) return true;
  // creating the very first copy while another instance does the same
  return /already exists|precondition/i.test(String(err && err.message));
}

function runC(rawRequest, dataDir) {
  return new Promise((resolve, reject) => {
    const child = spawn(BIN, ['-1', '-d', dataDir], { env: { ...process.env, TZ: process.env.TZ || 'Asia/Kolkata' } });
    const out = [];
    const err = [];
    child.stdout.on('data', (d) => out.push(d));
    child.stderr.on('data', (d) => err.push(d));
    child.on('error', reject);
    child.on('close', (code) => {
      if (err.length) console.log(Buffer.concat(err).toString().trim());
      if (code !== 0 && !out.length) reject(new Error(`cms_cgi exited with ${code}`));
      else resolve(Buffer.concat(out));
    });
    child.stdin.end(rawRequest);
  });
}

/* Exponential backoff with full jitter, so requests that collided don't
 * collide again on the next round: up to 100ms, 200ms, 400ms ... 1.6s. */
function backoff(attempt) {
  const cap = Math.min(1600, 50 * 2 ** attempt);
  return new Promise((r) => setTimeout(r, crypto.randomInt(20, cap)));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function buildRequest(req, body) {
  const lines = [`${req.method} ${req.url} HTTP/1.1`, `Host: ${req.headers.host || 'localhost'}`];
  for (const h of ['cookie', 'authorization', 'content-type']) {
    if (req.headers[h]) lines.push(`${h}: ${String(req.headers[h]).replace(/[\r\n]/g, '')}`);
  }
  lines.push(`Content-Length: ${body.length}`);
  return Buffer.concat([Buffer.from(lines.join('\r\n') + '\r\n\r\n'), body]);
}

function parseResponse(raw) {
  const split = raw.indexOf('\r\n\r\n');
  const head = raw.subarray(0, split < 0 ? raw.length : split).toString();
  const body = split < 0 ? Buffer.alloc(0) : raw.subarray(split + 4);
  const [statusLine, ...headerLines] = head.split('\r\n');
  const status = parseInt(statusLine.split(' ')[1], 10) || 502;
  const headers = {};
  for (const line of headerLines) {
    const i = line.indexOf(':');
    if (i > 0) headers[line.slice(0, i).trim().toLowerCase()] = line.slice(i + 1).trim();
  }
  return { status, headers, body };
}

module.exports = async (req, res) => {
  const started = Date.now();
  try {
    prepareBinary();
    const body = await readBody(req);
    const raw = buildRequest(req, body);

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      let baseEtag, before;
      try {
        ({ etag: baseEtag, files: before } = await pull());
      } catch (err) {
        // a failed or interrupted read is safe to simply try again
        if (attempt === MAX_ATTEMPTS) throw err;
        console.warn('cms adapter: read failed, retrying:', err.message);
        cachedEtag = null;
        await backoff(attempt);
        continue;
      }
      const work = fs.mkdtempSync('/tmp/cms-req-');
      let out, after;
      try {
        writeFiles(work, before);
        out = parseResponse(await runC(raw, work));
        after = readFiles(work);
      } finally {
        fs.rmSync(work, { recursive: true, force: true });
      }
      if (!before) for (const f of FILES) if (after[f] === null) delete after[f]; // keep JSON tidy

      const changed = FILES.some((f) => (before ? before[f] : null) !== (after[f] ?? null));
      if (changed) {
        try {
          await push(after, baseEtag);
        } catch (err) {
          if (!isConflict(err) || attempt === MAX_ATTEMPTS) throw err;
          cachedEtag = null; // our local copy is stale now, force a full re-read
          await backoff(attempt);
          continue;
        }
      }

      for (const h of ['content-type', 'set-cookie', 'content-disposition', 'cache-control', 'x-content-type-options']) {
        if (out.headers[h]) res.setHeader(h, out.headers[h]);
      }
      res.setHeader('x-cms-backend', `c-one-shot; ${Date.now() - started}ms; attempt ${attempt}`);
      res.statusCode = out.status;
      res.end(out.body);
      return;
    }
  } catch (err) {
    console.error('cms adapter error:', err);
    res.statusCode = 500;
    res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify({ error: 'The server hit a storage error. Please try again in a moment.' }));
  }
};

// let Vercel hand us the raw body instead of parsing it
module.exports.config = { api: { bodyParser: false } };
