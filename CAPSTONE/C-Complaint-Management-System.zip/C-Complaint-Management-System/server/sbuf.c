#include "sbuf.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void grow(sbuf *b, size_t need)
{
    if (b->len + need + 1 <= b->cap)
        return;
    size_t cap = b->cap ? b->cap : 256;
    while (cap < b->len + need + 1)
        cap *= 2;
    char *p = realloc(b->data, cap);
    if (!p) {
        perror("realloc");
        abort();
    }
    b->data = p;
    b->cap = cap;
}

void sb_init(sbuf *b)
{
    b->data = NULL;
    b->len = b->cap = 0;
    grow(b, 0);
    b->data[0] = '\0';
}

void sb_free(sbuf *b)
{
    free(b->data);
    b->data = NULL;
    b->len = b->cap = 0;
}

void sb_append(sbuf *b, const char *s, size_t n)
{
    grow(b, n);
    memcpy(b->data + b->len, s, n);
    b->len += n;
    b->data[b->len] = '\0';
}

void sb_puts(sbuf *b, const char *s) { sb_append(b, s, strlen(s)); }

void sb_printf(sbuf *b, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0)
        return;
    grow(b, (size_t)n);
    va_start(ap, fmt);
    vsnprintf(b->data + b->len, (size_t)n + 1, fmt, ap);
    va_end(ap);
    b->len += (size_t)n;
}

void sb_json_str(sbuf *b, const char *s)
{
    sb_append(b, "\"", 1);
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        switch (*p) {
        case '"': sb_append(b, "\\\"", 2); break;
        case '\\': sb_append(b, "\\\\", 2); break;
        case '\n': sb_append(b, "\\n", 2); break;
        case '\r': sb_append(b, "\\r", 2); break;
        case '\t': sb_append(b, "\\t", 2); break;
        case '<': sb_append(b, "\\u003c", 6); break; /* keeps it safe to inline in HTML */
        default:
            if (*p < 0x20)
                sb_printf(b, "\\u%04x", *p);
            else
                sb_append(b, (const char *)p, 1);
        }
    }
    sb_append(b, "\"", 1);
}

void sb_kv_str(sbuf *b, const char *key, const char *val, int first)
{
    if (!first)
        sb_append(b, ",", 1);
    sb_json_str(b, key);
    sb_append(b, ":", 1);
    sb_json_str(b, val ? val : "");
}

void sb_kv_int(sbuf *b, const char *key, long long val, int first)
{
    if (!first)
        sb_append(b, ",", 1);
    sb_json_str(b, key);
    sb_printf(b, ":%lld", val);
}
