/*
 * Campus Complaint Management System - server
 *
 *   ./cms_server [-p port] [-d data_dir] [-w web_dir]
 *
 *   ./cms_server -1 [-d data_dir]      one-shot mode, see below
 *
 * Listens on a TCP port, and hands every connection to its own detached
 * thread. Browsers get the web UI from web_dir, and anything under /api/ goes
 * to the JSON API (which the terminal client uses too).
 */
#include "api.h"
#include "http.h"
#include "store.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

static const char *web_root = "web";
static volatile sig_atomic_t stopping = 0;

typedef struct {
    int fd;
    char peer[64];
} conn_t;

static void log_line(const char *peer, const http_req *req, int note)
{
    char ts[32];
    time_t now = time(NULL);
    struct tm tm;
    strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", localtime_r(&now, &tm));
    printf("%s  %-15s %-5s %s%s\n", ts, peer, req->method, req->path, note ? "  (bad request)" : "");
    fflush(stdout); /* in one-shot mode stdout points at stderr, see one_shot() */
}

static void *serve(void *arg)
{
    conn_t *c = arg;
    __atomic_add_fetch(&active_connections, 1, __ATOMIC_RELAXED);

    /* don't let a client hold a thread forever by sending nothing */
    struct timeval tv = {.tv_sec = 15, .tv_usec = 0};
    setsockopt(c->fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    setsockopt(c->fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv);

    http_req req;
    int err = http_read_request(c->fd, &req);
    if (err == 0) {
        snprintf(req.peer, sizeof req.peer, "%s", c->peer);
        log_line(c->peer, &req, 0);
        if (strncmp(req.path, "/api/", 5) == 0)
            api_handle(c->fd, &req);
        else if (strcmp(req.method, "GET") == 0 || strcmp(req.method, "HEAD") == 0)
            http_send_file(c->fd, web_root, req.path);
        else
            http_send_error(c->fd, 405, "method not allowed");
    } else if (err > 0) {
        log_line(c->peer, &req, 1);
        http_send_error(c->fd, err, status_text(err));
    }
    http_free_request(&req);

    close(c->fd);
    free(c);
    __atomic_sub_fetch(&active_connections, 1, __ATOMIC_RELAXED);
    return NULL;
}

/* One-shot mode: read a single HTTP request on stdin, write the response to
 * stdout, exit. This is how the server runs on Vercel, where a small Node
 * function starts it once per API call (much like old-school CGI). Anything
 * the server would normally print goes to stderr so the response stays clean. */
static int one_shot(void)
{
    int out = dup(STDOUT_FILENO);
    dup2(STDERR_FILENO, STDOUT_FILENO);
    signal(SIGPIPE, SIG_IGN);

    http_req req;
    int err = http_read_request(STDIN_FILENO, &req);
    if (err == 0) {
        log_line("one-shot", &req, 0);
        if (strncmp(req.path, "/api/", 5) == 0)
            api_handle(out, &req);
        else
            http_send_file(out, web_root, req.path);
    } else {
        http_send_error(out, err > 0 ? err : 400, status_text(err > 0 ? err : 400));
    }
    http_free_request(&req);
    close(out);
    return 0;
}

static void on_signal(int sig)
{
    (void)sig;
    stopping = 1;
}

static void usage(const char *prog)
{
    fprintf(stderr, "usage: %s [-p port] [-d data_dir] [-w web_dir]\n"
                    "       %s -1 [-d data_dir]   (handle one request on stdin/stdout)\n", prog, prog);
    exit(2);
}

int main(int argc, char **argv)
{
    int port = 8080;
    const char *data_dir = "data";
    int opt, once = 0;
    while ((opt = getopt(argc, argv, "p:d:w:h1")) != -1) {
        switch (opt) {
        case '1': once = 1; break;
        case 'p': port = atoi(optarg); break;
        case 'd': data_dir = optarg; break;
        case 'w': web_root = optarg; break;
        default: usage(argv[0]);
        }
    }
    if (port <= 0 || port > 65535)
        usage(argv[0]);

    if (once) {
        /* keep store_init's chatter off stdout too */
        fflush(stdout);
        int saved = dup(STDOUT_FILENO);
        dup2(STDERR_FILENO, STDOUT_FILENO);
        int ok = store_init(data_dir) == 0;
        dup2(saved, STDOUT_FILENO);
        close(saved);
        if (!ok)
            return 1;
        server_started = time(NULL);
        return one_shot();
    }

    if (store_init(data_dir) != 0)
        return 1;
    server_started = time(NULL);

    int srv = socket(AF_INET, SOCK_STREAM, 0);
    if (srv < 0) {
        perror("socket");
        return 1;
    }
    int yes = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)port);
    if (bind(srv, (struct sockaddr *)&addr, sizeof addr) < 0) {
        perror("bind");
        return 1;
    }
    if (listen(srv, 64) < 0) {
        perror("listen");
        return 1;
    }

    /* Ctrl+C should stop the accept loop cleanly. No SA_RESTART on purpose,
     * so accept() returns with EINTR and we notice. */
    struct sigaction sa = {0};
    sa.sa_handler = on_signal;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);

    printf("Campus CMS server listening on port %d (pid %d)\n", port, getpid());
    printf("  web UI : http://localhost:%d/\n", port);
    printf("  data   : %s/\n", data_dir);
    fflush(stdout);

    while (!stopping) {
        struct sockaddr_in peer;
        socklen_t plen = sizeof peer;
        int fd = accept(srv, (struct sockaddr *)&peer, &plen);
        if (fd < 0) {
            if (errno == EINTR)
                continue;
            perror("accept");
            continue;
        }
        conn_t *c = malloc(sizeof *c);
        if (!c) {
            close(fd);
            continue;
        }
        c->fd = fd;
        inet_ntop(AF_INET, &peer.sin_addr, c->peer, sizeof c->peer);

        pthread_t t;
        if (pthread_create(&t, NULL, serve, c) != 0) {
            perror("pthread_create");
            close(fd);
            free(c);
            continue;
        }
        pthread_detach(t);
    }

    printf("\nshutting down\n");
    close(srv);
    /* take the lock so no request is halfway through a save when we exit */
    pthread_mutex_lock(&store_mx);
    return 0;
}
