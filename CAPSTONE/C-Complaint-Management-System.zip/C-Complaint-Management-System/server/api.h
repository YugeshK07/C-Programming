#ifndef API_H
#define API_H

#include "http.h"
#include <time.h>

extern time_t server_started;
extern volatile int active_connections; /* touched with __atomic builtins */

/* Handles anything under /api/. Takes the store lock internally. */
void api_handle(int fd, http_req *req);

#endif
