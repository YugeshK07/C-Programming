/*
 * Storage layer.
 *
 * Everything lives in memory while the server runs and is written to three
 * tab-separated text files in the data directory:
 *
 *   users.db       rewritten whenever a user changes
 *   complaints.db  rewritten whenever a complaint changes
 *   events.db      append-only log (the timeline / audit trail)
 *
 * Rewrites go to a temp file first and are then renamed over the old one, so a
 * crash in the middle of a save can't leave a half-written file behind.
 */
#include "store.h"
#include "sha256.h"

#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

pthread_mutex_t store_mx = PTHREAD_MUTEX_INITIALIZER;

user_t users[MAX_USERS];
int user_count;
complaint_t complaints[MAX_COMPLAINTS];
int complaint_count;
event_t events[MAX_EVENTS];
int event_count;

static char path_users[512], path_complaints[512], path_events[512];

static const char *ROLE_NAMES[] = {"student", "staff", "admin", "supervisor"};
static const char *STATUS_NAMES[] = {"Pending", "Reviewed", "Assigned", "In Progress", "Resolved", "Rejected"};
static const char *PRIO_NAMES[] = {"Low", "Medium", "High", "Critical"};
static const int PRIO_HOURS[] = {72, 48, 24, 4};

const char *role_name(role_t r) { return (r >= 0 && r < ROLE_COUNT) ? ROLE_NAMES[r] : "unknown"; }
const char *status_name(status_t s) { return (s >= 0 && s < ST_COUNT) ? STATUS_NAMES[s] : "Unknown"; }
const char *prio_name(prio_t p) { return (p >= 0 && p < PRIO_COUNT) ? PRIO_NAMES[p] : "Medium"; }
int prio_sla_hours(prio_t p) { return (p >= 0 && p < PRIO_COUNT) ? PRIO_HOURS[p] : 48; }

static int lookup(const char *s, const char *const *names, int n)
{
    if (!s)
        return -1;
    for (int i = 0; i < n; i++)
        if (strcasecmp(s, names[i]) == 0)
            return i;
    return -1;
}

int role_from_name(const char *s) { return lookup(s, ROLE_NAMES, ROLE_COUNT); }
int status_from_name(const char *s) { return lookup(s, STATUS_NAMES, ST_COUNT); }
int prio_from_name(const char *s) { return lookup(s, PRIO_NAMES, PRIO_COUNT); }

void random_hex(char *out, size_t nbytes)
{
    unsigned char buf[64];
    if (nbytes > sizeof buf)
        nbytes = sizeof buf;
    int fd = open("/dev/urandom", O_RDONLY);
    ssize_t got = fd >= 0 ? read(fd, buf, nbytes) : -1;
    if (fd >= 0)
        close(fd);
    if (got != (ssize_t)nbytes) {
        /* very unlikely, but don't hand out predictable zeros */
        for (size_t i = 0; i < nbytes; i++)
            buf[i] = (unsigned char)(rand() ^ (int)time(NULL) ^ (int)i);
    }
    for (size_t i = 0; i < nbytes; i++)
        sprintf(out + i * 2, "%02x", buf[i]);
    out[nbytes * 2] = '\0';
}

/* ---------- field escaping for the .db files ---------- */

static void put_field(FILE *f, const char *s, int last)
{
    for (; *s; s++) {
        if (*s == '\t')
            fputs("\\t", f);
        else if (*s == '\n')
            fputs("\\n", f);
        else if (*s == '\r')
            continue;
        else if (*s == '\\')
            fputs("\\\\", f);
        else
            fputc(*s, f);
    }
    fputc(last ? '\n' : '\t', f);
}

static void put_int(FILE *f, long long v, int last) { fprintf(f, "%lld%c", v, last ? '\n' : '\t'); }

/* Splits a line in place on tabs and undoes the escaping. Returns field count. */
static int split_line(char *line, char **fields, int max)
{
    int n = 0;
    char *w = line, *start = line;
    for (char *r = line;; r++) {
        if (*r == '\t' || *r == '\n' || *r == '\0') {
            int end = (*r == '\0' || *r == '\n');
            *w = '\0';
            if (n < max)
                fields[n++] = start;
            if (end)
                break;
            w++;
            start = w;
        } else if (*r == '\\' && r[1]) {
            r++;
            *w++ = (*r == 't') ? '\t' : (*r == 'n') ? '\n' : *r;
        } else {
            *w++ = *r;
        }
    }
    return n;
}

static void copy(char *dst, const char *src, size_t n)
{
    snprintf(dst, n, "%s", src ? src : "");
}

static FILE *open_tmp(const char *final_path, char *tmp_path, size_t n)
{
    snprintf(tmp_path, n, "%s.tmp", final_path);
    FILE *f = fopen(tmp_path, "w");
    if (!f)
        fprintf(stderr, "store: cannot write %s: %s\n", tmp_path, strerror(errno));
    return f;
}

static int commit_tmp(FILE *f, const char *tmp_path, const char *final_path)
{
    fflush(f);
    fsync(fileno(f));
    fclose(f);
    if (rename(tmp_path, final_path) != 0) {
        fprintf(stderr, "store: rename %s failed: %s\n", tmp_path, strerror(errno));
        return -1;
    }
    return 0;
}

/* ---------- users ---------- */

int store_save_users(void)
{
    char tmp[600];
    FILE *f = open_tmp(path_users, tmp, sizeof tmp);
    if (!f)
        return -1;
    for (int i = 0; i < user_count; i++) {
        user_t *u = &users[i];
        put_int(f, u->id, 0);
        put_field(f, u->username, 0);
        put_field(f, u->name, 0);
        put_field(f, role_name(u->role), 0);
        put_field(f, u->dept, 0);
        put_field(f, u->phone, 0);
        put_field(f, u->salt, 0);
        put_field(f, u->hash, 0);
        put_int(f, u->active, 1);
    }
    return commit_tmp(f, tmp, path_users);
}

static void load_users(void)
{
    FILE *f = fopen(path_users, "r");
    if (!f)
        return;
    char line[2048];
    char *fl[16];
    while (fgets(line, sizeof line, f) && user_count < MAX_USERS) {
        if (split_line(line, fl, 16) < 9)
            continue;
        user_t *u = &users[user_count++];
        memset(u, 0, sizeof *u);
        u->id = atoi(fl[0]);
        copy(u->username, fl[1], sizeof u->username);
        copy(u->name, fl[2], sizeof u->name);
        int r = role_from_name(fl[3]);
        u->role = r < 0 ? ROLE_STUDENT : (role_t)r;
        copy(u->dept, fl[4], sizeof u->dept);
        copy(u->phone, fl[5], sizeof u->phone);
        copy(u->salt, fl[6], sizeof u->salt);
        copy(u->hash, fl[7], sizeof u->hash);
        u->active = atoi(fl[8]);
    }
    fclose(f);
}

user_t *user_by_id(int id)
{
    for (int i = 0; i < user_count; i++)
        if (users[i].id == id)
            return &users[i];
    return NULL;
}

user_t *user_by_name(const char *username)
{
    for (int i = 0; i < user_count; i++)
        if (strcasecmp(users[i].username, username) == 0)
            return &users[i];
    return NULL;
}

static void hash_password(const char *salt, const char *password, char out[65])
{
    char buf[512];
    snprintf(buf, sizeof buf, "%s:%s", salt, password);
    sha256_hex(buf, out);
    /* a few thousand extra rounds so a leaked users.db isn't instantly crackable */
    for (int i = 0; i < 5000; i++) {
        snprintf(buf, sizeof buf, "%s%s", out, salt);
        sha256_hex(buf, out);
    }
}

void user_set_password(user_t *u, const char *password)
{
    random_hex(u->salt, 8);
    hash_password(u->salt, password, u->hash);
}

int user_check_password(const user_t *u, const char *password)
{
    char h[65];
    hash_password(u->salt, password, h);
    /* compare every byte so timing doesn't leak how much matched */
    int diff = 0;
    for (int i = 0; i < 64; i++)
        diff |= h[i] ^ u->hash[i];
    return diff == 0;
}

user_t *user_create(const char *username, const char *name, role_t role, const char *dept,
                    const char *phone, const char *password)
{
    if (user_count >= MAX_USERS || user_by_name(username))
        return NULL;
    int next_id = 1;
    for (int i = 0; i < user_count; i++)
        if (users[i].id >= next_id)
            next_id = users[i].id + 1;
    user_t *u = &users[user_count++];
    memset(u, 0, sizeof *u);
    u->id = next_id;
    copy(u->username, username, sizeof u->username);
    copy(u->name, name, sizeof u->name);
    u->role = role;
    copy(u->dept, dept, sizeof u->dept);
    copy(u->phone, phone, sizeof u->phone);
    u->active = 1;
    user_set_password(u, password);
    return u;
}

/* ---------- complaints ---------- */

int store_save_complaints(void)
{
    char tmp[600];
    FILE *f = open_tmp(path_complaints, tmp, sizeof tmp);
    if (!f)
        return -1;
    for (int i = 0; i < complaint_count; i++) {
        complaint_t *c = &complaints[i];
        put_int(f, c->num, 0);
        put_field(f, c->title, 0);
        put_field(f, c->category, 0);
        put_field(f, c->subcategory, 0);
        put_field(f, c->description, 0);
        put_field(f, c->zone, 0);
        put_field(f, c->room, 0);
        put_int(f, c->priority, 0);
        put_int(f, c->status, 0);
        put_int(f, c->escalated, 0);
        put_int(f, c->anonymous, 0);
        put_int(f, c->submitter_id, 0);
        put_int(f, c->assignee_id, 0);
        put_int(f, (long long)c->created, 0);
        put_int(f, (long long)c->updated, 0);
        put_int(f, (long long)c->resolved_at, 0);
        put_int(f, c->rating, 1);
    }
    return commit_tmp(f, tmp, path_complaints);
}

static void load_complaints(void)
{
    FILE *f = fopen(path_complaints, "r");
    if (!f)
        return;
    char line[4096];
    char *fl[24];
    while (fgets(line, sizeof line, f) && complaint_count < MAX_COMPLAINTS) {
        if (split_line(line, fl, 24) < 17)
            continue;
        complaint_t *c = &complaints[complaint_count++];
        memset(c, 0, sizeof *c);
        c->num = atoi(fl[0]);
        copy(c->title, fl[1], sizeof c->title);
        copy(c->category, fl[2], sizeof c->category);
        copy(c->subcategory, fl[3], sizeof c->subcategory);
        copy(c->description, fl[4], sizeof c->description);
        copy(c->zone, fl[5], sizeof c->zone);
        copy(c->room, fl[6], sizeof c->room);
        c->priority = (prio_t)atoi(fl[7]);
        c->status = (status_t)atoi(fl[8]);
        c->escalated = atoi(fl[9]);
        c->anonymous = atoi(fl[10]);
        c->submitter_id = atoi(fl[11]);
        c->assignee_id = atoi(fl[12]);
        c->created = (time_t)atoll(fl[13]);
        c->updated = (time_t)atoll(fl[14]);
        c->resolved_at = (time_t)atoll(fl[15]);
        c->rating = atoi(fl[16]);
    }
    fclose(f);
}

complaint_t *complaint_by_num(int num)
{
    for (int i = 0; i < complaint_count; i++)
        if (complaints[i].num == num)
            return &complaints[i];
    return NULL;
}

complaint_t *complaint_create(void)
{
    if (complaint_count >= MAX_COMPLAINTS)
        return NULL;
    int next = 1;
    for (int i = 0; i < complaint_count; i++)
        if (complaints[i].num >= next)
            next = complaints[i].num + 1;
    complaint_t *c = &complaints[complaint_count++];
    memset(c, 0, sizeof *c);
    c->num = next;
    c->created = c->updated = time(NULL);
    c->priority = PRIO_MEDIUM;
    c->status = ST_PENDING;
    return c;
}

void complaint_code(const complaint_t *c, char *out, size_t n)
{
    struct tm tm;
    localtime_r(&c->created, &tm);
    snprintf(out, n, "CMP-%04d-%03d", tm.tm_year + 1900, c->num);
}

time_t complaint_deadline(const complaint_t *c)
{
    return c->created + (time_t)prio_sla_hours(c->priority) * 3600;
}

/* ---------- events ---------- */

static void load_events(void)
{
    FILE *f = fopen(path_events, "r");
    if (!f)
        return;
    char line[2048];
    char *fl[8];
    while (fgets(line, sizeof line, f) && event_count < MAX_EVENTS) {
        if (split_line(line, fl, 8) < 5)
            continue;
        event_t *e = &events[event_count++];
        e->complaint_num = atoi(fl[0]);
        e->at = (time_t)atoll(fl[1]);
        e->actor_id = atoi(fl[2]);
        copy(e->kind, fl[3], sizeof e->kind);
        copy(e->text, fl[4], sizeof e->text);
    }
    fclose(f);
}

void event_add(int complaint_num, int actor_id, const char *kind, const char *fmt, ...)
{
    if (event_count >= MAX_EVENTS) {
        /* drop the oldest half from memory; the file still has everything */
        memmove(events, events + MAX_EVENTS / 2, sizeof(event_t) * (MAX_EVENTS / 2));
        event_count = MAX_EVENTS / 2;
    }
    event_t *e = &events[event_count++];
    e->complaint_num = complaint_num;
    e->at = time(NULL);
    e->actor_id = actor_id;
    copy(e->kind, kind, sizeof e->kind);
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(e->text, sizeof e->text, fmt, ap);
    va_end(ap);

    FILE *f = fopen(path_events, "a");
    if (!f) {
        fprintf(stderr, "store: cannot append to %s: %s\n", path_events, strerror(errno));
        return;
    }
    put_int(f, e->complaint_num, 0);
    put_int(f, (long long)e->at, 0);
    put_int(f, e->actor_id, 0);
    put_field(f, e->kind, 0);
    put_field(f, e->text, 1);
    fclose(f);
}

/* ---------- first run ---------- */

static void seed(void)
{
    fprintf(stderr, "store: empty data directory, creating demo accounts\n");
    user_create("admin", "Meera Iyer", ROLE_ADMIN, "Campus Estate Office", "Ext 4000", "admin123");
    user_create("super01", "Dr. Anil Menon", ROLE_SUPERVISOR, "Dean of Student Affairs", "Ext 4010", "super123");
    user_t *rk = user_create("OP-408", "Rajesh Kumar", ROLE_STAFF, "Plumbing Services", "+91-98765-11408", "staff123");
    user_t *av = user_create("OP-215", "Amit Verma", ROLE_STAFF, "Network & IT Services", "+91-98765-11215", "staff123");
    user_create("OP-330", "Sunita Rao", ROLE_STAFF, "Electrical & Power", "+91-98765-11330", "staff123");
    user_t *st = user_create("CS2023084", "Arjun Sharma", ROLE_STUDENT, "Computer Science & Engineering", "", "student123");
    user_create("EC2024017", "Priya Nair", ROLE_STUDENT, "Electronics & Communication", "", "student123");
    store_save_users();

    /* a few complaints so the dashboards aren't empty on day one */
    time_t now = time(NULL);
    struct {
        const char *title, *cat, *sub, *desc, *zone, *room;
        prio_t prio;
        status_t st;
        int assignee, hours_ago;
    } demo[] = {
        {"Water leakage in Block-B 3rd floor washroom", "Hostel Maintenance", "Plumbing & Water Supply",
         "Tap conduit leaking near the wash basins next to cubicle 3. Water is spreading into the corridor.",
         "Hostel Block B", "3rd floor east wing, washroom", PRIO_HIGH, ST_IN_PROGRESS, rk->id, 5},
        {"WiFi access point dropping in central library", "Network & WiFi", "Access point / coverage",
         "The 5GHz network keeps disconnecting every few minutes on the 2nd floor reading bay.",
         "Central Library", "2nd floor reading bay", PRIO_MEDIUM, ST_PENDING, 0, 20},
        {"Core switch link down in CS Lab 4", "Network & WiFi", "Wired LAN",
         "None of the lab machines get a network connection since this morning.",
         "CSE Block", "Lab 4", PRIO_CRITICAL, ST_ASSIGNED, av->id, 3},
        {"Broken bench in Lecture Hall 3", "Classroom & AV", "Furniture",
         "Third row bench has a cracked seat plank, someone could get hurt.",
         "Academic Block A", "Lecture Hall 3", PRIO_LOW, ST_RESOLVED, rk->id, 80},
    };
    for (size_t i = 0; i < sizeof demo / sizeof demo[0]; i++) {
        complaint_t *c = complaint_create();
        copy(c->title, demo[i].title, sizeof c->title);
        copy(c->category, demo[i].cat, sizeof c->category);
        copy(c->subcategory, demo[i].sub, sizeof c->subcategory);
        copy(c->description, demo[i].desc, sizeof c->description);
        copy(c->zone, demo[i].zone, sizeof c->zone);
        copy(c->room, demo[i].room, sizeof c->room);
        c->priority = demo[i].prio;
        c->status = demo[i].st;
        c->submitter_id = st->id;
        c->assignee_id = demo[i].assignee;
        c->created = now - demo[i].hours_ago * 3600;
        c->updated = now - 1800;
        if (c->status == ST_RESOLVED) {
            c->resolved_at = c->created + 20 * 3600;
            c->rating = 5;
        }
        event_add(c->num, st->id, "created", "Complaint lodged via student portal");
        if (c->assignee_id) {
            user_t *a = user_by_id(c->assignee_id);
            event_add(c->num, 1, "assign", "Assigned to %s (%s)", a->name, a->username);
        }
        if (c->status >= ST_IN_PROGRESS)
            event_add(c->num, c->assignee_id, "status", "Status changed to In Progress");
        if (c->status == ST_RESOLVED)
            event_add(c->num, c->assignee_id, "status", "Status changed to Resolved");
    }
    store_save_complaints();
}

int store_init(const char *dir)
{
    if (mkdir(dir, 0755) != 0 && errno != EEXIST) {
        fprintf(stderr, "store: cannot create %s: %s\n", dir, strerror(errno));
        return -1;
    }
    snprintf(path_users, sizeof path_users, "%s/users.db", dir);
    snprintf(path_complaints, sizeof path_complaints, "%s/complaints.db", dir);
    snprintf(path_events, sizeof path_events, "%s/events.db", dir);

    load_users();
    load_complaints();
    load_events();
    if (user_count == 0)
        seed();

    fprintf(stderr, "store: %d users, %d complaints, %d timeline events loaded from %s/\n",
           user_count, complaint_count, event_count, dir);
    return 0;
}
