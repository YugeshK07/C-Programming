#ifndef SHA256_H
#define SHA256_H

#include <stddef.h>
#include <stdint.h>

/* Plain SHA-256. Used for password hashing (salted) so we don't need OpenSSL. */
void sha256(const uint8_t *data, size_t len, uint8_t out[32]);
void sha256_hex(const char *text, char out_hex[65]);

/* HMAC-SHA256 (RFC 2104) over two C strings, as 64 hex chars. */
void hmac_sha256_hex(const char *key, const char *msg, char out_hex[65]);

#endif
