#ifndef STORE_H
#define STORE_H

#include <pthread.h>
#include <time.h>

#define MAX_USERS 1024
#define MAX_COMPLAINTS 8192
#define MAX_EVENTS 65536

typedef enum { ROLE_STUDENT = 0, ROLE_STAFF, ROLE_ADMIN, ROLE_SUPERVISOR, ROLE_COUNT } role_t;

/* Complaint lifecycle. The order matters: it doubles as the "stage" on the timeline. */
typedef enum {
    ST_PENDING = 0,  /* stage 1: logged, waiting for the desk */
    ST_REVIEWED,     /* stage 2: checked and categorised */
    ST_ASSIGNED,     /* stage 3: handed to a staff member */
    ST_IN_PROGRESS,  /* stage 4: staff is on it */
    ST_RESOLVED,     /* stage 5: done */
    ST_REJECTED,     /* closed without action (duplicate, invalid, ...) */
    ST_COUNT
} status_t;

typedef enum { PRIO_LOW = 0, PRIO_MEDIUM, PRIO_HIGH, PRIO_CRITICAL, PRIO_COUNT } prio_t;

typedef struct {
    int id;
    char username[32]; /* roll number for students, staff/faculty id for others */
    char name[64];
    role_t role;
    char dept[96];
    char phone[32];
    char salt[17];
    char hash[65];
    int active;
} user_t;

typedef struct {
    int num; /* shown to people as CMP-<year>-<num> */
    char title[128];
    char category[48];
    char subcategory[80];
    char description[1024];
    char zone[96];
    char room[128];
    prio_t priority;
    status_t status;
    int escalated;
    int anonymous;
    int submitter_id;
    int assignee_id; /* 0 = nobody yet */
    time_t created;
    time_t updated;
    time_t resolved_at;
    int rating; /* 0 = not rated, 1..5 otherwise */
} complaint_t;

typedef struct {
    int complaint_num;
    time_t at;
    int actor_id;
    char kind[16]; /* "status", "note", "assign", "escalate", "rating", "created" */
    char text[512];
} event_t;

/* One big lock around the whole store. Requests are short, so this is fine
 * for a campus-sized deployment and it keeps the reasoning simple. */
extern pthread_mutex_t store_mx;

extern user_t users[MAX_USERS];
extern int user_count;
extern complaint_t complaints[MAX_COMPLAINTS];
extern int complaint_count;
extern event_t events[MAX_EVENTS];
extern int event_count;

int store_init(const char *data_dir);
int store_save_users(void);
int store_save_complaints(void);

user_t *user_by_id(int id);
user_t *user_by_name(const char *username);
user_t *user_create(const char *username, const char *name, role_t role, const char *dept,
                    const char *phone, const char *password);
int user_check_password(const user_t *u, const char *password);
void user_set_password(user_t *u, const char *password);

complaint_t *complaint_by_num(int num);
complaint_t *complaint_create(void);
void complaint_code(const complaint_t *c, char *out, size_t n);
time_t complaint_deadline(const complaint_t *c);

void event_add(int complaint_num, int actor_id, const char *kind, const char *fmt, ...)
    __attribute__((format(printf, 4, 5)));

const char *role_name(role_t r);
int role_from_name(const char *s); /* -1 if unknown */
const char *status_name(status_t s);
int status_from_name(const char *s);
const char *prio_name(prio_t p);
int prio_from_name(const char *s);
int prio_sla_hours(prio_t p);

void random_hex(char *out, size_t nbytes); /* writes 2*nbytes hex chars + NUL */

#endif
