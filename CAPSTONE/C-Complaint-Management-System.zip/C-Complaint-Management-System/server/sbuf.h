#ifndef SBUF_H
#define SBUF_H

#include <stddef.h>

/* Growable string buffer. Handy for building JSON and HTTP responses. */
typedef struct {
    char *data;
    size_t len;
    size_t cap;
} sbuf;

void sb_init(sbuf *b);
void sb_free(sbuf *b);
void sb_append(sbuf *b, const char *s, size_t n);
void sb_puts(sbuf *b, const char *s);
void sb_printf(sbuf *b, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

/* Appends s as a quoted JSON string, escaping what needs escaping. */
void sb_json_str(sbuf *b, const char *s);

/* Appends ,"key":"value" (or without the comma when first is set). */
void sb_kv_str(sbuf *b, const char *key, const char *val, int first);
void sb_kv_int(sbuf *b, const char *key, long long val, int first);

#endif
