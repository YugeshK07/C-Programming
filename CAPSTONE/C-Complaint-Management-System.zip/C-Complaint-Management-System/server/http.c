/*
 * Just enough HTTP/1.1 to serve the web UI and the JSON API.
 * One request per connection (we always answer with Connection: close).
 */
#include "http.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#define MAX_HEADER 8192

const char *status_text(int s)
{
    switch (s) {
    case 200: return "OK";
    case 201: return "Created";
    case 204: return "No Content";
    case 400: return "Bad Request";
    case 401: return "Unauthorized";
    case 403: return "Forbidden";
    case 404: return "Not Found";
    case 405: return "Method Not Allowed";
    case 409: return "Conflict";
    case 413: return "Payload Too Large";
    case 431: return "Request Header Fields Too Large";
    default: return "Internal Server Error";
    }
}

static int write_all(int fd, const char *p, size_t n)
{
    while (n > 0) {
        ssize_t w = write(fd, p, n); /* write() works on sockets and pipes alike */
        if (w < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        p += w;
        n -= (size_t)w;
    }
    return 0;
}

static int hexval(int c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

/* URL-decodes src[0..len) into out. '+' becomes a space (form encoding). */
static void url_decode(const char *src, size_t len, char *out, size_t n)
{
    size_t o = 0;
    for (size_t i = 0; i < len && o + 1 < n; i++) {
        if (src[i] == '%' && i + 2 < len && hexval(src[i + 1]) >= 0 && hexval(src[i + 2]) >= 0) {
            out[o++] = (char)(hexval(src[i + 1]) * 16 + hexval(src[i + 2]));
            i += 2;
        } else if (src[i] == '+') {
            out[o++] = ' ';
        } else {
            out[o++] = src[i];
        }
    }
    out[o] = '\0';
}

int form_get(const char *src, const char *key, char *out, size_t n)
{
    if (n)
        out[0] = '\0';
    if (!src)
        return 0;
    size_t klen = strlen(key);
    const char *p = src;
    while (*p) {
        const char *amp = strchr(p, '&');
        size_t seg = amp ? (size_t)(amp - p) : strlen(p);
        const char *eq = memchr(p, '=', seg);
        size_t name_len = eq ? (size_t)(eq - p) : seg;
        char name[128];
        url_decode(p, name_len, name, sizeof name);
        if (strlen(name) == klen && strcmp(name, key) == 0) {
            if (eq)
                url_decode(eq + 1, seg - name_len - 1, out, n);
            return 1;
        }
        if (!amp)
            break;
        p = amp + 1;
    }
    return 0;
}

int cookie_get(const char *cookies, const char *name, char *out, size_t n)
{
    size_t nl = strlen(name);
    const char *p = cookies;
    while (p && *p) {
        while (*p == ' ' || *p == ';')
            p++;
        if (strncmp(p, name, nl) == 0 && p[nl] == '=') {
            p += nl + 1;
            size_t i = 0;
            while (*p && *p != ';' && i + 1 < n)
                out[i++] = *p++;
            out[i] = '\0';
            return 1;
        }
        p = strchr(p, ';');
    }
    return 0;
}

static void header_value(const char *headers, const char *name, char *out, size_t n)
{
    out[0] = '\0';
    size_t nl = strlen(name);
    const char *line = headers;
    while (line && *line) {
        if (strncasecmp(line, name, nl) == 0 && line[nl] == ':') {
            const char *v = line + nl + 1;
            while (*v == ' ')
                v++;
            size_t i = 0;
            while (v[i] && v[i] != '\r' && v[i] != '\n' && i + 1 < n) {
                out[i] = v[i];
                i++;
            }
            out[i] = '\0';
            return;
        }
        line = strstr(line, "\r\n");
        if (line)
            line += 2;
    }
}

int http_read_request(int fd, http_req *req)
{
    memset(req, 0, sizeof *req);
    char buf[MAX_HEADER + 1];
    size_t got = 0;
    char *end = NULL;

    while (!end) {
        if (got >= MAX_HEADER)
            return 431;
        ssize_t r = read(fd, buf + got, MAX_HEADER - got);
        if (r < 0 && errno == EINTR)
            continue;
        if (r <= 0)
            return -1; /* client went away, nothing to answer */
        got += (size_t)r;
        buf[got] = '\0';
        end = strstr(buf, "\r\n\r\n");
    }
    size_t header_len = (size_t)(end - buf) + 4;

    /* request line: METHOD /path?query HTTP/1.1 */
    char target[1600];
    if (sscanf(buf, "%7s %1599s", req->method, target) != 2)
        return 400;
    char *q = strchr(target, '?');
    if (q) {
        snprintf(req->query, sizeof req->query, "%s", q + 1);
        *q = '\0';
    }
    url_decode(target, strlen(target), req->path, sizeof req->path);

    char tmp[32];
    header_value(buf, "Content-Length", tmp, sizeof tmp);
    long clen = tmp[0] ? atol(tmp) : 0;
    if (clen < 0)
        return 400;
    if (clen > MAX_BODY)
        return 413;
    header_value(buf, "Cookie", req->cookie, sizeof req->cookie);
    header_value(buf, "Authorization", req->auth, sizeof req->auth);

    req->body = malloc((size_t)clen + 1);
    if (!req->body)
        return 500;
    size_t have = got - header_len;
    if (have > (size_t)clen)
        have = (size_t)clen;
    memcpy(req->body, buf + header_len, have);
    while (have < (size_t)clen) {
        ssize_t r = read(fd, req->body + have, (size_t)clen - have);
        if (r < 0 && errno == EINTR)
            continue;
        if (r <= 0)
            return -1;
        have += (size_t)r;
    }
    req->body[clen] = '\0';
    req->body_len = (size_t)clen;
    return 0;
}

void http_free_request(http_req *req)
{
    free(req->body);
    req->body = NULL;
}

void http_send(int fd, int status, const char *ctype, const char *body, size_t len,
               const char *extra_headers)
{
    char head[1024];
    int n = snprintf(head, sizeof head,
                     "HTTP/1.1 %d %s\r\n"
                     "Content-Type: %s\r\n"
                     "Content-Length: %zu\r\n"
                     "Connection: close\r\n"
                     "X-Content-Type-Options: nosniff\r\n"
                     "Cache-Control: no-store\r\n"
                     "Server: cms-c/1.0\r\n"
                     "%s\r\n",
                     status, status_text(status), ctype, len, extra_headers ? extra_headers : "");
    if (n > 0 && write_all(fd, head, (size_t)n) == 0 && len)
        write_all(fd, body, len);
}

void http_send_json(int fd, int status, const char *json)
{
    http_send(fd, status, "application/json; charset=utf-8", json, strlen(json), NULL);
}

void http_send_error(int fd, int status, const char *message)
{
    char buf[512];
    char safe[300];
    size_t j = 0;
    for (size_t i = 0; message[i] && j + 2 < sizeof safe; i++) {
        if (message[i] == '"' || message[i] == '\\')
            safe[j++] = '\\';
        safe[j++] = message[i];
    }
    safe[j] = '\0';
    snprintf(buf, sizeof buf, "{\"error\":\"%s\"}", safe);
    http_send_json(fd, status, buf);
}

static const char *mime_for(const char *path)
{
    const char *dot = strrchr(path, '.');
    if (!dot) return "application/octet-stream";
    if (!strcmp(dot, ".html")) return "text/html; charset=utf-8";
    if (!strcmp(dot, ".css")) return "text/css; charset=utf-8";
    if (!strcmp(dot, ".js")) return "application/javascript; charset=utf-8";
    if (!strcmp(dot, ".svg")) return "image/svg+xml";
    if (!strcmp(dot, ".png")) return "image/png";
    if (!strcmp(dot, ".ico")) return "image/x-icon";
    if (!strcmp(dot, ".json")) return "application/json";
    return "application/octet-stream";
}

void http_send_file(int fd, const char *root, const char *path)
{
    if (strstr(path, "..") || strchr(path, '\\')) {
        http_send_error(fd, 403, "bad path");
        return;
    }
    char full[1024];
    if (strcmp(path, "/") == 0)
        path = "/index.html";
    snprintf(full, sizeof full, "%s%s", root, path);

    int f = open(full, O_RDONLY);
    struct stat st;
    if (f < 0 || fstat(f, &st) != 0 || !S_ISREG(st.st_mode)) {
        if (f >= 0)
            close(f);
        http_send_error(fd, 404, "not found");
        return;
    }
    char *data = malloc((size_t)st.st_size + 1);
    ssize_t r = data ? read(f, data, (size_t)st.st_size) : -1;
    close(f);
    if (r != st.st_size) {
        free(data);
        http_send_error(fd, 500, "read failed");
        return;
    }
    http_send(fd, 200, mime_for(full), data, (size_t)st.st_size, NULL);
    free(data);
}
