/*
 * JSON API.
 *
 * Request bodies are plain form encoding (a=1&b=2), which the browser can
 * send with URLSearchParams and which is trivial to parse in C. Responses are
 * JSON.
 *
 * Every handler runs with store_mx held and writes its answer into a
 * `reply`. The lock is dropped before anything goes out on the socket, so a
 * slow client can't stall the other users.
 */
#include "api.h"
#include "sbuf.h"
#include "sha256.h"
#include "store.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

#define SESSION_SECONDS (8 * 3600)

time_t server_started;
volatile int active_connections;

typedef struct {
    int status;
    const char *ctype; /* NULL means JSON */
    char headers[256];
    sbuf body;
} reply;

static const char *CATEGORIES[] = {
    "Hostel Maintenance", "Network & WiFi", "Electrical & Power",
    "Classroom & AV", "Sanitation & Drainage", "Civil & Structural",
};
#define N_CATEGORIES ((int)(sizeof CATEGORIES / sizeof CATEGORIES[0]))

/* ---------- small helpers ---------- */

/* strncpy that always terminates and never pads */
static void scopy(char *dst, size_t n, const char *src)
{
    size_t len = strlen(src);
    if (len >= n)
        len = n - 1;
    memcpy(dst, src, len);
    dst[len] = '\0';
}

static void fail(reply *r, int status, const char *msg)
{
    r->status = status;
    r->body.len = 0;
    sb_puts(&r->body, "{");
    sb_kv_str(&r->body, "error", msg, 1);
    sb_puts(&r->body, "}");
}

static void ok_msg(reply *r, const char *msg)
{
    r->status = 200;
    sb_puts(&r->body, "{\"ok\":true");
    sb_kv_str(&r->body, "message", msg, 0);
    sb_puts(&r->body, "}");
}

/* Reads a form field and trims surrounding whitespace. */
static int field(const http_req *req, const char *key, char *out, size_t n)
{
    if (!form_get(req->body, key, out, n) && !form_get(req->query, key, out, n))
        return 0;
    char *s = out;
    while (*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r')
        s++;
    if (s != out)
        memmove(out, s, strlen(s) + 1);
    size_t len = strlen(out);
    while (len && (out[len - 1] == ' ' || out[len - 1] == '\t' || out[len - 1] == '\n' || out[len - 1] == '\r'))
        out[--len] = '\0';
    return 1;
}

static int valid_category(const char *c)
{
    for (int i = 0; i < N_CATEGORIES; i++)
        if (strcmp(c, CATEGORIES[i]) == 0)
            return 1;
    return 0;
}

static int valid_username(const char *s)
{
    size_t n = strlen(s);
    if (n < 3 || n > 30)
        return 0;
    for (; *s; s++)
        if (!((*s >= 'a' && *s <= 'z') || (*s >= 'A' && *s <= 'Z') || (*s >= '0' && *s <= '9') ||
              *s == '-' || *s == '_' || *s == '.'))
            return 0;
    return 1;
}

static int is_open(const complaint_t *c) { return c->status != ST_RESOLVED && c->status != ST_REJECTED; }

/* Accepts "CMP-2026-007", "7" or "007". */
static complaint_t *find_complaint(const char *ref)
{
    const char *dash = strrchr(ref, '-');
    const char *digits = dash ? dash + 1 : ref;
    if (!*digits)
        return NULL;
    for (const char *p = digits; *p; p++)
        if (*p < '0' || *p > '9')
            return NULL;
    return complaint_by_num(atoi(digits));
}

/* ---------- sessions ----------
 *
 * Tokens are signed instead of stored: "<user id>.<expiry>.<hmac>", where the
 * HMAC-SHA256 covers the id, the expiry and the user's password salt. That
 * means the server needs no session table (so it also works when every
 * request runs in a fresh process, as on Vercel), and changing a password
 * invalidates every token issued before it. Disabled accounts are refused at
 * lookup time.
 *
 * The key comes from the CMS_SECRET environment variable. Without it a random
 * key is made at startup, so logins don't survive a restart. */

static char secret[129];

static const char *get_secret(void)
{
    if (!secret[0]) {
        const char *env = getenv("CMS_SECRET");
        if (env && strlen(env) >= 16)
            scopy(secret, sizeof secret, env);
        else
            random_hex(secret, 32);
    }
    return secret;
}

static void sign(int user_id, long long exp, const user_t *u, char out[65])
{
    char msg[160];
    snprintf(msg, sizeof msg, "%d.%lld.%s", user_id, exp, u->salt);
    hmac_sha256_hex(get_secret(), msg, out);
}

static void request_token(const http_req *req, char *token, size_t n)
{
    token[0] = '\0';
    if (strncasecmp(req->auth, "Bearer ", 7) == 0)
        scopy(token, n, req->auth + 7);
    else
        cookie_get(req->cookie, "cms_token", token, n);
}

static user_t *session_user(const http_req *req)
{
    char token[160];
    request_token(req, token, sizeof token);
    int id;
    long long exp;
    char mac[80];
    if (sscanf(token, "%d.%lld.%79s", &id, &exp, mac) != 3 || strlen(mac) != 64)
        return NULL;
    if (exp < (long long)time(NULL))
        return NULL;
    user_t *u = user_by_id(id);
    if (!u || !u->active)
        return NULL;
    char want[65];
    sign(id, exp, u, want);
    int diff = 0;
    for (int i = 0; i < 64; i++)
        diff |= want[i] ^ mac[i];
    return diff == 0 ? u : NULL;
}

static const char *session_start(const user_t *u)
{
    static __thread char token[160];
    long long exp = (long long)time(NULL) + SESSION_SECONDS;
    char mac[65];
    sign(u->id, exp, u, mac);
    snprintf(token, sizeof token, "%d.%lld.%s", u->id, exp, mac);
    return token;
}

/* ---------- permissions ---------- */

static int can_view(const user_t *u, const complaint_t *c)
{
    switch (u->role) {
    case ROLE_STUDENT: return c->submitter_id == u->id;
    case ROLE_STAFF: return c->assignee_id == u->id || c->submitter_id == u->id;
    default: return 1;
    }
}

static int is_manager(const user_t *u) { return u->role == ROLE_ADMIN || u->role == ROLE_SUPERVISOR; }

/* ---------- JSON builders ---------- */

static void user_json(sbuf *b, const user_t *u)
{
    sb_puts(b, "{");
    sb_kv_int(b, "id", u->id, 1);
    sb_kv_str(b, "username", u->username, 0);
    sb_kv_str(b, "name", u->name, 0);
    sb_kv_str(b, "role", role_name(u->role), 0);
    sb_kv_str(b, "dept", u->dept, 0);
    sb_kv_str(b, "phone", u->phone, 0);
    sb_kv_int(b, "active", u->active, 0);
    sb_puts(b, "}");
}

static void complaint_json(sbuf *b, const complaint_t *c, const user_t *viewer, int with_events)
{
    char code[32];
    complaint_code(c, code, sizeof code);
    user_t *sub = user_by_id(c->submitter_id);
    user_t *asg = c->assignee_id ? user_by_id(c->assignee_id) : NULL;

    /* Anonymous complaints hide the person from everyone except supervisors
     * (and the person who filed it, obviously). */
    int hide = c->anonymous && viewer->role != ROLE_SUPERVISOR && viewer->id != c->submitter_id;
    int stage = c->status == ST_REJECTED ? 5 : (int)c->status + 1;

    sb_puts(b, "{");
    sb_kv_str(b, "id", code, 1);
    sb_kv_int(b, "num", c->num, 0);
    sb_kv_str(b, "title", c->title, 0);
    sb_kv_str(b, "category", c->category, 0);
    sb_kv_str(b, "subcategory", c->subcategory, 0);
    sb_kv_str(b, "description", c->description, 0);
    sb_kv_str(b, "zone", c->zone, 0);
    sb_kv_str(b, "room", c->room, 0);
    sb_kv_str(b, "priority", prio_name(c->priority), 0);
    sb_kv_int(b, "sla_hours", prio_sla_hours(c->priority), 0);
    sb_kv_str(b, "status", status_name(c->status), 0);
    sb_kv_int(b, "stage", stage, 0);
    sb_kv_int(b, "open", is_open(c), 0);
    sb_kv_int(b, "escalated", c->escalated, 0);
    sb_kv_int(b, "anonymous", c->anonymous, 0);
    sb_kv_str(b, "submitter", hide ? "Anonymous" : (sub ? sub->name : "Unknown"), 0);
    sb_kv_str(b, "submitter_username", hide ? "" : (sub ? sub->username : ""), 0);
    sb_kv_str(b, "submitter_dept", hide ? "" : (sub ? sub->dept : ""), 0);
    sb_kv_int(b, "assignee_id", c->assignee_id, 0);
    sb_kv_str(b, "assignee", asg ? asg->name : "", 0);
    sb_kv_str(b, "assignee_username", asg ? asg->username : "", 0);
    sb_kv_str(b, "assignee_dept", asg ? asg->dept : "", 0);
    sb_kv_str(b, "assignee_phone", asg ? asg->phone : "", 0);
    sb_kv_int(b, "created", (long long)c->created, 0);
    sb_kv_int(b, "updated", (long long)c->updated, 0);
    sb_kv_int(b, "resolved_at", (long long)c->resolved_at, 0);
    sb_kv_int(b, "deadline", (long long)complaint_deadline(c), 0);
    sb_kv_int(b, "rating", c->rating, 0);

    if (with_events) {
        sb_puts(b, ",\"events\":[");
        int first = 1;
        for (int i = 0; i < event_count; i++) {
            const event_t *e = &events[i];
            if (e->complaint_num != c->num)
                continue;
            user_t *a = user_by_id(e->actor_id);
            int hide_actor = hide && e->actor_id == c->submitter_id;
            sb_puts(b, first ? "{" : ",{");
            first = 0;
            sb_kv_int(b, "at", (long long)e->at, 1);
            sb_kv_str(b, "actor", hide_actor ? "Anonymous" : (a ? a->name : "System"), 0);
            sb_kv_str(b, "actor_role", a ? role_name(a->role) : "system", 0);
            sb_kv_str(b, "kind", e->kind, 0);
            sb_kv_str(b, "text", e->text, 0);
            sb_puts(b, "}");
        }
        sb_puts(b, "]");
    }
    sb_puts(b, "}");
}

/* ---------- auth endpoints ---------- */

static void login_reply(reply *r, user_t *u, int remember)
{
    const char *token = session_start(u);
    snprintf(r->headers, sizeof r->headers,
             "Set-Cookie: cms_token=%s; Path=/; HttpOnly; SameSite=Strict%s\r\n", token,
             remember ? "; Max-Age=28800" : "");
    r->status = 200;
    sb_puts(&r->body, "{");
    sb_kv_str(&r->body, "token", token, 1);
    sb_puts(&r->body, ",\"user\":");
    user_json(&r->body, u);
    sb_puts(&r->body, "}");
}

static void h_login(const http_req *req, reply *r)
{
    char username[64], password[128], role[32], remember[8];
    field(req, "username", username, sizeof username);
    field(req, "password", password, sizeof password);
    field(req, "role", role, sizeof role);
    field(req, "remember", remember, sizeof remember);

    user_t *u = user_by_name(username);
    if (!u || !user_check_password(u, password)) {
        fail(r, 401, "Wrong ID or password.");
        return;
    }
    if (!u->active) {
        fail(r, 403, "This account has been disabled. Contact the estate office.");
        return;
    }
    if (role[0] && role_from_name(role) != (int)u->role) {
        char msg[128];
        snprintf(msg, sizeof msg, "This ID is registered as %s, not %s.", role_name(u->role), role);
        fail(r, 403, msg);
        return;
    }
    login_reply(r, u, strcmp(remember, "1") == 0);
}

static void h_register(const http_req *req, reply *r)
{
    char username[64], name[96], dept[128], password[128];
    field(req, "username", username, sizeof username);
    field(req, "name", name, sizeof name);
    field(req, "dept", dept, sizeof dept);
    field(req, "password", password, sizeof password);

    if (!valid_username(username)) {
        fail(r, 400, "Roll number should be 3-30 letters, digits, '-', '_' or '.'.");
        return;
    }
    if (strlen(name) < 2) {
        fail(r, 400, "Please enter your full name.");
        return;
    }
    if (strlen(password) < 6) {
        fail(r, 400, "Password needs at least 6 characters.");
        return;
    }
    if (user_by_name(username)) {
        fail(r, 409, "That roll number is already registered.");
        return;
    }
    /* self sign-up is for students only; staff accounts are made by an admin */
    user_t *u = user_create(username, name, ROLE_STUDENT, dept, "", password);
    if (!u) {
        fail(r, 500, "User table is full.");
        return;
    }
    store_save_users();
    login_reply(r, u, 0);
}

static void h_password(const http_req *req, reply *r, user_t *me)
{
    char oldp[128], newp[128];
    field(req, "old", oldp, sizeof oldp);
    field(req, "new", newp, sizeof newp);
    if (!user_check_password(me, oldp)) {
        fail(r, 403, "Current password is wrong.");
        return;
    }
    if (strlen(newp) < 6) {
        fail(r, 400, "New password needs at least 6 characters.");
        return;
    }
    user_set_password(me, newp);
    store_save_users();
    login_reply(r, me, 1); /* old tokens are dead now, so hand out a fresh one */
}

/* ---------- complaint endpoints ---------- */

static int cmp_newest(const void *a, const void *b)
{
    const complaint_t *x = *(complaint_t *const *)a, *y = *(complaint_t *const *)b;
    return (x->created < y->created) - (x->created > y->created);
}

/* open ones first, most urgent deadline first; closed ones after, newest first */
static int cmp_sla(const void *a, const void *b)
{
    const complaint_t *x = *(complaint_t *const *)a, *y = *(complaint_t *const *)b;
    if (is_open(x) != is_open(y))
        return is_open(y) - is_open(x);
    if (!is_open(x))
        return cmp_newest(a, b);
    if (x->escalated != y->escalated)
        return y->escalated - x->escalated;
    time_t dx = complaint_deadline(x), dy = complaint_deadline(y);
    return (dx > dy) - (dx < dy);
}

static void h_list(const http_req *req, reply *r, user_t *me)
{
    char status[32], category[64], esc[8], q[128], sort[16], scope[16];
    field(req, "status", status, sizeof status);
    field(req, "category", category, sizeof category);
    field(req, "escalated", esc, sizeof esc);
    field(req, "q", q, sizeof q);
    field(req, "sort", sort, sizeof sort);
    field(req, "scope", scope, sizeof scope);
    int want_status = status[0] ? status_from_name(status) : -1;
    int only_open = strcasecmp(status, "open") == 0;

    complaint_t **list = malloc(sizeof(complaint_t *) * (size_t)(complaint_count + 1));
    int n = 0;
    for (int i = 0; i < complaint_count; i++) {
        complaint_t *c = &complaints[i];
        if (!can_view(me, c))
            continue;
        /* staff see their queue by default, and what they filed with scope=mine */
        if (me->role == ROLE_STAFF) {
            if (strcmp(scope, "mine") == 0 ? c->submitter_id != me->id : c->assignee_id != me->id)
                continue;
        } else if (strcmp(scope, "mine") == 0 && c->submitter_id != me->id) {
            continue;
        }
        if (want_status >= 0 && (int)c->status != want_status)
            continue;
        if (only_open && !is_open(c))
            continue;
        if (category[0] && strcmp(category, c->category) != 0)
            continue;
        if (esc[0] == '1' && !(c->escalated && is_open(c)))
            continue;
        if (strcasecmp(status, "unassigned") == 0 && (c->assignee_id || !is_open(c)))
            continue;
        if (q[0]) {
            char code[32];
            complaint_code(c, code, sizeof code);
            if (!strcasestr(c->title, q) && !strcasestr(c->description, q) && !strcasestr(code, q) &&
                !strcasestr(c->room, q) && !strcasestr(c->zone, q))
                continue;
        }
        list[n++] = c;
    }
    qsort(list, (size_t)n, sizeof list[0], strcmp(sort, "sla") == 0 ? cmp_sla : cmp_newest);

    r->status = 200;
    sb_printf(&r->body, "{\"count\":%d,\"items\":[", n);
    for (int i = 0; i < n; i++) {
        if (i)
            sb_puts(&r->body, ",");
        complaint_json(&r->body, list[i], me, 0);
    }
    sb_puts(&r->body, "]}");
    free(list);
}

static void h_create(const http_req *req, reply *r, user_t *me)
{
    char title[256], cat[96], sub[128], desc[1100], zone[128], room[160], prio[16], anon[8];
    field(req, "title", title, sizeof title);
    field(req, "category", cat, sizeof cat);
    field(req, "subcategory", sub, sizeof sub);
    field(req, "description", desc, sizeof desc);
    field(req, "zone", zone, sizeof zone);
    field(req, "room", room, sizeof room);
    field(req, "priority", prio, sizeof prio);
    field(req, "anonymous", anon, sizeof anon);

    if (strlen(title) < 5 || strlen(title) > 120) {
        fail(r, 400, "Subject should be between 5 and 120 characters.");
        return;
    }
    if (!valid_category(cat)) {
        fail(r, 400, "Pick one of the listed categories.");
        return;
    }
    if (strlen(desc) < 10 || strlen(desc) > 1000) {
        fail(r, 400, "Description should be between 10 and 1000 characters.");
        return;
    }
    if (!zone[0] || !room[0]) {
        fail(r, 400, "Tell us where the problem is (building and room/landmark).");
        return;
    }
    int p = prio[0] ? prio_from_name(prio) : PRIO_MEDIUM;
    if (p < 0) {
        fail(r, 400, "Unknown priority.");
        return;
    }

    complaint_t *c = complaint_create();
    if (!c) {
        fail(r, 500, "Complaint table is full.");
        return;
    }
    scopy(c->title, sizeof c->title, title);
    scopy(c->category, sizeof c->category, cat);
    scopy(c->subcategory, sizeof c->subcategory, sub);
    scopy(c->description, sizeof c->description, desc);
    scopy(c->zone, sizeof c->zone, zone);
    scopy(c->room, sizeof c->room, room);
    c->priority = (prio_t)p;
    c->anonymous = strcmp(anon, "1") == 0;
    c->submitter_id = me->id;
    store_save_complaints();
    event_add(c->num, me->id, "created", "Complaint lodged (%s priority, %d h SLA)%s",
              prio_name(c->priority), prio_sla_hours(c->priority), c->anonymous ? ", filed anonymously" : "");

    r->status = 201;
    complaint_json(&r->body, c, me, 1);
}

static void h_get(reply *r, user_t *me, complaint_t *c)
{
    r->status = 200;
    complaint_json(&r->body, c, me, 1);
}

static void h_status(const http_req *req, reply *r, user_t *me, complaint_t *c)
{
    char st[32], note[512];
    field(req, "status", st, sizeof st);
    field(req, "note", note, sizeof note);
    int s = status_from_name(st);
    if (s < 0) {
        fail(r, 400, "Unknown status.");
        return;
    }
    if (me->role == ROLE_STUDENT) {
        fail(r, 403, "Students can't change the status. Use escalation if it's stuck.");
        return;
    }
    if (me->role == ROLE_STAFF) {
        if (c->assignee_id != me->id) {
            fail(r, 403, "This complaint isn't assigned to you.");
            return;
        }
        if (s != ST_IN_PROGRESS && s != ST_RESOLVED) {
            fail(r, 403, "Staff can only mark work as In Progress or Resolved.");
            return;
        }
    }
    if (s == (int)c->status) {
        fail(r, 409, "It's already in that state.");
        return;
    }
    if ((s == ST_ASSIGNED || s == ST_IN_PROGRESS) && !c->assignee_id) {
        fail(r, 409, "Assign someone first.");
        return;
    }
    if (s == ST_RESOLVED && me->role == ROLE_STAFF && strlen(note) < 5) {
        fail(r, 400, "Add a short note about what was done.");
        return;
    }

    c->status = (status_t)s;
    c->updated = time(NULL);
    if (s == ST_RESOLVED || s == ST_REJECTED) {
        c->resolved_at = c->updated;
        c->escalated = 0;
    } else {
        c->resolved_at = 0;
        c->rating = 0;
    }
    store_save_complaints();
    if (note[0])
        event_add(c->num, me->id, "status", "Status changed to %s: %s", status_name(c->status), note);
    else
        event_add(c->num, me->id, "status", "Status changed to %s", status_name(c->status));
    h_get(r, me, c);
}

static void h_assign(const http_req *req, reply *r, user_t *me, complaint_t *c)
{
    if (!is_manager(me)) {
        fail(r, 403, "Only the admin desk or a supervisor can assign work.");
        return;
    }
    if (!is_open(c)) {
        fail(r, 409, "This complaint is already closed.");
        return;
    }
    char who[64];
    field(req, "staff", who, sizeof who);
    user_t *s = user_by_name(who);
    if (!s)
        s = user_by_id(atoi(who));
    if (!s || s->role != ROLE_STAFF || !s->active) {
        fail(r, 400, "Pick an active staff member.");
        return;
    }
    if (c->assignee_id == s->id) {
        fail(r, 409, "Already assigned to that person.");
        return;
    }
    int reassign = c->assignee_id != 0;
    c->assignee_id = s->id;
    if (c->status < ST_ASSIGNED || reassign)
        c->status = ST_ASSIGNED;
    c->updated = time(NULL);
    store_save_complaints();
    event_add(c->num, me->id, "assign", "%s %s (%s, %s)", reassign ? "Reassigned to" : "Assigned to",
              s->name, s->username, s->dept);
    h_get(r, me, c);
}

static void h_note(const http_req *req, reply *r, user_t *me, complaint_t *c)
{
    char text[512];
    field(req, "text", text, sizeof text);
    if (strlen(text) < 2) {
        fail(r, 400, "Note is empty.");
        return;
    }
    c->updated = time(NULL);
    store_save_complaints();
    event_add(c->num, me->id, "note", "%s", text);
    h_get(r, me, c);
}

static void h_escalate(const http_req *req, reply *r, user_t *me, complaint_t *c, int on)
{
    if (on && me->role == ROLE_STAFF) {
        fail(r, 403, "Staff should raise a note instead; escalation is for students and supervisors.");
        return;
    }
    if (!on && !is_manager(me)) {
        fail(r, 403, "Only the admin desk or a supervisor can de-escalate.");
        return;
    }
    if (!is_open(c)) {
        fail(r, 409, "Closed complaints can't be escalated.");
        return;
    }
    if (c->escalated == on) {
        fail(r, 409, on ? "Already escalated." : "It isn't escalated.");
        return;
    }
    char reason[400];
    field(req, "reason", reason, sizeof reason);
    if (on && strlen(reason) < 5) {
        fail(r, 400, "Say briefly why this needs escalation.");
        return;
    }
    c->escalated = on;
    c->updated = time(NULL);
    store_save_complaints();
    if (on)
        event_add(c->num, me->id, "escalate", "Escalated: %s", reason);
    else
        event_add(c->num, me->id, "escalate", "Escalation cleared%s%s", reason[0] ? ": " : "", reason);
    h_get(r, me, c);
}

static void h_rate(const http_req *req, reply *r, user_t *me, complaint_t *c)
{
    if (c->submitter_id != me->id) {
        fail(r, 403, "Only the person who filed it can rate the fix.");
        return;
    }
    if (c->status != ST_RESOLVED) {
        fail(r, 409, "You can rate it once it's resolved.");
        return;
    }
    char stars[8], comment[300];
    field(req, "stars", stars, sizeof stars);
    field(req, "comment", comment, sizeof comment);
    int s = atoi(stars);
    if (s < 1 || s > 5) {
        fail(r, 400, "Rating is 1 to 5 stars.");
        return;
    }
    c->rating = s;
    store_save_complaints();
    event_add(c->num, me->id, "rating", "Rated the resolution %d/5%s%s", s, comment[0] ? ": " : "", comment);
    h_get(r, me, c);
}

/* ---------- dashboards ---------- */

static void h_stats(reply *r, user_t *me)
{
    int by_status[ST_COUNT] = {0};
    int by_cat[N_CATEGORIES + 1];
    memset(by_cat, 0, sizeof by_cat);
    int total = 0, today = 0, escalated = 0, open = 0, overdue = 0, unassigned = 0;
    int resolved30 = 0, met30 = 0, rated = 0, rating_sum = 0, resolved_today = 0;
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now, &tm);
    tm.tm_hour = tm.tm_min = tm.tm_sec = 0;
    time_t midnight = mktime(&tm);

    for (int i = 0; i < complaint_count; i++) {
        complaint_t *c = &complaints[i];
        if (!can_view(me, c))
            continue;
        if (me->role == ROLE_STAFF && c->assignee_id != me->id)
            continue;
        total++;
        by_status[c->status]++;
        if (c->created >= midnight)
            today++;
        if (is_open(c)) {
            open++;
            if (c->escalated)
                escalated++;
            if (complaint_deadline(c) < now)
                overdue++;
            if (!c->assignee_id)
                unassigned++;
            int k = N_CATEGORIES;
            for (int j = 0; j < N_CATEGORIES; j++)
                if (strcmp(c->category, CATEGORIES[j]) == 0)
                    k = j;
            by_cat[k]++;
        }
        if (c->status == ST_RESOLVED && c->resolved_at >= now - 30 * 86400) {
            resolved30++;
            if (c->resolved_at <= complaint_deadline(c))
                met30++;
        }
        if (c->status == ST_RESOLVED && c->resolved_at >= midnight)
            resolved_today++;
        if (c->rating) {
            rated++;
            rating_sum += c->rating;
        }
    }

    r->status = 200;
    sbuf *b = &r->body;
    sb_puts(b, "{");
    sb_kv_int(b, "total", total, 1);
    sb_kv_int(b, "today", today, 0);
    sb_kv_int(b, "open", open, 0);
    sb_kv_int(b, "escalated", escalated, 0);
    sb_kv_int(b, "overdue", overdue, 0);
    sb_kv_int(b, "unassigned", unassigned, 0);
    sb_kv_int(b, "resolved_30d", resolved30, 0);
    sb_kv_int(b, "resolved_today", resolved_today, 0);
    sb_printf(b, ",\"sla_met_pct\":%.1f", resolved30 ? 100.0 * met30 / resolved30 : 100.0);
    sb_printf(b, ",\"avg_rating\":%.2f", rated ? (double)rating_sum / rated : 0.0);
    sb_puts(b, ",\"by_status\":{");
    for (int s = 0; s < ST_COUNT; s++)
        sb_kv_int(b, status_name((status_t)s), by_status[s], s == 0);
    sb_puts(b, "},\"by_category\":[");
    for (int j = 0; j <= N_CATEGORIES; j++) {
        sb_puts(b, j ? ",{" : "{");
        sb_kv_str(b, "name", j < N_CATEGORIES ? CATEGORIES[j] : "Other", 1);
        sb_kv_int(b, "open", by_cat[j], 0);
        sb_puts(b, "}");
    }
    sb_puts(b, "]}");
}

static void h_meta(reply *r)
{
    r->status = 200;
    sbuf *b = &r->body;
    sb_puts(b, "{\"categories\":[");
    for (int i = 0; i < N_CATEGORIES; i++) {
        if (i)
            sb_puts(b, ",");
        sb_json_str(b, CATEGORIES[i]);
    }
    sb_puts(b, "],\"statuses\":[");
    for (int s = 0; s < ST_COUNT; s++) {
        if (s)
            sb_puts(b, ",");
        sb_json_str(b, status_name((status_t)s));
    }
    sb_puts(b, "],\"priorities\":[");
    for (int p = 0; p < PRIO_COUNT; p++) {
        sb_puts(b, p ? ",{" : "{");
        sb_kv_str(b, "name", prio_name((prio_t)p), 1);
        sb_kv_int(b, "sla_hours", prio_sla_hours((prio_t)p), 0);
        sb_puts(b, "}");
    }
    sb_puts(b, "]}");
}

static void h_health(reply *r)
{
    r->status = 200;
    sbuf *b = &r->body;
    sb_puts(b, "{");
    sb_kv_str(b, "status", "ok", 1);
    sb_kv_int(b, "pid", getpid(), 0);
    sb_kv_int(b, "uptime", (long long)(time(NULL) - server_started), 0);
    sb_kv_int(b, "users", user_count, 0);
    sb_kv_int(b, "complaints", complaint_count, 0);
    sb_kv_int(b, "events", event_count, 0);
    sb_kv_int(b, "connections", __atomic_load_n(&active_connections, __ATOMIC_RELAXED), 0);
    sb_puts(b, "}");
}

static void h_audit(const http_req *req, reply *r, user_t *me)
{
    if (!is_manager(me)) {
        fail(r, 403, "Admins and supervisors only.");
        return;
    }
    char lim[8];
    field(req, "limit", lim, sizeof lim);
    int limit = atoi(lim);
    if (limit <= 0 || limit > 500)
        limit = 50;
    r->status = 200;
    sb_puts(&r->body, "{\"items\":[");
    int shown = 0;
    for (int i = event_count - 1; i >= 0 && shown < limit; i--, shown++) {
        const event_t *e = &events[i];
        complaint_t *c = complaint_by_num(e->complaint_num);
        user_t *a = user_by_id(e->actor_id);
        char code[32] = "";
        if (c)
            complaint_code(c, code, sizeof code);
        int hide = c && c->anonymous && e->actor_id == c->submitter_id && me->role != ROLE_SUPERVISOR;
        sb_puts(&r->body, shown ? ",{" : "{");
        sb_kv_int(&r->body, "at", (long long)e->at, 1);
        sb_kv_str(&r->body, "complaint", code, 0);
        sb_kv_str(&r->body, "actor", hide ? "Anonymous" : (a ? a->name : "System"), 0);
        sb_kv_str(&r->body, "actor_role", a ? role_name(a->role) : "system", 0);
        sb_kv_str(&r->body, "kind", e->kind, 0);
        sb_kv_str(&r->body, "text", e->text, 0);
        sb_puts(&r->body, "}");
    }
    sb_puts(&r->body, "]}");
}

static void csv_cell(sbuf *b, const char *s, int last)
{
    sb_puts(b, "\"");
    /* a leading = + - @ would be run as a formula by spreadsheet apps */
    if (*s == '=' || *s == '+' || *s == '-' || *s == '@')
        sb_puts(b, "'");
    for (; *s; s++) {
        if (*s == '"')
            sb_puts(b, "\"\"");
        else if (*s == '\n' || *s == '\r')
            sb_puts(b, " ");
        else
            sb_append(b, s, 1);
    }
    sb_puts(b, last ? "\"\r\n" : "\",");
}

static void h_export(reply *r, user_t *me)
{
    if (!is_manager(me)) {
        fail(r, 403, "Admins and supervisors only.");
        return;
    }
    r->status = 200;
    r->ctype = "text/csv; charset=utf-8";
    snprintf(r->headers, sizeof r->headers, "Content-Disposition: attachment; filename=\"complaints.csv\"\r\n");
    sbuf *b = &r->body;
    sb_puts(b, "id,title,category,subcategory,zone,room,priority,status,escalated,submitter,assignee,created,deadline,resolved,rating\r\n");
    for (int i = 0; i < complaint_count; i++) {
        complaint_t *c = &complaints[i];
        char code[32], t1[32], t2[32], t3[32] = "", num[16];
        complaint_code(c, code, sizeof code);
        struct tm tm;
        time_t dl = complaint_deadline(c);
        strftime(t1, sizeof t1, "%Y-%m-%d %H:%M", localtime_r(&c->created, &tm));
        strftime(t2, sizeof t2, "%Y-%m-%d %H:%M", localtime_r(&dl, &tm));
        if (c->resolved_at)
            strftime(t3, sizeof t3, "%Y-%m-%d %H:%M", localtime_r(&c->resolved_at, &tm));
        user_t *s = user_by_id(c->submitter_id), *a = user_by_id(c->assignee_id);
        int hide = c->anonymous && me->role != ROLE_SUPERVISOR;
        csv_cell(b, code, 0);
        csv_cell(b, c->title, 0);
        csv_cell(b, c->category, 0);
        csv_cell(b, c->subcategory, 0);
        csv_cell(b, c->zone, 0);
        csv_cell(b, c->room, 0);
        csv_cell(b, prio_name(c->priority), 0);
        csv_cell(b, status_name(c->status), 0);
        csv_cell(b, c->escalated ? "yes" : "no", 0);
        csv_cell(b, hide ? "Anonymous" : (s ? s->name : ""), 0);
        csv_cell(b, a ? a->name : "", 0);
        csv_cell(b, t1, 0);
        csv_cell(b, t2, 0);
        csv_cell(b, t3, 0);
        snprintf(num, sizeof num, "%d", c->rating);
        csv_cell(b, c->rating ? num : "", 1);
    }
}

/* ---------- user management ---------- */

static void h_users(const http_req *req, reply *r, user_t *me)
{
    if (!is_manager(me)) {
        fail(r, 403, "Admins and supervisors only.");
        return;
    }
    char role[32];
    field(req, "role", role, sizeof role);
    int want = role[0] ? role_from_name(role) : -1;
    r->status = 200;
    sb_puts(&r->body, "{\"items\":[");
    int first = 1;
    for (int i = 0; i < user_count; i++) {
        user_t *u = &users[i];
        if (want >= 0 && (int)u->role != want)
            continue;
        int open_jobs = 0, done = 0;
        for (int j = 0; j < complaint_count; j++) {
            if (complaints[j].assignee_id != u->id)
                continue;
            if (is_open(&complaints[j]))
                open_jobs++;
            else if (complaints[j].status == ST_RESOLVED)
                done++;
        }
        if (!first)
            sb_puts(&r->body, ",");
        first = 0;
        /* reuse user_json but tack the workload numbers on the end */
        size_t mark = r->body.len;
        user_json(&r->body, u);
        (void)mark;
        r->body.len--; /* drop the closing brace */
        sb_kv_int(&r->body, "open_jobs", open_jobs, 0);
        sb_kv_int(&r->body, "resolved_jobs", done, 0);
        sb_puts(&r->body, "}");
    }
    sb_puts(&r->body, "]}");
}

static void h_user_create(const http_req *req, reply *r, user_t *me)
{
    if (me->role != ROLE_ADMIN) {
        fail(r, 403, "Only the admin can create accounts.");
        return;
    }
    char username[64], name[96], role[32], dept[128], phone[48], password[128];
    field(req, "username", username, sizeof username);
    field(req, "name", name, sizeof name);
    field(req, "role", role, sizeof role);
    field(req, "dept", dept, sizeof dept);
    field(req, "phone", phone, sizeof phone);
    field(req, "password", password, sizeof password);
    int rl = role_from_name(role);
    if (rl < 0) {
        fail(r, 400, "Role must be student, staff, admin or supervisor.");
        return;
    }
    if (!valid_username(username)) {
        fail(r, 400, "ID should be 3-30 letters, digits, '-', '_' or '.'.");
        return;
    }
    if (strlen(name) < 2 || strlen(password) < 6) {
        fail(r, 400, "Name is required and the password needs 6+ characters.");
        return;
    }
    if (user_by_name(username)) {
        fail(r, 409, "That ID is taken.");
        return;
    }
    user_t *u = user_create(username, name, (role_t)rl, dept, phone, password);
    if (!u) {
        fail(r, 500, "User table is full.");
        return;
    }
    store_save_users();
    r->status = 201;
    user_json(&r->body, u);
}

static void h_user_update(const http_req *req, reply *r, user_t *me, user_t *u, const char *what)
{
    if (me->role != ROLE_ADMIN) {
        fail(r, 403, "Only the admin can change accounts.");
        return;
    }
    if (strcmp(what, "active") == 0) {
        char v[8];
        field(req, "active", v, sizeof v);
        if (u->id == me->id) {
            fail(r, 409, "You can't disable your own account.");
            return;
        }
        u->active = strcmp(v, "1") == 0;
    } else if (strcmp(what, "password") == 0) {
        char p[128];
        field(req, "password", p, sizeof p);
        if (strlen(p) < 6) {
            fail(r, 400, "Password needs at least 6 characters.");
            return;
        }
        user_set_password(u, p); /* new salt, so their old tokens stop working */
    } else {
        fail(r, 404, "Unknown action.");
        return;
    }
    store_save_users();
    r->status = 200;
    user_json(&r->body, u);
}

/* ---------- router ---------- */

static int is(const http_req *req, const char *method) { return strcmp(req->method, method) == 0; }

static void route(const http_req *req, reply *r)
{
    /* split /api/a/b/c into parts */
    char path[512];
    snprintf(path, sizeof path, "%s", req->path + 4); /* skip "/api" */
    char *parts[6] = {0};
    int np = 0;
    for (char *save = NULL, *t = strtok_r(path, "/", &save); t && np < 6; t = strtok_r(NULL, "/", &save))
        parts[np++] = t;
    if (np == 0) {
        fail(r, 404, "No such endpoint.");
        return;
    }
    const char *p0 = parts[0];

    /* public endpoints */
    if (np == 1 && !strcmp(p0, "health") && is(req, "GET")) { h_health(r); return; }
    if (np == 1 && !strcmp(p0, "meta") && is(req, "GET")) { h_meta(r); return; }
    if (np == 1 && !strcmp(p0, "login") && is(req, "POST")) { h_login(req, r); return; }
    if (np == 1 && !strcmp(p0, "register") && is(req, "POST")) { h_register(req, r); return; }
    if (np == 1 && !strcmp(p0, "logout") && is(req, "POST")) {
        snprintf(r->headers, sizeof r->headers, "Set-Cookie: cms_token=; Path=/; Max-Age=0\r\n");
        { ok_msg(r, "Signed out."); return; }
    }

    user_t *me = session_user(req);
    if (!me) {
        fail(r, 401, "Please sign in again.");
        return;
    }

    if (np == 1 && !strcmp(p0, "me") && is(req, "GET")) {
        r->status = 200;
        user_json(&r->body, me);
        return;
    }
    if (np == 1 && !strcmp(p0, "password") && is(req, "POST")) { h_password(req, r, me); return; }
    if (np == 1 && !strcmp(p0, "stats") && is(req, "GET")) { h_stats(r, me); return; }
    if (np == 1 && !strcmp(p0, "audit") && is(req, "GET")) { h_audit(req, r, me); return; }
    if (np == 1 && !strcmp(p0, "export.csv") && is(req, "GET")) { h_export(r, me); return; }

    if (!strcmp(p0, "users")) {
        if (np == 1 && is(req, "GET")) { h_users(req, r, me); return; }
        if (np == 1 && is(req, "POST")) { h_user_create(req, r, me); return; }
        if (np == 3 && is(req, "POST")) {
            user_t *u = user_by_id(atoi(parts[1]));
            if (!u) { fail(r, 404, "No such user."); return; }
            { h_user_update(req, r, me, u, parts[2]); return; }
        }
    }

    if (!strcmp(p0, "complaints")) {
        if (np == 1 && is(req, "GET")) { h_list(req, r, me); return; }
        if (np == 1 && is(req, "POST")) { h_create(req, r, me); return; }
        complaint_t *c = np >= 2 ? find_complaint(parts[1]) : NULL;
        if (!c || !can_view(me, c)) {
            /* same answer either way, so ids can't be probed */
            fail(r, 404, "No such complaint.");
            return;
        }
        if (np == 2 && is(req, "GET")) { h_get(r, me, c); return; }
        if (np == 3 && is(req, "POST")) {
            const char *a = parts[2];
            if (!strcmp(a, "status")) { h_status(req, r, me, c); return; }
            if (!strcmp(a, "assign")) { h_assign(req, r, me, c); return; }
            if (!strcmp(a, "note")) { h_note(req, r, me, c); return; }
            if (!strcmp(a, "escalate")) { h_escalate(req, r, me, c, 1); return; }
            if (!strcmp(a, "deescalate")) { h_escalate(req, r, me, c, 0); return; }
            if (!strcmp(a, "rate")) { h_rate(req, r, me, c); return; }
        }
    }
    fail(r, 404, "No such endpoint.");
}

void api_handle(int fd, http_req *req)
{
    reply r;
    memset(&r, 0, sizeof r);
    sb_init(&r.body);

    pthread_mutex_lock(&store_mx);
    route(req, &r);
    pthread_mutex_unlock(&store_mx);

    http_send(fd, r.status ? r.status : 500, r.ctype ? r.ctype : "application/json; charset=utf-8",
              r.body.data, r.body.len, r.headers[0] ? r.headers : NULL);
    sb_free(&r.body);
}
