#ifndef HTTP_H
#define HTTP_H

#include <stddef.h>

#define MAX_BODY (64 * 1024)

typedef struct {
    char method[8];
    char path[512];   /* decoded path without the query string */
    char query[1024]; /* raw query string, may be empty */
    char cookie[512];
    char auth[256];   /* Authorization header value */
    char peer[64];    /* client ip, for the log */
    char *body;       /* NUL-terminated, may be empty */
    size_t body_len;
} http_req;

/* Reads one request from fd. Returns 0 on success, an HTTP status code on error. */
int http_read_request(int fd, http_req *req);
void http_free_request(http_req *req);

void http_send(int fd, int status, const char *ctype, const char *body, size_t len,
               const char *extra_headers);
void http_send_json(int fd, int status, const char *json);
void http_send_error(int fd, int status, const char *message);

/* Serves a file from the web root. Refuses anything that tries to climb out of it. */
void http_send_file(int fd, const char *root, const char *path);

/* Looks up key in an application/x-www-form-urlencoded string (body or query).
 * Returns 1 if found. The value is URL-decoded into out. */
int form_get(const char *src, const char *key, char *out, size_t n);

/* Pulls a cookie value out of the Cookie header. */
int cookie_get(const char *cookies, const char *name, char *out, size_t n);

const char *status_text(int status);

#endif
