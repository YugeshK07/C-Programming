---
name: Institutional Incident & Complaint System
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf4'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dde9ff'
  surface-container-highest: '#d5e3fd'
  on-surface: '#0d1c2f'
  on-surface-variant: '#444651'
  inverse-surface: '#233144'
  inverse-on-surface: '#ebf1ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#4b1c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#6e2c00'
  on-tertiary-container: '#f39461'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb691'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#773205'
  background: '#f8f9ff'
  on-background: '#0d1c2f'
  surface-variant: '#d5e3fd'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-inline:
    fontFamily: monospace
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers an institutional, high-reliability enterprise interface designed for mission-critical record handling, complaint resolution, and audit trails. Emphasizing utility, data density, and systemic legibility over ornamental trends, the visual language draws from functional engineering dashboards, institutional administration portals, and rigorous data-management consoles.

The emotional tone communicates structural accountability, immediate status comprehension, and operational neutrality. Visual hierarchy relies on razor-sharp alignment, deliberate tabular layout grids, and functional semantic status badging, ensuring operators can navigate large complaint backlogs, manage ticket transitions, and ingest detailed technical telemetry with zero ambiguity.

## Colors

The palette is engineered around high-contrast institutional legibility against pure white and off-white base surfaces.

- **Primary (`#1E3A8A`)**: Institutional Navy Blue anchor used for prominent primary CTAs, active global navigation, and key identification indices. Supported by an ultra-deep navy (`#0F2942`) for solid side navigation bars and primary table headers.
- **Secondary (`#0D9488`)**: Precise Teal used for structural accents, secondary interactive affordances, active filter states, and data visualization callouts.
- **Neutrals**: Crisp structural scale spanning `#FFFFFF` (pure surface), `#F8FAFC` (workspace canvas and zebra row tint), `#E2E8F0` (table and input borders), `#64748B` (secondary labels, metadata, and timestamps), and `#334155` / `#0F172A` (authoritative text rendering).
- **Functional Status Indicators**:
  - **Pending / Awaiting Action**: Amber (`#D97706` text/border on `#FEF3C7` background).
  - **In-Progress / Investigation**: Slate Blue (`#2563EB` text/border on `#EFF6FF` background).
  - **Resolved / Closed**: Emerald (`#059669` text/border on `#ECFDF5` background).
  - **Escalated / Critical**: Rose (`#E11D48` text/border on `#FFF1F2` background).

## Typography

Typography prioritizes extreme clarity, compact information density, and instant scanning. `Inter` acts as the universal system workhorse, supplemented with clean monospaced font handling for ticket IDs, telemetry logs, and C-backend error identifiers.

Numeric values in data grids must employ tabular lining figures (`font-variant-numeric: tabular-nums`) to preserve column verticality. Form labels, status indicators, and table header tags utilize uppercase or sentence-cased medium weights to distinguish structural labels from dynamic record values.

## Layout & Spacing

The layout model is governed by a fluid enterprise dashboard structure framed by a 12-column dynamic grid. Vertical and horizontal rhythms strictly leverage a 4px baseline matrix.

- **Canvas & Containers**: The default background sits on `#F8FAFC`, with operational modules, search panels, and record grids presented on explicit `#FFFFFF` bounded containers. 
- **Breakpoints & Adaptation**:
  - **Mobile (<768px)**: Single column stacked flow, collapsible header, hidden lower-priority tabular columns via progressive disclosure, and 1rem outer margin.
  - **Tablet (768px - 1024px)**: Dual pane view (record list left, detail panel overlay), collapsible navigation rail.
  - **Desktop (1024px+)**: Fixed 240px enterprise sidebar navigation, top utilitarian command bar, fluid record workspace with right-docked complaint inspection inspector panes.
- **Density Tiering**: Table rows and form rows adhere to compact vertical paddings (`space-sm` for compact tables, `space-md` for standard forms) to prevent excessive vertical scrolling during extensive data processing.

## Elevation & Depth

This design system rejects heavy blurs, translucent glass effects, and dramatic dropshadows in favor of **structural containment and low-contrast perimeter definition**.

- **Structural Outlines**: Depth is primarily articulated using 1px solid borders (`#E2E8F0`). Containers, data cards, and table headers stay grounded within crisp border perimeters.
- **Level 0 (Flat)**: Workspace canvas (`#F8FAFC`).
- **Level 1 (Surface Containers)**: Data cards, table shells, and sidebar blocks (`#FFFFFF`, bordered by 1px solid `#E2E8F0`).
- **Level 2 (Popovers & Context Menus)**: Dropdown action menus, filter overlays, and tooltips utilize an understated technical drop: `0px 2px 4px -1px rgba(15, 41, 66, 0.06), 0px 4px 6px -1px rgba(15, 41, 66, 0.1)`, bounded by a 1px solid `#CBD5E1` border.
- **Level 3 (Modal Drawers & Dialogs)**: Critical incident escalations and audit confirmation modals sit at `0px 10px 15px -3px rgba(15, 41, 66, 0.1), 0px 4px 6px -2px rgba(15, 41, 66, 0.05)` with a backdrop tinted to `#0F172A` at 40% opacity.

## Shapes

The design system implements a controlled, soft institutional geometry (`roundedness: 1`). 

- **Base Radius (`0.25rem` / `4px`)**: Applied consistently to primary and secondary buttons, form input controls, search bars, badge pills, and individual table selection indicators.
- **Container Radius (`rounded-lg` / `0.5rem` / `8px`)**: Applied to high-level content wrappers, card modules, modal containers, and system status callout banners.
- **Zero Radius (`0px`)**: Retained deliberately for compact table cell dividers, full-height lateral panels, and vertical tab dividers to preserve alignment integrity against strict tabular data structures.

## Components

### Buttons
- **Primary**: Solid `#1E3A8A` background, `#FFFFFF` text, 1px solid `#1E3A8A`. Hover: `#0F2942`. Active: `#0B1E32`. Focused: 2px outline `#0D9488` with 2px offset.
- **Secondary**: `#FFFFFF` background, `#334155` text, 1px solid `#CBD5E1`. Hover: `#F1F5F9`.
- **Destructive / Escalation**: `#FFFFFF` background, `#E11D48` text, 1px solid `#FECDD3`. Hover: `#FFF1F2`.
- **Dimensions**: Compact 32px height for operational tools; standard 38px height for modal actions.

### Badges & Status Chips
- Monospaced, high-contrast, compact status flags rendered at 11px font size with `0.25rem` corner radius.
- Padding: 2px vertical, 6px horizontal.
- Includes a 6px solid circular indicator dot matching the status color prefix.

### Form Inputs & Selects
- 1px solid `#CBD5E1` border on `#FFFFFF` background, height 34px, 8px horizontal padding.
- Focus: 1px solid `#1E3A8A` with a subtle 2px ring at 15% opacity (`rgba(30, 58, 138, 0.15)`).
- Error state: 1px solid `#E11D48` accompanied by an inline 12px error explanation below the input.

### Data Tables (Complaint Queue)
- Table header: `#F8FAFC` background with a solid 1px `#CBD5E1` bottom border, uppercase 11px tracking-wider text (`#64748B`).
- Table rows: Minimum 40px height, `#FFFFFF` default with alternating `#F8FAFC` zebra striping or `#F1F5F9` hover state.
- Cell alignment: Monospaced Ticket IDs left-aligned, status badges centered, numerical metrics right-aligned.

### Cards & Summary Metrics
- Flat white containers with 1px solid `#E2E8F0` border and `0.5rem` radius.
- Metric cards display an 11px uppercase subtitle, prominent 24px semi-bold metric, and status indicator tag with teal or amber trend identifiers.

### Interactive Checkboxes & Radio Controls
- Square 14px boxes with 2px rounded corners. Unchecked: `#FFFFFF` with `#94A3B8` border. Checked: `#1E3A8A` with solid white check glyph.