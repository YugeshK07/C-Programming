#ifndef SIMATS_BILLING_H
#define SIMATS_BILLING_H

#define SERVICE_PERCENT 5.0
#define MAX_ID_LENGTH 50

double calculate_service_charge(double subtotal);

#endif /* SIMATS_BILLING_H */
