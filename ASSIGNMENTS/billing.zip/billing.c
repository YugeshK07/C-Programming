#include <stdio.h>
#include <string.h>

#define SERVICE_PERCENT 5.0
#define MAX_ID_LENGTH 50

int main(void)
{
    char facility_id[MAX_ID_LENGTH];
    double units, rate, subtotal, service_charge, final_bill;

    printf("SMART CAMPUS UTILITY BILLING SYSTEM\n");
    printf("Enter facility/consumer ID: ");
    if (scanf("%49s", facility_id) != 1) {
        printf("Error: identifier is required.\n");
        return 1;
    }
    printf("Enter units consumed: ");
    if (scanf("%lf", &units) != 1) {
        printf("Error: units must be numeric.\n");
        return 1;
    }
    printf("Enter rate per unit (Rs.): ");
    if (scanf("%lf", &rate) != 1) {
        printf("Error: rate must be numeric.\n");
        return 1;
    }
    if (units < 0.0 || rate < 0.0) {
        printf("Error: units and rate cannot be negative.\n");
        return 1;
    }

    subtotal = units * rate;
    service_charge = subtotal * SERVICE_PERCENT / 100.0;
    final_bill = subtotal + service_charge;

    printf("\n----------- BILL SUMMARY -----------\n");
    printf("Facility ID       : %s\n", facility_id);
    printf("Units consumed    : %.2f\n", units);
    printf("Rate per unit     : Rs. %.2f\n", rate);
    printf("Subtotal          : Rs. %.2f\n", subtotal);
    printf("Service charge(5%%): Rs. %.2f\n", service_charge);
    printf("Final bill        : Rs. %.2f\n", final_bill);
    printf("------------------------------------\n");
    return 0;
}
