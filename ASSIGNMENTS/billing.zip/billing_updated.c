#include <stdio.h>
#include <string.h>

#define SERVICE_PERCENT 5.0
#define CONCESSION_PERCENT 10.0
#define WARNING_LIMIT 1000.0
#define MAX_ID_LENGTH 50
#define ELIGIBLE_DEPARTMENT "LIB"

int main(void)
{
    char facility_id[MAX_ID_LENGTH];
    char department_code[20];
    double units, rate, subtotal, concession, discounted_subtotal;
    double service_charge, final_bill;
    int eligible;

    printf("SMART CAMPUS UTILITY BILLING SYSTEM - UPDATED\n");
    printf("Enter facility/consumer ID: ");
    if (scanf("%49s", facility_id) != 1) {
        printf("Error: identifier is required.\n");
        return 1;
    }
    printf("Enter department code (LIB for eligible department): ");
    if (scanf("%19s", department_code) != 1) {
        printf("Error: department code is required.\n");
        return 1;
    }
    printf("Enter units consumed: ");
    if (scanf("%lf", &units) != 1) {
        printf("Error: units must be numeric.\n");
        return 1;
    }
    printf("Enter rate per unit (Rs.): ");
    if (scanf("%lf", &rate) != 1) {
        printf("Error: rate must be numeric.\n");
        return 1;
    }
    if (units < 0.0 || rate < 0.0) {
        printf("Error: units and rate cannot be negative.\n");
        return 1;
    }

    eligible = (strcmp(department_code, ELIGIBLE_DEPARTMENT) == 0);
    subtotal = units * rate;
    concession = eligible ? subtotal * CONCESSION_PERCENT / 100.0 : 0.0;
    discounted_subtotal = subtotal - concession;
    service_charge = discounted_subtotal * SERVICE_PERCENT / 100.0;
    final_bill = discounted_subtotal + service_charge;

    printf("\n----------- UPDATED BILL SUMMARY -----------\n");
    printf("Facility ID       : %s\n", facility_id);
    printf("Department code   : %s\n", department_code);
    printf("Eligibility       : %s\n", eligible ? "YES" : "NO");
    printf("Units consumed    : %.2f\n", units);
    printf("Rate per unit     : Rs. %.2f\n", rate);
    printf("Subtotal          : Rs. %.2f\n", subtotal);
    printf("Concession        : Rs. %.2f\n", concession);
    printf("After concession  : Rs. %.2f\n", discounted_subtotal);
    printf("Service charge(5%%): Rs. %.2f\n", service_charge);
    printf("Final bill        : Rs. %.2f\n", final_bill);
    if (final_bill - WARNING_LIMIT > 0.000001) {
        printf("WARNING: Bill exceeds Rs. %.2f\n", WARNING_LIMIT);
    } else {
        printf("Bill is within the configured limit.\n");
    }
    printf("--------------------------------------------\n");
    return 0;
}
