#include <stdio.h>
int main(void) {
 printf("Compiler: GCC 14.2.0 (Debian)\n");
 printf("sizeof(char) = %zu bytes\n", sizeof(char));
 printf("sizeof(short) = %zu bytes\n", sizeof(short));
 printf("sizeof(int) = %zu bytes\n", sizeof(int));
 printf("sizeof(long) = %zu bytes\n", sizeof(long));
 printf("sizeof(float) = %zu bytes\n", sizeof(float));
 printf("sizeof(double) = %zu bytes\n", sizeof(double));
 return 0;
}
